// antiban_impl.cpp — Implementaciones de antiban.h
#include <cstdint>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <dlfcn.h>
#include "antiban.h"
#include "../Stealth/got_plt_hooks.h"
#include "../Misc/imports.h"

extern bool AimbotEsp;
static bool g_abDone = false;
static int (*orig_connect)(int, const struct sockaddr*, socklen_t) = nullptr;
static bool g_earlyNetDone = false;

int GetBanRisk() {
    int risk = g_abDone ? 5 : 35;
    if (AimbotEsp) risk += 8;
    return risk > 100 ? 100 : risk;
}

void ApplyAntiBan() {
    if (g_abDone) return;
    struct HookEntry { uintptr_t addr; void* fn; };
    HookEntry hooks[] = {
        { (uintptr_t)AB_BypassAllFilters,        _ab_true },
        { (uintptr_t)AB_LogReportCheat,          _ab_noop },
        { (uintptr_t)AB_LogReportCheatInHistory, _ab_noop },
        { (uintptr_t)AB_LogOutGameReport,        _ab_noop },
        { (uintptr_t)AB_OnReportCheatClick,      _ab_noop },
        { (uintptr_t)AB_SendQuickReport,         _ab_noop },
        { (uintptr_t)AB_OnUGCKickOutPlayer,      _ab_noop },
    };
    for (auto& h : hooks)
        if (h.addr) A64HookFunction(reinterpret_cast<void*>(h.addr), h.fn, nullptr);
    g_abDone = true;

    // Nivel 1+2: GOT/PLT hooks (packet sanitizer + libanogs CRC fixer)
    ApplyGotPltHooks();
}

void ApplyNetworkHook() {}

static bool IsReportEndpoint(const struct sockaddr* addr) {
    if (!addr || addr->sa_family != AF_INET) return false;
    uint32_t ip = ntohl(((const struct sockaddr_in*)addr)->sin_addr.s_addr);
    uint8_t b0 = (ip >> 24) & 0xFF, b1 = (ip >> 16) & 0xFF;
    return b0 == 103 && (b1 == 15 || b1 == 243 || b1 == 248);
}

static int hook_connect(int fd, const struct sockaddr* addr, socklen_t len) {
    if (IsReportEndpoint(addr)) return 0;
    return orig_connect(fd, addr, len);
}

void ApplyEarlyNetworkBlock() {
    if (g_earlyNetDone) return;
    g_earlyNetDone = true;
    void* libc = dlopen(OBFUSCATE("libc.so"), RTLD_NOW | RTLD_NOLOAD);
    if (!libc) return;
    void* fn = dlsym(libc, OBFUSCATE("connect"));
    if (fn && !orig_connect)
        A64HookFunction(fn, (void*)hook_connect, reinterpret_cast<void**>(&orig_connect));
    dlclose(libc);
}
