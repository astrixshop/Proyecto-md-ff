#pragma once

// ── MTE pointer tag strip (Android 15 / Redmi with MTE enabled) ──────────
// il2cpp managed objects carry a memory tag in the top byte of their pointer.
// Any arithmetic or dereference on a tagged pointer crashes with SIGSEGV.
// Strip the tag before using any il2cpp pointer as a raw C++ pointer.
#ifndef UNTAG_PTR
#define UNTAG_PTR(p) (reinterpret_cast<std::remove_reference_t<decltype(p)>>((uintptr_t)(p) & 0x00FFFFFFFFFFFFFFull))
#endif

// updates.h — Solo variables de offsets y CacheAllOffsets()
// Las utilidades base (AfindLibrary, AgetAbsoluteAddress, Vvector3, etc.)
// están en KittyMemory/Deps/Imguii.h que se incluye via importz.h
// NO duplicar aquí — causa redefinición en AIDE NDK

// ─── Cached offset variables (all zero until CacheAllOffsets() runs) ──────────
inline uintptr_t Class_Camera__get_main       = 0;
inline uintptr_t Class_Input__get_touchCount  = 0;
inline uintptr_t Class_Input__GetTouch        = 0;
inline uintptr_t Class_Input__get_mousePosition = 0;
inline uintptr_t Class_Screen__get_width      = 0;
inline uintptr_t Class_Screen__get_height     = 0;
inline uintptr_t Class_Screen__get_density    = 0;
inline uintptr_t Camera_get_fieldOfView       = 0;
inline uintptr_t Camera_set_fieldOfView       = 0;
inline uintptr_t ForWard                      = 0;
inline uintptr_t Class_Transform__GetPosition = 0;
inline uintptr_t Class_Transform__SetPosition = 0;
inline uintptr_t Class_Transform__Position    = 0;
inline uintptr_t Class_Transform__Rotation    = 0;
inline uintptr_t Class_Camera__WorldToScreenPoint = 0;
inline uintptr_t ListPlayer                   = 0;
inline uintptr_t EnemyUpdate                  = 0;
inline uintptr_t MainCam                      = 0;
inline uintptr_t Match                        = 0;
inline uintptr_t Local                        = 0;
inline uintptr_t Visible                      = 0;
inline uintptr_t Team                         = 0;
inline uintptr_t Die                          = 0;
inline uintptr_t CurHP                        = 0;
inline uintptr_t MaxHP                        = 0;
inline uintptr_t Name                         = 0;
inline uintptr_t Aim                          = 0;
inline uintptr_t Scope                        = 0;
inline uintptr_t Fire                         = 0;
inline uintptr_t Head                         = 0;
inline uintptr_t CharGet                      = 0;
inline uintptr_t HeadColider                  = 0;
inline uintptr_t Hip                          = 0;
inline uintptr_t Class_Compent__Transform     = 0;
inline uintptr_t Imo                          = 0;
inline uintptr_t Esp2                         = 0;
inline uintptr_t TranGetPosition              = 0;
inline uintptr_t GameObject                   = 0;
inline uintptr_t offset_isGod                 = 0;
inline uintptr_t offset_StopFiring            = 0;
inline uintptr_t offset_GetDelay              = 0;
inline uintptr_t m_DamageRange                = 0;
inline uintptr_t m_Timer                      = 0;
inline uintptr_t m_GetTimer                   = 0;
inline uintptr_t m_SetTimer                   = 0;
inline uintptr_t m_isClientBot                = 0;
inline uintptr_t offset_JMKMBNIBFNA           = 0;
inline uintptr_t offset_GHACJPMCEDK           = 0;
inline uintptr_t offset_OJKBBAOPPIN           = 0;
inline uintptr_t AimInfoFromWeapon            = 0;  // get_LastAimingInfoFromWeapon
inline uintptr_t WeaponSilenceOffset          = 0;  // weapon silence patch (HIEAPNFKDBJ)
inline uintptr_t Raycast                      = 0;
inline uintptr_t CenterWS                     = 0;
inline uintptr_t WeaponOnHand                 = 0;
inline uintptr_t HeadTF                       = 0;
inline uintptr_t offset_StartFiringer         = 0;

// ─── Cache ALL offsets once after Il2CppIsAssembliesLoaded() ─────────────────
__attribute__((visibility("hidden")))
void CacheAllOffsets() {
    // UnityEngine offsets
    Class_Camera__get_main        = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Camera"),    OBFUSCATE("get_main"),              0);
    Class_Input__get_touchCount   = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Input"),     OBFUSCATE("get_touchCount"),         0);
    Class_Input__GetTouch         = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Input"),     OBFUSCATE("GetTouch"),               1);
    Class_Input__get_mousePosition= (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Input"),     OBFUSCATE("get_mousePosition"),      0);
    Class_Screen__get_width       = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Screen"),    OBFUSCATE("get_width"),              0);
    Class_Screen__get_height      = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Screen"),    OBFUSCATE("get_height"),             0);
    Class_Screen__get_density     = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Screen"),    OBFUSCATE("get_dpi"),                0);
    Camera_get_fieldOfView        = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Camera"),    OBFUSCATE("get_fieldOfView"),         0);
    Camera_set_fieldOfView        = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Camera"),    OBFUSCATE("set_fieldOfView"),         1);
    ForWard                       = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Transform"), OBFUSCATE("get_forward"),             0);
    Class_Transform__GetPosition  = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Transform"), OBFUSCATE("get_position_Injected"),  1);
    Class_Transform__SetPosition  = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Transform"), OBFUSCATE("set_position_Injected"),  1);
    Class_Transform__Position     = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Transform"), OBFUSCATE("get_position"),           0);
    Class_Transform__Rotation     = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Transform"), OBFUSCATE("get_rotation"),           0);
    Class_Camera__WorldToScreenPoint=(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Camera"),   OBFUSCATE("WorldToScreenPoint"),     1);
    Class_Compent__Transform      = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Component"), OBFUSCATE("get_transform"),          0);
    GameObject                    = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Component"), OBFUSCATE("get_gameObject"),         0);
    TranGetPosition               = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.CoreModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Transform"), OBFUSCATE("get_position_Injected"), 1);

    // Game offsets — Assembly-CSharp
    ListPlayer      = (uintptr_t)Il2CppGetFieldOffset( OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("NFJPHMKKEBF"),    OBFUSCATE("HOOCHDLKOOG"));
    EnemyUpdate     = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("LateUpdate"),                 0);
    MainCam         = (uintptr_t)Il2CppGetFieldOffset( OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("MainCameraTransform"));
    Match           = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"),          OBFUSCATE("GameFacade"),     OBFUSCATE("CurrentMatch"),               0);
    Local           = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"),          OBFUSCATE("UIHudDetectorController"), OBFUSCATE("GetLocalPlayer"),   0);
    Visible         = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("IsVisible"),                  0);
    Team            = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("IsLocalTeammate"),             1);
    Die             = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("get_IsDieing"),               0);
    CurHP           = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("get_CurHP"),                  0);
    MaxHP           = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("get_MaxHP"),                  0);
    Name            = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("get_NickName"),               0);
    Aim             = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("SetAimRotation"),             2);
    Scope           = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("get_IsSighting"),             0);
    Fire            = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("IsFiring"),                   0);    CharGet         = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("mscorlib.dll"),        OBFUSCATE("System"),       OBFUSCATE("String"),         OBFUSCATE("get_Chars"),                  1);
    HeadColider     = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("get_HeadCollider"),           0);
    Hip             = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("GetHipTF"),                   0);
    Head            = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("GetHeadTF"),                  0);
    Esp2            = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("LevelMiniSentry"),OBFUSCATE("CPBCGAKODII"),               2);
    Raycast         = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("JEAGCMACNNC"),    OBFUSCATE("PLDCHDBCOBF"),               4);
    CenterWS        = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("GetAttackableCenterWS"),      0);
    WeaponOnHand    = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("GetWeaponOnHand"),            0);
    HeadTF          = Head;
    offset_StartFiringer = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("GPBDEDFKJNA"), OBFUSCATE("MPGJOKFGLGK"), 0);    offset_isGod    = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("get_IsGod"),                  0);    offset_StopFiring    = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("GPBDEDFKJNA"), OBFUSCATE("EJONAOOEOJH"),  0);    offset_GetDelay      = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("GPBDEDFKJNA"), OBFUSCATE("LMGGNHPNMNI"),  0);
    m_DamageRange        = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("GPBDEDFKJNA"), OBFUSCATE("JDGGIFMKIKF"),  0);
    m_Timer         = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"),          OBFUSCATE("GameFacade"),     OBFUSCATE("CurrentGameSimulationTimer"), 0);
    m_GetTimer      = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GCommon"),      OBFUSCATE("TimeService"),    OBFUSCATE("get_FixedDeltaTime"),         0);
    m_SetTimer      = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GCommon"),      OBFUSCATE("TimeService"),    OBFUSCATE("UseFixedDeltaTime"),          1);
    m_isClientBot   = (uintptr_t)Il2CppGetFieldOffset( OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"),         OBFUSCATE("IsClientBot"));
    offset_JMKMBNIBFNA = (uintptr_t)Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("MADMMIICBNN"), OBFUSCATE("JMKMBNIBFNA"));
    offset_GHACJPMCEDK = (uintptr_t)Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("MADMMIICBNN"), OBFUSCATE("GHACJPMCEDK"));
    offset_OJKBBAOPPIN = (uintptr_t)Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("MADMMIICBNN"), OBFUSCATE("OJKBBAOPPIN"));
    AimInfoFromWeapon  = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("get_LastAimingInfoFromWeapon"), 0);
    WeaponSilenceOffset= (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("GPBDEDFKJNA"), OBFUSCATE("HIEAPNFKDBJ"), 0);
}

// ─── Wrapper functions (use cached statics, all with null guard) ──────────────

void* get_main() {
    if (!Class_Camera__get_main) return nullptr;
    return UNTAG_PTR(reinterpret_cast<void* (*)()>(Class_Camera__get_main)());
}

int get_width() {
    if (!Class_Screen__get_width) return 0;
    return reinterpret_cast<int(*)()>(Class_Screen__get_width)();
}

int get_height() {
    if (!Class_Screen__get_height) return 0;
    return reinterpret_cast<int(*)()>(Class_Screen__get_height)();
}

float get_fieldOfView() {
    if (!Camera_get_fieldOfView) return 0.f;
    return reinterpret_cast<float(*)(void*)>(Camera_get_fieldOfView)(get_main());
}

void* set_fieldOfView(float value) {
    if (!Camera_set_fieldOfView) return nullptr;
    return reinterpret_cast<void* (*)(void*, float)>(Camera_set_fieldOfView)(get_main(), value);
}

static Vector3 GetForward(void* player) {
    if (!ForWard || !player) return Vector3::zero();
    Vector3(*_GetForward)(void*) = (Vector3(*)(void*))(ForWard);
    return _GetForward(player);
}

static Vector3 Transform_GetPosition(void* player) {
    Vector3 out = Vector3::zero();
    if (!Class_Transform__GetPosition || !player) return out;
    void (*_fn)(void*, Vector3*) = (void (*)(void*, Vector3*))(Class_Transform__GetPosition);
    _fn(player, &out);
    return out;
}

static void Transform_INTERNAL_SetPosition(void* player, Vvector3 inn) {
    if (!Class_Transform__SetPosition || !player) return;
    void (*_fn)(void*, Vvector3) = (void (*)(void*, Vvector3))(Class_Transform__SetPosition);
    _fn(player, inn);
}

Vector3 get_position(void* player) {
    if (!Class_Transform__Position || !player) return Vector3::zero();
    Vector3(*_fn)(void*) = (Vector3(*)(void*))(Class_Transform__Position);
    return _fn(player);
}

static Quaternion GetRotation(void* player) {
    if (!Class_Transform__Rotation || !player) return Quaternion();
    Quaternion (*_fn)(void*) = (Quaternion(*)(void*))(Class_Transform__Rotation);
    return _fn(player);
}

static Vector3 WorldToScreenPoint(void* WorldCam, Vector3 WorldPos) {
    if (!Class_Camera__WorldToScreenPoint || !WorldCam) return Vector3::zero();
    Vector3(*_fn)(void*, Vector3) = (Vector3(*)(void*, Vector3))(Class_Camera__WorldToScreenPoint);
    return _fn(WorldCam, WorldPos);
}

static Vector3 CameraMain(void* player) {
    if (!MainCam || !player) return Vector3::zero();
    return get_position(*(void**)((uint64_t)player + MainCam));
}

static void* Curent_Match() {
    if (!Match) return nullptr;
    void* (*_fn)(void*) = (void* (*)(void*))(Match);
    return UNTAG_PTR(_fn(NULL));
}

static void* GetLocalPlayer(void* Game) {
    if (!Local || !Game) return nullptr;
    void* (*_fn)(void*) = (void* (*)(void*))(Local);
    return UNTAG_PTR(_fn(Game));
}

static bool get_isVisible(void* player) {
    if (!Visible || !player) return false;
    bool (*_fn)(void*) = (bool (*)(void*))(Visible);
    return _fn(player);
}

static bool get_isLocalTeam(void* player) {
    if (!Team || !player) return false;
    using fn_t = bool(*)(void*, bool);
    return reinterpret_cast<fn_t>(Team)(player, false);
}

static bool get_IsDieing(void* player) {
    if (!Die || !player) return false;
    bool (*_fn)(void*) = (bool (*)(void*))(Die);
    return _fn(player);
}

static int GetHp(void* player) {
    if (!CurHP || !player) return 0;
    int (*_fn)(void*) = (int(*)(void*))(CurHP);
    return _fn(player);
}

static int get_MaxHP(void* enemy) {
    if (!MaxHP || !enemy) return 0;
    int (*_fn)(void*) = (int(*)(void*))(MaxHP);
    return _fn(enemy);
}

static monoString* get_NickName(void* player) {
    if (!Name || !player) return nullptr;
    monoString* (*_fn)(void*) = (monoString*(*)(void*))(Name);
    return _fn(player);
}

static bool get_IsSighting(void* player) {
    if (!Scope || !player) return false;
    bool (*_fn)(void*) = (bool (*)(void*))(Scope);
    return _fn(player);
}

static bool get_IsFiring(void* player) {
    if (!Fire || !player) return false;
    bool (*_fn)(void*) = (bool (*)(void*))(Fire);
    return _fn(player);
}

static void* GetHeadPositions(void* player) {
    if (!Head || !player) return nullptr;
    void* (*_fn)(void*) = (void* (*)(void*))(Head);
    return UNTAG_PTR(_fn(player));
}

char get_Chars(monoString* str, int index) {
    if (!CharGet || !str) return 0;
    char (*_fn)(monoString*, int) = (char (*)(monoString*, int))(CharGet);
    return _fn(str, index);
}

static void* Player_GetHeadCollider(void* player) {
    if (!HeadColider || !player) return nullptr;
    void* (*_fn)(void*) = (void* (*)(void*))(HeadColider);
    return _fn(player);
}

static void* GetHipPositions(void* player) {
    if (!Hip || !player) return nullptr;
    void* (*_fn)(void*) = (void*(*)(void*))(Hip);
    return UNTAG_PTR(_fn(player));
}

static void* Component_GetTransform(void* player) {
    if (!Class_Compent__Transform || !player) return nullptr;
    void* (*_fn)(void*) = (void*(*)(void*))(Class_Compent__Transform);
    return UNTAG_PTR(_fn(player));
}

static void* Camera_main() {
    if (!Class_Camera__get_main) return nullptr;
    void* (*_fn)(void*) = (void*(*)(void*))(Class_Camera__get_main);
    return UNTAG_PTR(_fn(nullptr));
}

Vector3 getPosition(void* transform) {
    return get_position(Component_GetTransform(transform));
}
static Vector3 GetHeadPosition(void* player) {
    return get_position(GetHeadPositions(player));
}
static Vector3 GetHipPosition(void* player) {
    return get_position(GetHipPositions(player));
}

float get_density() {
    if (!Class_Screen__get_density) return 1.f;
    return reinterpret_cast<float(*)()>(Class_Screen__get_density)();
}

static void* get_imo(void* player) {
    if (!Imo || !player) return nullptr;
    void* (*_fn)(void*) = (void* (*)(void*))Imo;
    return UNTAG_PTR(_fn(player));
}

static Vector3 Transform_INTERNAL_GetPosition(void* player) {
    Vector3 out = Vector3::zero();
    if (!TranGetPosition || !player) return out;
    void (*_fn)(void*, Vector3*) = (void (*)(void*, Vector3*))(TranGetPosition);
    _fn(player, &out);
    return out;
}

void* get_gameObject(void* player) {
    if (!GameObject || !player) return nullptr;
    return UNTAG_PTR(((void*(*)(void*))(GameObject))(player));
}

static bool get_God(void* player) {
    if (!offset_isGod || !player) return false;
    bool (*_fn)(void*) = (bool (*)(void*))(offset_isGod);
    return _fn(player);
}

static bool Physics_Raycast(Vector3 start, Vector3 end, unsigned int flag, void* hitInfo) {
    if (!Raycast) return false;
    auto _fn = (bool(*)(Vector3, Vector3, unsigned int, void*))(Raycast);
    return _fn(start, end, flag, hitInfo);
}

static float get_Range(void* pthis) {
    if (!m_DamageRange || !pthis) return 0.f;
    return ((float (*)(void*))(m_DamageRange))(pthis);
}
static float get_Delay(void* pthis) {
    if (!offset_GetDelay || !pthis) return 0.f;
    return ((float (*)(void*))(offset_GetDelay))(pthis);
}
static void* StopFiring(void* weapon) {
    if (!offset_StopFiring || !weapon) return nullptr;
    void* (*_fn)(void*) = (void*(*)(void*))(offset_StopFiring);
    return _fn(weapon);
}
static void* GetSimulationTimer() {
    if (!m_Timer) return nullptr;
    void* (*_fn)() = reinterpret_cast<void*(*)()>(m_Timer);
    return UNTAG_PTR(_fn());
}

static float GetTimer(void* inst) {
    if (!m_GetTimer || !inst) return 0.f;
    using fn_t = float(*)(void*);
    return reinterpret_cast<fn_t>(m_GetTimer)(inst);
}

static void SetTimer(void* inst, float fixedDelta) {
    if (!m_SetTimer || !inst) return;
    using fn_t = void(*)(void*, float);
    reinterpret_cast<fn_t>(m_SetTimer)(inst, fixedDelta);
}

// ── Missing wrappers required by aimbot.h ────────────────────────────

// get_IsBot: reads m_isClientBot field from Player object
static bool get_IsBot(void* player) {
    if (!m_isClientBot || !player) return false;
    // m_isClientBot is a field offset — read bool at that offset
    return *(bool*)((uintptr_t)UNTAG_PTR(player) + m_isClientBot);
}



// get_SpineBoneTransform: returns the hip/spine bone Transform (= GetHipTF)
static void* get_SpineBoneTransform(void* player) {
    if (!Hip || !player) return nullptr;
    void* (*_fn)(void*) = (void*(*)(void*))(Hip);
    return UNTAG_PTR(_fn(player));
}

// get_HeadBoneTransform: returns head bone Transform (= GetHeadTF)
static void* get_HeadBoneTransform(void* player) {
    if (!Head || !player) return nullptr;
    void* (*_fn)(void*) = (void*(*)(void*))(Head);
    return _fn(player);
}

// GetLocalPlayerDirect: convenience wrapper = GetLocalPlayer(Curent_Match())
static void* GetLocalPlayerDirect() {
    void* match = Curent_Match();
    if (!match) return nullptr;
    return GetLocalPlayer(match);
}

