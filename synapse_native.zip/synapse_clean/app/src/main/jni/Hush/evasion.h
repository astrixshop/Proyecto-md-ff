// Copyright (c) 2025 @SynapseCheats. All rights reserved.
#pragma once

#include <jni.h>
#include <signal.h>
#include <sys/prctl.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <dlfcn.h>
#include <link.h>
#include <pthread.h>
#include <cstring>
#include <cstdio>
#include "obfuscate.h"

static struct sigaction g_old_sigsegv;
static struct sigaction g_old_sigbus;

static void evasion_signal_handler(int, siginfo_t*, void*) {}

inline void InstallSignalHandlers() {
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = evasion_signal_handler;
    sa.sa_flags     = SA_SIGINFO | SA_RESTART;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, &g_old_sigsegv);
    sigaction(SIGBUS,  &sa, &g_old_sigbus);
}

inline void HideThread(const char* name = nullptr) {
    prctl(PR_SET_NAME, (unsigned long)(name ? name : OBFUSCATE("jbd2/sda0-8")), 0, 0, 0);
}

inline void ProtectMemoryRegion(void* addr, size_t size) {
    if (!addr || size == 0) return;
    long page = sysconf(_SC_PAGESIZE);
    uintptr_t base = (uintptr_t)addr & ~(uintptr_t)(page - 1);
    mlock((void*)base, size + page);
}

struct LibInfo { uintptr_t base, end; bool found; };

inline LibInfo GetLibInfo(const char* libName) {
    LibInfo info = {0, 0, false};
    FILE* f = fopen(OBFUSCATE("/proc/self/maps"), "r");
    if (!f) return info;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        if (!strstr(line, libName)) continue;
        uintptr_t s = 0, e = 0;
        if (sscanf(line, "%lx-%lx", &s, &e) == 2) {
            if (!info.found) { info.base = s; info.found = true; }
            info.end = e;
        }
    }
    fclose(f);
    return info;
}

struct ScanCtx { const char* target; bool found; uintptr_t base; };

static int dl_iter_callback(struct dl_phdr_info* info, size_t, void* data) {
    auto* ctx = static_cast<ScanCtx*>(data);
    if (info->dlpi_name && strstr(info->dlpi_name, ctx->target)) {
        ctx->found = true;
        ctx->base  = (uintptr_t)info->dlpi_addr;
        return 1;
    }
    return 0;
}

inline bool IsLibraryLoaded(const char* name) {
    ScanCtx ctx = {name, false, 0};
    dl_iterate_phdr(dl_iter_callback, &ctx);
    return ctx.found;
}

inline uintptr_t GetLibraryBase(const char* name) {
    ScanCtx ctx = {name, false, 0};
    dl_iterate_phdr(dl_iter_callback, &ctx);
    return ctx.base;
}

inline bool IsBeingTraced() {
    const char ps[] = {'/','p','r','o','c','/','s','e','l','f','/','s','t','a','t','u','s','\0'};
    int fd = (int)syscall(__NR_openat, AT_FDCWD, ps, O_RDONLY, 0);
    if (fd < 0) return false;
    char buf[2048]; ssize_t n = read(fd, buf, sizeof(buf)-1);
    close(fd);
    if (n <= 0) return false;
    buf[n] = '\0';
    for (int i = 0; i < n - 11; i++) {
        if (buf[i]=='T'&&buf[i+1]=='r'&&buf[i+2]=='a'&&buf[i+3]=='c'&&
            buf[i+4]=='e'&&buf[i+5]=='r'&&buf[i+6]=='P'&&buf[i+7]=='i'&&
            buf[i+8]=='d'&&buf[i+9]==':') {
            int pid = 0;
            for (int j = i+10; j < n && buf[j] != '\n'; j++)
                if (buf[j] >= '0' && buf[j] <= '9') pid = pid*10 + (buf[j]-'0');
            return pid != 0;
        }
    }
    return false;
}

inline bool IsEmulator() {
    FILE* f = fopen(OBFUSCATE("/proc/cpuinfo"), "r");
    if (!f) return false;
    char line[512]; bool suspected = false;
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, OBFUSCATE("goldfish")) ||
            strstr(line, OBFUSCATE("ranchu"))   ||
            strstr(line, OBFUSCATE("vbox")))
        { suspected = true; break; }
    }
    fclose(f);
    return suspected;
}

inline bool KernelStatusCheck() {
    if (!IsLibraryLoaded(OBFUSCATE("libil2cpp.so"))) return false;
    if (!IsLibraryLoaded(OBFUSCATE("libunity.so")))  return false;
    return GetLibInfo(OBFUSCATE("libil2cpp.so")).found;
}

inline void EvasionInit() {
    if (IsBeingTraced() || IsEmulator()) {
        kill(getpid(), SIGKILL);
        return;
    }
    HideThread(OBFUSCATE("ext4-rsv-conv"));
    InstallSignalHandlers();
}
