// particulas.h — stub. Ver particles.h
#pragma once
