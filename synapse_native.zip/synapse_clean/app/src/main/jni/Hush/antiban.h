#pragma once
// antiban.h — Solo declaraciones para AIDE NDK r12
// Implementaciones en antiban_impl.cpp

// Offsets dinámicos de Il2Cpp — se calculan en runtime
#include <Il2Cpp.h>
#include "obfuscate.h"
#include <And64InlineHook.hpp>

#define AB_LogReportCheat \
    Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("EventLogger"), OBFUSCATE("LogReportCheat"), 9)
#define AB_LogReportCheatInHistory \
    Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("EventLogger"), OBFUSCATE("LogReportCheatInHistory"), 7)
#define AB_LogOutGameReport \
    Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("EventLogger"), OBFUSCATE("LogOutGameReport"), 4)
#define AB_OnReportCheatClick \
    Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("UIInGameScene"), OBFUSCATE("OnReportCheatClick"), 1)
#define AB_SendQuickReport \
    Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("UIInGameScene"), OBFUSCATE("SendQuickReport"), 2)
#define AB_OnUGCKickOutPlayer \
    Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("UIInGameScene"), OBFUSCATE("OnUGCKickOutPlayer"), 1)
#define AB_BypassAllFilters \
    Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("GameConfig"), OBFUSCATE("get_GER_BypassAllFilters"), 0)

// Stubs de hook — necesitan estar en el header porque se usan en los #define
__attribute__((visibility("hidden")))
inline static int64_t _ab_noop_i64(void*,void*,void*,void*,void*,void*,void*,void*,void*,void*) { return 0; }
__attribute__((visibility("hidden")))
inline static int64_t _ab_true_i64(void*,void*,void*,void*,void*,void*,void*,void*,void*,void*) { return 1; }

#define _ab_noop ((void*)_ab_noop_i64)
#define _ab_true ((void*)_ab_true_i64)

// Declaraciones
int GetBanRisk();
// got_plt_hooks.h se incluye en antiban_impl.cpp donde se llama ApplyGotPltHooks()
void ApplyAntiBan();
void ApplyNetworkHook();
void ApplyEarlyNetworkBlock();
