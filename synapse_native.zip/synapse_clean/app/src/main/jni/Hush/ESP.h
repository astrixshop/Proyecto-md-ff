// Copyright (c) 2025 @SynapseCheats. All rights reserved.
#pragma once
#include "importz.h"

// ── Pointer validation ────────────────────────────────────────────────────────
// UNTAG_PTR estándar: strip TBI tag (bits 56-63)
#ifndef UNTAG_PTR
#define UNTAG_PTR(p) (reinterpret_cast<void*>((uintptr_t)(p) & 0x00FFFFFFFFFFFFFFull))
#endif

// IsGamePtr: verifica que un puntero sea un objeto il2cpp válido.
//
// PROBLEMA REAL (logcat 2026-04-16, fault addr 0x300000018):
//   UNTAG_PTR solo strip bits 56-63. El puntero 0x0000000300000000 tiene
//   el valor "raro" en bits 32-33, NO en bits 56-63. UNTAG_PTR no lo filtra.
//   Resultado: !current_Match es false (0x300000000 != 0), pasa el null-check,
//   y cuando se accede a sus campos (this+0x18) → SIGSEGV en UnityGfxDeviceW.
//
// SOLUCIÓN: en AArch64 Android con ASLR de 39 bits, los objetos il2cpp en
// heap tienen la dirección en el rango aproximado 0x70_0000_0000 a
// 0x7F_FFFF_FFFF (bits 36-39 deben ser 0x7X). El valor 0x300000000 tiene
// bits 36-39 = 0x03 → NO es un heap pointer válido → filtrar.
//
// La macro IsGamePtr también acepta punteros en el rango 32-bit bajo para
// dispositivos ARM con heap < 4GB (raro en 64-bit FF MAX pero como fallback).
static inline bool IsGamePtr(const void* p) {
    if (!p) return false;
    uintptr_t v = (uintptr_t)p & 0x00FFFFFFFFFFFFFFull; // strip TBI tag
    if (v < 0x10000ULL) return false;                   // null-ish / protected page
    // En 64-bit Android, punteros válidos de app están en:
    //   - 0x0000_0070_0000_0000 a 0x0000_007F_FFFF_FFFF (rango principal ASLR)
    //   - 0x0000_0000_7000_0000 a 0x0000_0000_FFFF_FFFF (heap 32-bit legacy)
    // El valor 0x300000000 = 0x0000_0003_0000_0000 cae FUERA de ambos rangos.
    uintptr_t hi40 = v >> 30; // bits [69..30] — suficiente para discriminar
    // Rango principal 64-bit: v ∈ [0x70_0000_0000, 0x7F_FFFF_FFFF] → hi40 ∈ [0x1C0, 0x1FF]
    // Legacy 32-bit:          v ∈ [0x70000000,     0xFFFFFFFF]    → hi40 ∈ [0x1,   0x3]
    // Garbage 0x300000000:    hi40 = 0xC → RECHAZADO
    // (cualquier valor entre 0x4 y 0x1BF se rechaza también)
    return (hi40 >= 0x1C0 && hi40 <= 0x1FF) ||   // heap 64-bit Android principal
           (hi40 >= 0x1   && hi40 <= 0x3);         // heap legacy 32-bit
}

#include "aimbot.h"

static inline Vector3 SafeGetPosition(void* obj) {
    if (!IsGamePtr(obj)) return Vector3::zero();
    void* tf = Component_GetTransform(obj);
    if (!IsGamePtr(tf)) return Vector3::zero();
    return get_position(tf);
}

void DrawESP(float screenWidth, float screenHeight) {
    ImDrawList* draw = ImGui::GetBackgroundDrawList();
    if (!draw || !AimbotEsp) return;

    // ── Validar match y jugador local ────────────────────────────────────────
    void* current_Match = Curent_Match();

    // FIX: IsGamePtr rechaza 0x300000000 y similares que pasan !null pero
    // apuntan a objetos a mitad de construcción → SIGSEGV en UnityGfxDeviceW
    if (!IsGamePtr(current_Match)) return;
    current_Match = UNTAG_PTR(current_Match);

    void* local_player = GetLocalPlayer(current_Match);
    if (!IsGamePtr(local_player)) return;
    local_player = UNTAG_PTR(local_player);

    // FIX CRASH: si ListPlayer=0 (offset no cacheado), match+0 da un puntero
    // al primer campo del objeto Match — totalmente inválido como diccionario
    if (!ListPlayer) return;
    auto* players = reinterpret_cast<monoDictionary<uint8_t*, void**>*>(
        UNTAG_PTR(*(void**)((uintptr_t)current_Match + ListPlayer)));
    void* camera = UNTAG_PTR(Camera_main());

    if (!IsGamePtr(players) || !IsGamePtr(camera)) return;
    // Guard adicional: el diccionario debe tener un count razonable
    // antes de leer su vtable (getNumValues llama método virtual)
    if ((uintptr_t)players < 0x70000000ULL) return;

    // Validar que el conteo de jugadores sea razonable antes de iterar
    int numPlayers = players->getNumValues();
    if (numPlayers <= 0 || numPlayers > 200) return;

    for (int i = 0; i < numPlayers; ++i) {
        void* enemy = UNTAG_PTR(players->getValues()[i]);
        if (!IsGamePtr(enemy) || enemy == local_player) continue;

        bool eIsBot = get_IsBot(enemy);
        if (!eIsBot && get_isLocalTeam(enemy)) continue;
        if (!get_isVisible(enemy) && !eIsBot) continue;

        Vector3 toePos = SafeGetPosition(enemy);
        if (toePos.x == 0.f && toePos.y == 0.f && toePos.z == 0.f) continue;

        Vector3 toeScreen = WorldToScreenPoint(camera, toePos);
        if (toeScreen.z < 1) continue;

        Vector3 headPos = toePos + Vector3(0, 1.7f, 0);
        Vector3 headScreen = WorldToScreenPoint(camera, headPos);
        if (headScreen.z < 1) continue;

        float height = fabsf(headScreen.y - toeScreen.y) * (1.2f / 1.1f);
        float width  = height * 0.5f;
        Rect rect(headScreen.x - width / 2.f, screenHeight - headScreen.y, width, height);

        bool isKnocked = get_IsDieing(enemy);

        if (EspLine && currentLinePosition != TOP_LEFT) {
            ImVec2 startPoint = ImVec2(screenWidth / 2.0f, 10);
            ImColor lineColor = isKnocked ? ImColor(255, 0, 0) : ImColor(255, 255, 255);
            if (!isKnocked) {
                int segments = 60;
                for (int j = 0; j < segments; ++j) {
                    float t = j / float(segments);
                    ImVec2 s = ImLerp(startPoint, ImVec2(headScreen.x, screenHeight - headScreen.y), t);
                    ImVec2 e = ImLerp(startPoint, ImVec2(headScreen.x, screenHeight - headScreen.y), t + 1.0f / segments);
                    draw->AddLine(s, e, lineColor, 1.0f);
                }
            } else {
                draw->AddLine(startPoint, ImVec2(headScreen.x, screenHeight - headScreen.y), lineColor, 0.5f);
            }
        }

        if (EspBox) {
            ImColor boxColor = isKnocked ? ImColor(255, 0, 0) : ImColor(255, 255, 255);
            float lineW = 1.0f;
            float cornerLen = rect.w * 0.20f;
            draw->AddLine({rect.x, rect.y}, {rect.x + cornerLen, rect.y}, boxColor, lineW);
            draw->AddLine({rect.x, rect.y}, {rect.x, rect.y + cornerLen}, boxColor, lineW);
            draw->AddLine({rect.x + rect.w, rect.y}, {rect.x + rect.w - cornerLen, rect.y}, boxColor, lineW);
            draw->AddLine({rect.x + rect.w, rect.y}, {rect.x + rect.w, rect.y + cornerLen}, boxColor, lineW);
            draw->AddLine({rect.x, rect.y + rect.h}, {rect.x + cornerLen, rect.y + rect.h}, boxColor, lineW);
            draw->AddLine({rect.x, rect.y + rect.h}, {rect.x, rect.y + rect.h - cornerLen}, boxColor, lineW);
            draw->AddLine({rect.x + rect.w, rect.y + rect.h}, {rect.x + rect.w - cornerLen, rect.y + rect.h}, boxColor, lineW);
            draw->AddLine({rect.x + rect.w, rect.y + rect.h}, {rect.x + rect.w, rect.y + rect.h - cornerLen}, boxColor, lineW);
        }

        if (EspVida) {
            float maxHealth = get_MaxHP(enemy);
            float currentHealth = GetHp(enemy);
            float hp = (maxHealth > 0.f) ? std::clamp(currentHealth / maxHealth, 0.f, 1.f) : 0.f;

            ImVec4 colorGreen  = {0.f, 1.f, 0.f, 1.f};
            ImVec4 colorYellow = {1.f, 1.f, 0.f, 1.f};
            ImVec4 colorRed    = {1.f, 0.f, 0.f, 1.f};
            ImVec4 hColor = hp > 0.5f
                ? ImLerp(colorYellow, colorGreen, (hp - 0.5f) / 0.5f)
                : ImLerp(colorRed, colorYellow, hp / 0.5f);

            float barW = 3.f;
            ImVec2 barPos(rect.x - barW - 3.f, rect.y);
            float barH = rect.h * hp;
            draw->AddRectFilled(
                {barPos.x, barPos.y + rect.h - barH},
                {barPos.x + barW, barPos.y + rect.h},
                ImColor(hColor));
        }
    }

    if (EspCircle) {
        ImVec2 center = {ImGui::GetIO().DisplaySize.x / 2.f, ImGui::GetIO().DisplaySize.y / 2.f};
        ImGui::GetBackgroundDrawList()->AddCircle(center, Fov_Aim, IM_COL32(255, 255, 255, 255), 64, 1.f);
    }
}
