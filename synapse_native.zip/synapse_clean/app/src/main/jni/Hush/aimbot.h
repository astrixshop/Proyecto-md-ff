// Copyright (c) 2025 @SynapseCheats. All rights reserved.
#pragma once
#include "../KittyMemory/MemoryPatch.hpp"
#include "ESP.h"
#ifndef UNTAG_PTR
#define UNTAG_PTR(p) (reinterpret_cast<void*>((uintptr_t)(p) & 0x00FFFFFFFFFFFFFFull))
#endif

// BUG 3 FIX: Variables declaradas con `inline` (C++17).
//
// PROBLEMA: sin `inline`, cada translation unit que incluya aimbot.h
// (vía ESP.h → importz.h) define su propia copia de estas variables.
// El linker produce "multiple definition of SilentAim" etc. y el build
// falla, o en el mejor caso enlaza la copia incorrecta (comportamiento
// indefinido en runtime). memory.h ya usa el patrón `inline` correcto.
//
// Con `inline`, C++17 garantiza que existe exactamente una definición
// compartida por todas las TUs — mismo valor visto desde cualquier .cpp.

inline bool  SilentAim      = false;
inline bool  SilentHeadshot = false;
inline float SilentFov      = 180.0f;
inline float SilentDist     = 400.0f;
inline bool  AntiReport     = false;
inline bool  AutoSilence    = false;
inline bool  AimBotLegit    = false;
inline bool  AimbotRage     = false;
inline bool  SilentKill     = false;
inline bool  GhostH         = false;
inline bool  TaTuPlayer     = false;
inline bool  PullEnemy      = false;
inline bool  EspGrenade     = false;

// ── Motor de Humanización — Anti-IA Behavioral Detection ────────
// Garena ML server analiza: headshot rate, reaction time, aim linearity.
// Un aimbot perfecto tiene 100% HS rate y 0ms reaction → ban por IA.
// Solución: añadir ruido gaussiano controlado y limitar HS rate.
inline float g_HumanHsRate    = 0.30f;  // máx 30% headshots (humano ~25-35%)
inline int   g_HumanHitCount  = 0;      // contador total de hits
inline int   g_HumanHsCount   = 0;      // contador de headshots

// Simple LCG pseudo-random con seed basado en tiempo (no usa <random>)
static uint32_t g_humanRandSeed = 0;
static inline float humanRand() {
    if (!g_humanRandSeed) g_humanRandSeed = (uint32_t)(uintptr_t)&g_humanRandSeed ^ 0x12345678;
    g_humanRandSeed = g_humanRandSeed * 1664525u + 1013904223u;
    return (float)(g_humanRandSeed >> 16) / 65535.0f;  // [0.0, 1.0]
}

// Ruido gaussiano Box-Muller (simula micro-temblor del dedo humano)
static inline float gaussNoise(float stddev) {
    float u1 = humanRand() * 0.9999f + 0.0001f;
    float u2 = humanRand();
    // Box-Muller transform
    float z = sqrtf(-2.0f * logf(u1)) * cosf(6.28318f * u2);
    return z * stddev;
}

// Decide si este hit debe ser headshot (respeta g_HumanHsRate)
static inline bool shouldHeadshot() {
    g_HumanHitCount++;
    float currentRate = g_HumanHitCount > 0
        ? (float)g_HumanHsCount / (float)g_HumanHitCount
        : 0.0f;
    // Si ya superamos el rate objetivo → forzar chest
    if (currentRate >= g_HumanHsRate) return false;
    // Probabilidad aleatoria ponderada
    bool hs = humanRand() < g_HumanHsRate;
    if (hs) g_HumanHsCount++;
    return hs;
}

// Las variables static de abajo son internas a cada TU — ya son correctas.
static bool   s_hitFlash       = false;
static double s_hitTime        = 0.0;
static bool   s_lastHead       = false;
static bool   s_silencePatch   = false;
static bool   s_toggle         = false;

// ── AutoSilence — silenciar arma via patch ARM64 ─────────────
static uintptr_t s_weaponSilenceOffset = 0;

static MemoryPatch s_silencePatchObj;
static bool        s_silencePatchInited = false;

inline void UpdateAutoSilence() {
    if (AutoSilence == s_silencePatch) return;
    s_silencePatch = AutoSilence;
    // Use offset pre-cached in CacheAllOffsets — never call Il2Cpp from render thread
    if (!s_weaponSilenceOffset)
        s_weaponSilenceOffset = WeaponSilenceOffset;
    uintptr_t addr = s_weaponSilenceOffset;
    if (!addr || !IsGamePtr((void*)addr)) return;
    if (AutoSilence) {
        s_silencePatchObj = MemoryPatch::createWithHex(addr,
            "1F 20 03 D5 1F 20 03 D5 1F 20 03 D5 C0 03 5F D6");
        s_silencePatchInited = true;
        s_silencePatchObj.Modify();
    } else {
        if (s_silencePatchInited) s_silencePatchObj.Restore();
    }
}

// ── Helpers de posición ───────────────────────────────────────
static inline bool IsValidTarget(void* e, void* local) {
    if (!e || e == local || get_IsDieing(e) || !get_MaxHP(e)) return false;
    if (!get_IsBot(e) && get_isLocalTeam(e)) return false;
    return true;
}

static inline Vector3 GetHeadPos(void* p) {
    void* tf = get_HeadBoneTransform(p);
    if (tf) return Transform_GetPosition(tf);
    Vector3 v = getPosition(p); v.y += 1.7f; return v;
}

static inline Vector3 GetChestPos(void* p) {
    void* tf = get_SpineBoneTransform(p);
    if (tf) return Transform_GetPosition(tf);
    Vector3 v = getPosition(p); v.y += 1.1f; return v;
}

// ── Selección de objetivo ─────────────────────────────────────
static void* GetSilentTarget() {
    void* match = Curent_Match(); if (!IsGamePtr(match)) match = nullptr;
    void* local = GetLocalPlayerDirect(); if (!IsGamePtr(local)) local = nullptr;
    if (!match || !local) return nullptr;

    // FIX CRASH: guard ListPlayer antes de desreferenciar
    if (!ListPlayer) return nullptr;
    // FIX: strip tag from match before arithmetic
    match = UNTAG_PTR(match);
    auto* players = *(monoDictionary<uint8_t*, void**>**)((uintptr_t)match + ListPlayer);
    if (!IsGamePtr(players)) return nullptr;
    players = (monoDictionary<uint8_t*, void**>*)UNTAG_PTR(players);

    void*   cam  = Camera_main();
    if (!IsGamePtr(cam)) return nullptr;  // FIX: 0x100000000 passes cam? but crashes
    cam = UNTAG_PTR(cam);
    Vector3 camP = Transform_GetPosition(Component_GetTransform(cam));
    ImVec2  sc   = ImGui::GetIO().DisplaySize;

    float best   = SilentFov * 10.f;
    void* target = nullptr;

    for (int i = 0, n = players->getNumValues(); i < n && i < 64; i++) {
        void* e = players->getValues()[i]; if (!IsGamePtr(e)) { e = nullptr; continue; }
        if (!IsValidTarget(e, local)) continue;
        if (Vector3::Distance(camP, getPosition(e)) > SilentDist) continue;

        Vector3 s = WorldToScreenPoint(cam, getPosition(e));
        if (s.z < 0) continue;

        float dx = s.x - sc.x * 0.5f, dy = s.y - sc.y * 0.5f;
        float ang = sqrtf(dx*dx + dy*dy);
        if (ang < best) { best = ang; target = e; }
    }
    return target;
}

// ── Aplicar desvío de bala ────────────────────────────────────
static void ApplySilentAim() {
    void* local = GetLocalPlayerDirect(); if (!IsGamePtr(local)) local = nullptr;
    if (!local) return;
    void* target = GetSilentTarget();
    if (!target) return;

    using fnAimInfo = void*(*)(void*);
    static uintptr_t s_aimInfoOffset = 0;
    // Use offset pre-cached in CacheAllOffsets — never call Il2Cpp from render thread
    if (!s_aimInfoOffset)
        s_aimInfoOffset = AimInfoFromWeapon;
    if (!s_aimInfoOffset) return;

    void* info = reinterpret_cast<fnAimInfo>(s_aimInfoOffset)(local);
    if (!IsGamePtr(info)) return;  // reject 0x100000000 and similar garbage pointers
    info = UNTAG_PTR(info);

    bool   isBot = get_IsBot(target);
    bool   hitHead;
    Vector3 tPos;

    if (SilentHeadshot) {
        // HUMANIZACION: no siempre headshot — respetar g_HumanHsRate (~30%)
        // Garena ML detecta >70% HS rate como inhumano → ban por IA
        hitHead = shouldHeadshot();
        if (!hitHead) {
            // Apuntar al pecho con micro-ruido gaussiano
            tPos = GetChestPos(target);
        } else {
            tPos = GetHeadPos(target);
            // Bots: alternar para simular imprecision humana
            if (isBot) {
                if (s_toggle) { tPos = GetChestPos(target); hitHead = false; }
                s_toggle = !s_toggle;
            }
        }
    } else {
        tPos = GetChestPos(target); hitHead = false;
    }

    void*   cam  = Camera_main();
    if (!IsGamePtr(cam)) return;  // FIX: 0x100000000 passes cam? but crashes
    cam = UNTAG_PTR(cam);
    Vector3 camP = Transform_GetPosition(Component_GetTransform(cam));

    // HUMANIZACION: añadir micro-ruido gaussiano a la dirección de apuntado
    // Simula el temblor natural del dedo humano en la pantalla táctil
    // std=0.012 rad ≈ 0.7° de imprecision — imperceptible visualmente pero
    // rompe la perfección matemática que detecta la IA de Garena
    Vector3 targetPos = tPos;
    targetPos.x += gaussNoise(0.012f);
    targetPos.y += gaussNoise(0.008f);  // eje Y menos ruido (dedo más estable vert.)
    targetPos.z += gaussNoise(0.012f);

    Vector3 dir = Vector3::Normalized(targetPos - camP);

    *reinterpret_cast<Vector3*>((uintptr_t)info + 0x28) = camP;
    *reinterpret_cast<Vector3*>((uintptr_t)info + 0x34) = dir;

    s_hitFlash = true;
    s_hitTime  = ImGui::GetTime();
    s_lastHead = hitHead;
}

// ── Hit marker ────────────────────────────────────────────────
static void DrawSilentHitMarker(float sw, float sh) {
    if (!s_hitFlash) return;
    float el = (float)(ImGui::GetTime() - s_hitTime);
    if (el > 0.25f) { s_hitFlash = false; return; }
    float   a  = 1.f - (el / 0.25f);
    ImColor col = s_lastHead ? ImColor(255,30,30,(int)(255*a))
                             : ImColor(255,200,0,(int)(235*a));
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    float cx = sw*.5f, cy = sh*.5f, L = 10.f, g = 5.f, t = 1.8f;
    dl->AddLine({cx-L-g,cy},{cx-g,cy},   col,t);
    dl->AddLine({cx+g,cy},{cx+L+g,cy},   col,t);
    dl->AddLine({cx,cy-L-g},{cx,cy-g},   col,t);
    dl->AddLine({cx,cy+g},{cx,cy+L+g},   col,t);
    dl->AddCircleFilled({cx,cy}, 2.f, col);
}

inline void Aimbott() {
    UpdateAutoSilence();
    if (SilentAim) ApplySilentAim();
}
