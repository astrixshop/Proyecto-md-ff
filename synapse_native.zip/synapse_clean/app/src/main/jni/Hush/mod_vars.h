// mod_vars.h — redirige a memory.h (evita ODR violation)
#pragma once
#include "memory.h"
