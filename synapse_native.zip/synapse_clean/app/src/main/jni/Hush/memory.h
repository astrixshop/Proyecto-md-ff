// Copyright (c) 2025 @SynapseCheats. All rights reserved.
#pragma once

// ══════════════════════════════════════════════════════════════════
// memory.h — Variables del proyecto (solo lo que necesita ImGui)
// ══════════════════════════════════════════════════════════════════

// ── Variables del menú ────────────────────────────────────────────
// Estas variables las usa layout.h para renderizar el menú.
// Los valores se definen aquí una sola vez (inline C++17).
// Agrega aquí las variables de tus propios features.

inline bool AimbotEsp      = false;
inline bool aimbotAuto     = false;
inline bool aimbotTrigger  = false;
inline bool Aimbot         = false;
inline bool AimVisible     = false;
inline bool AimSilent      = false;
inline bool ignoreKnockedEnemies = false;
inline float Fov_Aim       = 50.0f;
inline float Aimdis        = 350.0f;
inline int  aimPosition    = 0;
inline int  aimSmoothing   = 0;

inline bool EspBox         = false;
inline bool EspLine        = false;
inline bool EspVida        = false;
inline bool EspCircle      = false;
inline bool EspInfo        = false;
inline int  currentBoxType = 0;

inline const int TOP_LEFT  = 0;
inline const int TOP       = 1;
inline const int BOTTOM    = 2;
inline const int CENTER    = 3;
inline const int DISABLED  = 4;
inline int  currentLinePosition = TOP;

inline bool SpeedHack      = false;
inline bool GhostHack      = false;
inline bool Paraquedas     = false;
inline bool TelekillTeste  = false;
inline bool ResetGuest1    = false;

