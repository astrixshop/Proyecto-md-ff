// Copyright (c) 2025 @SynapseCheats. All rights reserved.
#pragma once

#include <stdio.h>
#include <stdlib.h>
// #include <fcntl.h>  // incluido en imports.h
#include <pthread.h>
#include <math.h>
#include <iostream>
#include <string>
#include <vector>

#include "imgui.h"
#include <imgui_internal.h>
#include <Il2Cpp.h>
#include <Vector3.hpp>
#include <Color.h>
#include "obfuscate.h"
#include "unity.h"
#include "KittyMemory/Deps/Imguii.h"
#include "updates.h"
#include "Rect.h"
#include "imgui_impl_opengl3.h"
#include "mod_vars.h"
#include "others.h"
