// Copyright (c) 2025 @SynapseCheats. All rights reserved.
#pragma once
#include <imgui.h>
#include <string>
#include <chrono>

// ============================================================
// SafeNotif — Overlay pequeño de estado anti-cheat
// Aparece al inicio y se actualiza en tiempo real
// ============================================================

// ── GetBanRisk() — indicador local de riesgo observable desde el proceso ──────
// No hay forma de saber el riesgo real desde el cliente. Esta implementación
// devuelve un valor basado en señales locales observables:
//   - TracerPid != 0  → 90 (debugger/Frida activo — riesgo máximo)
//   - /proc/net/unix  contiene "frida"  → 75 (socket Frida detectado)
//   - /data/local/tmp/frida-server existe → 50 (binario Frida en disco)
//   - Sin señales → 5 (limpio)
static int GetBanRisk() {
    // 1. TracerPid check
    {
        FILE* f = fopen("/proc/self/status", "r");
        if (f) {
            char line[128];
            while (fgets(line, sizeof(line), f)) {
                if (strncmp(line, "TracerPid", 9) == 0) {
                    int pid = 0;
                    sscanf(line + 10, "%d", &pid);
                    if (pid != 0) { fclose(f); return 90; }
                    break;
                }
            }
            fclose(f);
        }
    }
    // 2. Frida socket en /proc/net/unix
    {
        FILE* f = fopen("/proc/net/unix", "r");
        if (f) {
            char line[256];
            while (fgets(line, sizeof(line), f)) {
                if (strstr(line, "frida") || strstr(line, "linjector")) {
                    fclose(f); return 75;
                }
            }
            fclose(f);
        }
    }
    // 3. Binario Frida conocido en disco
    if (access("/data/local/tmp/frida-server", F_OK) == 0 ||
        access("/data/local/tmp/re.frida.server", F_OK) == 0) {
        return 50;
    }
    return 5;
}

// Colores según riesgo
inline ImVec4 GetRiskColor(int risk) {
    if (risk <= 20) return ImVec4(0.0f, 0.9f, 0.3f, 1.0f);  // verde
    if (risk <= 50) return ImVec4(1.0f, 0.8f, 0.0f, 1.0f);  // amarillo
    if (risk <= 75) return ImVec4(1.0f, 0.4f, 0.0f, 1.0f);  // naranja
    return           ImVec4(1.0f, 0.1f, 0.1f, 1.0f);         // rojo
}

inline const char* GetRiskLabel(int risk) {
    if (risk <= 20) return "SEGURO";
    if (risk <= 50) return "PRECAUCION";
    if (risk <= 75) return "RIESGO ALTO";
    return "BAN INMINENTE";
}

void DrawSafeNotif() {
    // Solo mostrar los primeros 6 segundos al entrar, luego siempre visible pequeño
    auto now = std::chrono::steady_clock::now();
    float elapsed = std::chrono::duration<float>(now - notif_start).count();

    // Calcular alpha: fade in 0.5s, visible, nunca desaparece
    float alpha = 1.0f;
    if (elapsed < 0.5f) alpha = elapsed / 0.5f;

inline auto notif_start = std::chrono::steady_clock::now();
    int risk = GetBanRisk();
    ImVec4 riskColor = GetRiskColor(risk);
    const char* riskLabel = GetRiskLabel(risk);

    // ── Posición: esquina superior derecha, pequeño ──────────
    ImGuiIO& io = ImGui::GetIO();
    float padding = 8.0f;
    float width   = 160.0f;
    float height  = 48.0f;
    float posX    = io.DisplaySize.x - width - padding;
    float posY    = padding;

    ImGui::SetNextWindowPos(ImVec2(posX, posY), ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(width, height), ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(0.82f * alpha);

    ImGuiWindowFlags flags =
        ImGuiWindowFlags_NoDecoration   |
        ImGuiWindowFlags_NoInputs        |
        ImGuiWindowFlags_NoNav           |
        ImGuiWindowFlags_NoMove          |
        ImGuiWindowFlags_NoBringToFrontOnFocus;

    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 6.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,  ImVec2(6.0f, 5.0f));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.06f, 0.06f, 0.08f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_Border,   ImVec4(riskColor.x, riskColor.y, riskColor.z, 0.5f));

    if (ImGui::Begin("##SafeNotif", nullptr, flags)) {

        // Línea 1: "MOD MENU SEGURO" o estado
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(
            riskColor.x * alpha,
            riskColor.y * alpha,
            riskColor.z * alpha,
            alpha));
        ImGui::SetWindowFontScale(0.75f);
        ImGui::Text("MOD MENU %s", riskLabel);
        ImGui::PopStyleColor();

        // Línea 2: barra de riesgo
        ImGui::PushStyleColor(ImGuiCol_PlotHistogram, riskColor);
        ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0.15f, 0.15f, 0.15f, 0.8f));
        float riskNorm = risk / 100.0f;
        char overlay[12];
        snprintf(overlay, sizeof(overlay), "%d%%", risk);
        ImGui::ProgressBar(riskNorm, ImVec2(-1.0f, 9.0f), overlay);
        ImGui::PopStyleColor(2);

        ImGui::SetWindowFontScale(1.0f);
    }
    ImGui::End();
    ImGui::PopStyleColor(2);
    ImGui::PopStyleVar(2);
}
