// Copyright (c) 2025 @SynapseCheats. All rights reserved.
#pragma once
inline bool clearMousePos = true;
