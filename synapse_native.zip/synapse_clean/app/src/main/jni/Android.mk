LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE    := hwcomposer.ranchu
LOCAL_CFLAGS    := -O2 -DNDEBUG -fvisibility=hidden -ffunction-sections -fdata-sections -w
LOCAL_CFLAGS    += -fno-rtti -fno-exceptions -fpermissive -Wno-error=format-security
LOCAL_CPPFLAGS  := -O2 -DNDEBUG -fvisibility=hidden -ffunction-sections -fdata-sections -w -s -std=c++17
LOCAL_CPPFLAGS  += -Wno-error=c++11-narrowing -fms-extensions -fno-rtti -fno-exceptions -fpermissive
LOCAL_LDFLAGS   += -Wl,--gc-sections,--strip-all
LOCAL_LDLIBS    := -llog -landroid -lEGL -lGLESv3 -lGLESv2 -lz -ldl

LOCAL_C_INCLUDES += $(LOCAL_PATH)
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Hush
LOCAL_C_INCLUDES += $(LOCAL_PATH)/ZygModule
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Misc
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Misc/Unity
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Misc/update/xdl/include
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Misc/update
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Misc/update/xdl
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Misc/imgui
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Misc/imgui/fonts
LOCAL_C_INCLUDES += $(LOCAL_PATH)/KittyMemory
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Native    # proc_intercept.h, sig_hook.h

FILE_LIST += $(wildcard $(LOCAL_PATH)/KittyMemory/*.c*)
FILE_LIST += $(wildcard $(LOCAL_PATH)/Misc/imgui/*.c*)
FILE_LIST += $(wildcard $(LOCAL_PATH)/Misc/update/*.c*)
FILE_LIST += $(wildcard $(LOCAL_PATH)/Misc/update/xdl/*.c*)
FILE_LIST += $(wildcard $(LOCAL_PATH)/ZygModule/*.c*)
FILE_LIST += $(wildcard $(LOCAL_PATH)/Native/*.c*)     # native_init.cpp

LOCAL_SRC_FILES := $(FILE_LIST:$(LOCAL_PATH)/%=%)

include $(BUILD_SHARED_LIBRARY)
