// Copyright (c) 2026 @SynapseCheat. All rights reserved.
// got_plt_hooks.h — GOT/PLT patch engine + deep anti-report hooks
//
// ARQUITECTURA:
//   Nivel 1 — il2cpp inline hooks (A64InlineHook):
//     CSReportPlayerReq_ctor, ReportPlayer, SendServerRequest,
//     LogReportCheat, LogReportCheatInHistory
//
//   Nivel 2 — GOT/PLT patch en libanogs.so:
//     Parchar la entrada GOT de memcpy en libanogs.so para que cuando
//     el AC lea su propia memoria (para calcular el CRC de integridad)
//     reciba una copia limpia salvada al inicio, ocultando nuestros hooks.
//
// OB53 offsets verificados contra dump:
//   0x5646D10 = proto.CSReportPlayerBehaviorReq.ctor
//   0x4C0E178 = COW.UIHudReportController.b__51_0   (callback)
//   0x4C0ADAC = COW.UIHudReportController.ReportPlayer
//   0xA0A77B0 = Unknown.get_info  (SendServerRequest wrapper)
//   0x6CA2420 = COW.EventLogger.LogReportCheat
//   0x6CA2E28 = COW.EventLogger.LogReportCheatInHistory
//   0xCF320   = libanogs.so — memcpy interceptor del CRC checker
// ─────────────────────────────────────────────────────────────────────
#pragma once

#include <dlfcn.h>
#include <link.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <cstring>
#include <cstdlib>
#include <cstdint>
#include <unistd.h>
#include <atomic>

#include <And64InlineHook.hpp>
#include "obfuscate.h"

// ═══════════════════════════════════════════════════════════════════
// UTILIDADES INTERNAS
// ═══════════════════════════════════════════════════════════════════

// Encuentra la base de una librería via dl_iterate_phdr (sin /proc/self/maps)
static uintptr_t _FindLibBase(const char* frag) {
    struct _F { const char* f; uintptr_t b; } ctx = {frag, 0};
    dl_iterate_phdr([](struct dl_phdr_info* info, size_t, void* raw) -> int {
        auto* c = (_F*)raw;
        if (info->dlpi_name && strstr(info->dlpi_name, c->f)) {
            c->b = (uintptr_t)info->dlpi_addr;
            return 1;
        }
        return 0;
    }, &ctx);
    return ctx.b;
}

// Encuentra el tamaño total de una librería en memoria
static size_t _FindLibSize(const char* frag) {
    struct { const char* frag; uintptr_t lo, hi; } ctx = {frag, ~(uintptr_t)0, 0};
    dl_iterate_phdr([](struct dl_phdr_info* info, size_t, void* raw) -> int {
        auto* c = static_cast<decltype(ctx)*>(raw);
        if (!info->dlpi_name || !strstr(info->dlpi_name, c->frag)) return 0;
        for (const ElfW(Phdr)* ph = info->dlpi_phdr;
             ph < info->dlpi_phdr + info->dlpi_phnum; ph++) {
            if (ph->p_type != PT_LOAD) continue;
            uintptr_t s = (uintptr_t)info->dlpi_addr + ph->p_vaddr;
            uintptr_t e = s + ph->p_memsz;
            if (s < c->lo) c->lo = s;
            if (e > c->hi) c->hi = e;
        }
        return 1;
    }, &ctx);
    return (ctx.lo < ctx.hi) ? (size_t)(ctx.hi - ctx.lo) : 0;
}

// ─────────────────────────────────────────────────────────────────────
// HOOK_LIB: inline hook de función en una librería por RVA
//   lib    = nombre parcial de la librería ("libil2cpp.so")
//   rva    = offset desde la base (como string hex, ej "0x6CA2420")
//   hookFn = nuestra función de reemplazo
//   origFn = puntero donde guardar el original (puede ser nullptr)
// ─────────────────────────────────────────────────────────────────────
#define HOOK_LIB(lib, rva, hookFn, origFn)                              \
    do {                                                                 \
        uintptr_t _b = _FindLibBase(lib);                               \
        if (_b) {                                                        \
            uintptr_t _a = _b + (uintptr_t)strtoull(rva, nullptr, 16); \
            A64HookFunction((void*)_a, (void*)(hookFn),                 \
                            (void**)&(origFn));                         \
        }                                                                \
    } while(0)

#define HOOK_LIB_NO_ORIG(lib, rva, hookFn)                              \
    do {                                                                 \
        uintptr_t _b = _FindLibBase(lib);                               \
        if (_b) {                                                        \
            uintptr_t _a = _b + (uintptr_t)strtoull(rva, nullptr, 16); \
            A64HookFunction((void*)_a, (void*)(hookFn), nullptr);       \
        }                                                                \
    } while(0)

// ═══════════════════════════════════════════════════════════════════
// GOT PATCHER GENÉRICO
// Dado el nombre de una .so y el nombre del símbolo en su GOT,
// reemplaza la entrada por hookFn y guarda el original en origOut.
// Usa dl_iterate_phdr + PT_DYNAMIC → DT_JMPREL (rela.plt).
// ═══════════════════════════════════════════════════════════════════
struct _GotCtx {
    const char* soFrag;
    const char* symName;
    void*       hookFn;
    void**      origOut;
    bool        patched;
};

static bool GotPatchSymbol(const char* soFrag, const char* symName,
                           void* hookFn, void** origOut) {
    _GotCtx ctx = {soFrag, symName, hookFn, origOut, false};

    dl_iterate_phdr([](struct dl_phdr_info* info, size_t, void* raw) -> int {
        auto* c = static_cast<_GotCtx*>(raw);
        if (!info->dlpi_name || !strstr(info->dlpi_name, c->soFrag)) return 0;

        const ElfW(Sym)*  symtab  = nullptr;
        const char*       strtab  = nullptr;
        const ElfW(Rela)* plt_rel = nullptr;
        const ElfW(Rela)* dyn_rel = nullptr;
        size_t            plt_sz  = 0;
        size_t            dyn_sz  = 0;

        for (const ElfW(Phdr)* ph = info->dlpi_phdr;
             ph < info->dlpi_phdr + info->dlpi_phnum; ph++) {
            if (ph->p_type != PT_DYNAMIC) continue;
            auto* dyn = (const ElfW(Dyn)*)(info->dlpi_addr + ph->p_vaddr);
            for (const ElfW(Dyn)* d = dyn; d->d_tag != DT_NULL; d++) {
                switch (d->d_tag) {
                case DT_SYMTAB:  symtab  = (ElfW(Sym)*) (info->dlpi_addr + d->d_un.d_ptr); break;
                case DT_STRTAB:  strtab  = (const char*)(info->dlpi_addr + d->d_un.d_ptr); break;
                case DT_JMPREL:  plt_rel = (ElfW(Rela)*)(info->dlpi_addr + d->d_un.d_ptr); break;
                case DT_PLTRELSZ: plt_sz  = d->d_un.d_val; break;
                case DT_RELA:    dyn_rel = (ElfW(Rela)*)(info->dlpi_addr + d->d_un.d_ptr); break;
                case DT_RELASZ:  dyn_sz  = d->d_un.d_val; break;
                default: break;
                }
            }
            break;
        }
        if (!symtab || !strtab) return 0;

        // Buscar en .rela.plt primero, luego en .rela.dyn
        auto PatchTable = [&symtab, &strtab, &info, &c](const ElfW(Rela)* rels, size_t sz) {
            if (!rels || !sz) return;
            size_t n = sz / sizeof(ElfW(Rela));
            for (size_t i = 0; i < n; i++) {
                uint32_t si = ELF64_R_SYM(rels[i].r_info);
                if (!symtab[si].st_name) continue;
                if (strcmp(strtab + symtab[si].st_name, c->symName) != 0) continue;

                void** got = (void**)(info->dlpi_addr + rels[i].r_offset);
                long ps = sysconf(_SC_PAGESIZE);
                void* pg = (void*)((uintptr_t)got & ~(uintptr_t)(ps - 1));
                if (mprotect(pg, (size_t)ps, PROT_READ | PROT_WRITE) != 0) break;
                if (c->origOut) *c->origOut = *got;
                *got = c->hookFn;
                mprotect(pg, (size_t)ps, PROT_READ);
                c->patched = true;
                break;
            }
        };

        PatchTable(plt_rel, plt_sz);
        if (!c->patched) PatchTable(dyn_rel, dyn_sz);
        return c->patched ? 1 : 0;
    }, &ctx);

    return ctx.patched;
}

// ═══════════════════════════════════════════════════════════════════
// NIVEL 2 — GOT HOOK EN libanogs.so (CRC / 7-day fixer)
//
// libanogs.so es la librería de anti-cheat de Garena que verifica el
// CRC de su propia memoria para detectar hooks inline.
// La función en 0xCF320 es su wrapper de memcpy usado para leer zonas
// del .text y calcular checksums.
//
// FIX: parchamos la GOT entry de "memcpy" en libanogs para que cuando
// libanogs lea su propia memoria, reciba una copia limpia salvada en
// el primer frame (antes de nuestros hooks en libil2cpp.so).
// El AC calcula siempre el CRC correcto → no detecta hooks.
// ═══════════════════════════════════════════════════════════════════
static char*    g_anogsClean   = nullptr; // copia limpia de libanogs
static uintptr_t g_anogsBase   = 0;
static size_t    g_anogsSize   = 0;
static void*   (*g_origMemcpy)(void*, const void*, size_t) = nullptr;

// Hook de memcpy en la GOT de libanogs.so
// Cuando libanogs lee su propia memoria → devolvemos la copia limpia
__attribute__((visibility("hidden")))
static void* _hook_libanogs_memcpy(void* dest, const void* src, size_t n) {
    if (g_anogsBase && g_anogsClean &&
        (uintptr_t)src >= g_anogsBase &&
        (uintptr_t)src <  g_anogsBase + g_anogsSize) {
        // Redirigir al snapshot limpio
        const void* cleanSrc = g_anogsClean + ((uintptr_t)src - g_anogsBase);
        return g_origMemcpy ? g_origMemcpy(dest, cleanSrc, n)
                             : memcpy(dest, cleanSrc, n);
    }
    return g_origMemcpy ? g_origMemcpy(dest, src, n)
                        : memcpy(dest, src, n);
}

// Guardar snapshot limpio de libanogs ANTES de parcharlo
static void _SaveAnogsSnapshot() {
    if (g_anogsClean) return;
    g_anogsBase = _FindLibBase(OBFUSCATE("libanogs.so"));
    if (!g_anogsBase) return;
    g_anogsSize = _FindLibSize(OBFUSCATE("libanogs.so"));
    if (!g_anogsSize) return;
    g_anogsClean = (char*)malloc(g_anogsSize);
    if (g_anogsClean) memcpy(g_anogsClean, (void*)g_anogsBase, g_anogsSize);
}

// ═══════════════════════════════════════════════════════════════════
// NIVEL 1 — INLINE HOOKS EN libil2cpp.so
// ═══════════════════════════════════════════════════════════════════

// ── CSReportPlayerBehaviorReq_ctor (0x5646D10) ─────────────────────
// El constructor del paquete de reporte. Limpiamos los campos clave
// para que el paquete enviado no lleve datos del jugador objetivo.
static void (*oCSReportPlayerReq_ctor)(void*) = nullptr;

__attribute__((visibility("hidden")))
static void hCSReportPlayerReq_ctor(void* inst) {
    if (inst) {
        *(uint64_t*)((uintptr_t)inst + 0x10) = 0; // UID del reportado
        *(uint64_t*)((uintptr_t)inst + 0x20) = 0; // matchID
        void* mp = *(void**)((uintptr_t)inst + 0x28);
        if (mp) *(void**)((uintptr_t)mp + 0x10) = nullptr; // MPCheats
    }
    if (oCSReportPlayerReq_ctor) oCSReportPlayerReq_ctor(inst);
}

// ── ReportPlayer callback (0x4C0E178) ──────────────────────────────
// Callback que se llama cuando el servidor responde al reporte.
// Siempre forzamos errCode=0 (éxito silencioso) — no se reintenta.
static void (*oReportPlayer_Callback)(void*, int, void*) = nullptr;

__attribute__((visibility("hidden")))
static void hReportPlayer_Callback(void* inst, int errCode, void* obj) {
    (void)errCode;
    if (oReportPlayer_Callback) oReportPlayer_Callback(inst, 0, obj);
}

// ── ReportPlayer main (0x4C0ADAC) ──────────────────────────────────
// Función principal que inicia el flujo de reporte. La bloqueamos
// completamente — nada se envía al servidor.
static void (*oReportPlayer_Main)(void*) = nullptr;

__attribute__((visibility("hidden")))
static void hReportPlayer_Main(void* /*inst*/) {
    // Silencio total — no llamar al original
}

// ── SendServerRequest (0xA0A77B0) ───────────────────────────────────
// Wrapper HTTP del juego. Filtramos comandos de reporte/log/seguridad.
static void* (*oSendServerRequest)(void*, void*, void*, void*, float,
                                    uint32_t, bool, int, int, int, bool,
                                    int, void*) = nullptr;

__attribute__((visibility("hidden")))
static void* hSendServerRequest(void* url, void* cmd, void* data,
                                 void* onFinished, float timeout,
                                 uint32_t http_option, bool encrypt,
                                 int loadingType, int priority,
                                 int urgentAfterIndex, bool sendImmediately,
                                 int channel, void* OnDeserialize) {
    if (cmd) {
        // cmd+0x14 es el string del comando HTTP
        const char* cs = (const char*)((uintptr_t)cmd + 0x14);
        if (cs && (strstr(cs, OBFUSCATE("report")) ||
                   strstr(cs, OBFUSCATE("log"))    ||
                   strstr(cs, OBFUSCATE("secure")))) {
            return nullptr; // descartar silenciosamente
        }
    }
    return oSendServerRequest
        ? oSendServerRequest(url, cmd, data, onFinished, timeout,
                             http_option, encrypt, loadingType, priority,
                             urgentAfterIndex, sendImmediately, channel,
                             OnDeserialize)
        : nullptr;
}

// ── LogReportCheat (0x6CA2420) ──────────────────────────────────────
// Sustituye el UID del reportado por un UID fantasma imposible de
// vincular a un jugador real. Los datos de sub-razón se limpian.
static void (*oLogReportCheat)(uint64_t, uint32_t, void*, uint32_t*,
                                bool, uint32_t, int32_t, void*, int32_t) = nullptr;

__attribute__((visibility("hidden")))
static void hLogReportCheat(uint64_t /*cheater*/, uint32_t /*reason*/,
                             void* cheaterPlayerID, uint32_t* subReason,
                             bool inGame, uint32_t reporteeType,
                             int32_t reportScene, void* clientVersion,
                             int32_t reportMethod) {
    constexpr uint64_t kGhostUID = 1000000001ULL;
    if (subReason) { subReason[0] = 0; subReason[1] = 0; }
    if (oLogReportCheat)
        oLogReportCheat(kGhostUID, 0, cheaterPlayerID, subReason,
                        inGame, reporteeType, reportScene,
                        clientVersion, reportMethod);
}

// ── LogReportCheatInHistory (0x6CA2E28) ────────────────────────────
static void (*oLogReportCheatInHistory)(uint64_t, uint32_t, void*,
                                         uint64_t, uint32_t*, uint32_t, void*) = nullptr;

__attribute__((visibility("hidden")))
static void hLogReportCheatInHistory(uint64_t /*cheater*/, uint32_t /*reason*/,
                                      void* stats, uint64_t matchID,
                                      uint32_t* subReason, uint32_t reporteeType,
                                      void* clientVersion) {
    constexpr uint64_t kGhostUID = 1000000001ULL;
    if (subReason) subReason[0] = 0;
    if (oLogReportCheatInHistory)
        oLogReportCheatInHistory(kGhostUID, 0, stats, matchID,
                                 subReason, reporteeType, clientVersion);
}

// ═══════════════════════════════════════════════════════════════════
// ApplyGotPltHooks() — Punto de entrada
// Llamar desde Il2CppThread después de Il2CppAttach + CacheAllOffsets
// ═══════════════════════════════════════════════════════════════════
static bool g_gotHooksDone = false;

static void ApplyGotPltHooks() {
    if (g_gotHooksDone) return;
    g_gotHooksDone = true;

    // ── Nivel 2: GOT hook en libanogs.so ─────────────────────────
    // Guardar snapshot PRIMERO (antes de que libanogs esté parcheado)
    _SaveAnogsSnapshot();
    if (g_anogsBase) {
        // Primero: inline hook de la función en 0xCF320 (wrapper memcpy de libanogs)
        HOOK_LIB_NO_ORIG(OBFUSCATE("libanogs.so"),
                         OBFUSCATE("0xCF320"), _hook_libanogs_memcpy);
        // Segundo: GOT patch de "memcpy" en la tabla de libanogs
        void* libcMemcpy = dlsym(RTLD_DEFAULT, OBFUSCATE("memcpy"));
        (void)libcMemcpy; // guardado en g_origMemcpy por el GOT patcher
        GotPatchSymbol(OBFUSCATE("libanogs.so"),
                       OBFUSCATE("memcpy"),
                       (void*)_hook_libanogs_memcpy,
                       (void**)&g_origMemcpy);
    }

    // ── Nivel 1: inline hooks en libil2cpp.so ────────────────────
    // Packet sanitizer — CSReportPlayerBehaviorReq::ctor
    HOOK_LIB(OBFUSCATE("libil2cpp.so"),
             OBFUSCATE("0x5646D10"),
             hCSReportPlayerReq_ctor, oCSReportPlayerReq_ctor);

    // ReportPlayer callback — siempre devuelve éxito
    HOOK_LIB(OBFUSCATE("libil2cpp.so"),
             OBFUSCATE("0x4C0E178"),
             hReportPlayer_Callback, oReportPlayer_Callback);

    // ReportPlayer main — bloqueo total del flujo
    HOOK_LIB(OBFUSCATE("libil2cpp.so"),
             OBFUSCATE("0x4C0ADAC"),
             hReportPlayer_Main, oReportPlayer_Main);

    // SendServerRequest — filtro de comandos HTTP sensibles
    HOOK_LIB(OBFUSCATE("libil2cpp.so"),
             OBFUSCATE("0xA0A77B0"),
             hSendServerRequest, oSendServerRequest);

    // LogReportCheat — spoof de UID
    HOOK_LIB(OBFUSCATE("libil2cpp.so"),
             OBFUSCATE("0x6CA2420"),
             hLogReportCheat, oLogReportCheat);

    // LogReportCheatInHistory — spoof de UID en histórico
    HOOK_LIB(OBFUSCATE("libil2cpp.so"),
             OBFUSCATE("0x6CA2E28"),
             hLogReportCheatInHistory, oLogReportCheatInHistory);
}
