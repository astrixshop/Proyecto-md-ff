// stealth_impl.cpp — Implementaciones de stealth_full.h
// Este archivo .cpp puede incluir cualquier header C sin conflictos extern "C"

#include <jni.h>
#include <dlfcn.h>
#include <link.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <signal.h>
#include <pthread.h>
#include <sys/prctl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <atomic>
#include <thread>
#include "../ZygModule/And64InlineHook.hpp"
#include "../Misc/obfuscate.h"
#include "stealth_full.h"

static char _g_soName[128] = {};
static int (*_orig_dl_iter)(int(*)(struct dl_phdr_info*,size_t,void*),void*) = nullptr;
struct _DlCtx { int(*cb)(struct dl_phdr_info*,size_t,void*); void* d; };
static int _filter_cb(struct dl_phdr_info* i, size_t s, void* raw) {
    auto* c = static_cast<_DlCtx*>(raw);
    if (i->dlpi_name && _g_soName[0] && strstr(i->dlpi_name, _g_soName)) return 0;
    return c->cb(i, s, c->d);
}
static int _hooked_dl_iter(int(*cb)(struct dl_phdr_info*,size_t,void*), void* d) {
    _DlCtx c = {cb, d}; return _orig_dl_iter(_filter_cb, &c);
}
static std::atomic<bool> _g_wd{false};
static std::atomic<bool> _g_acActive{false};

bool _TracerPidCheck() {
    // FIX: /proc/self/status read generates AVC denied on Android 14. Disabled.
    return false;
}

bool _JdwpCheck() {
    // FIX: /proc/self/net/tcp6 generates AVC denied on Android 14 → Garena ban trigger.
    // This was THE source of 9 AVC denied entries in the logcat. Disabled.
    return false;
}

bool _BreakpointCheck(void* fn) {
    if (!fn) return false;
    uint32_t instr = *reinterpret_cast<volatile uint32_t*>(fn);
    return (instr & 0xFFE0001F) == 0xD4200000;
}

bool _FridaCheck() {
    // FIX: /proc/self/maps generates AVC denied on Android 14. Disabled.
    return false;
}

bool _GotIntegrityCheck() {
    // FIX: /proc/self/maps generates AVC denied on Android 14. Disabled.
    return false;
}

bool _XposedCheck() {
    const char x1[] = {'/','s','y','s','t','e','m','/','f','r','a','m','e','w','o','r','k','/','X','p','o','s','e','d','B','r','i','d','g','e','.','j','a','r','\0'};
    const char x2[] = {'/','d','a','t','a','/','a','d','b','/','m','o','d','u','l','e','s','/','l','s','p','o','s','e','d','\0'};
    const char x3[] = {'/','s','y','s','t','e','m','/','l','i','b','6','4','/','l','i','b','x','p','o','s','e','d','_','a','r','t','.','s','o','\0'};
    const char* p[] = { x1, x2, x3, nullptr };
    for (int i = 0; p[i]; i++) {
        struct stat st;
        if (syscall(__NR_newfstatat, AT_FDCWD, p[i], &st, 0) == 0) return true;
    }
    return false;
}

void _UnlinkFromLinkMap(const char* soName) {
    const char rd[] = {'_','r','_','d','e','b','u','g','\0'};
    struct r_debug* dbg = reinterpret_cast<struct r_debug*>(dlsym(RTLD_DEFAULT, rd));
    if (!dbg || !dbg->r_map) return;
    struct link_map* m = dbg->r_map;
    while (m) {
        if (m->l_name && strstr(m->l_name, soName)) {
            if (m->l_prev) m->l_prev->l_next = m->l_next;
            if (m->l_next) m->l_next->l_prev = m->l_prev;
            m->l_name[0] = '\0'; break;
        }
        m = m->l_next;
    }
}

void _ProtectCodePages(const char* soName) {
    // FIX: /proc/self/maps read generates AVC denied on Android 14 → Garena detects.
    // Use dl_iterate_phdr instead — kernel interface, no /proc read, no SELinux audit.
    struct _Ctx { const char* name; } ctx = { soName };
    dl_iterate_phdr([](struct dl_phdr_info* info, size_t, void* raw) -> int {
        auto* c = static_cast<_Ctx*>(raw);
        if (!info->dlpi_name || !strstr(info->dlpi_name, c->name)) return 0;
        for (int i = 0; i < info->dlpi_phnum; i++) {
            const ElfW(Phdr)& ph = info->dlpi_phdr[i];
            if (ph.p_type != PT_LOAD) continue;
            uintptr_t s = info->dlpi_addr + ph.p_vaddr;
            if (s && ph.p_filesz > 0)
                mlock(reinterpret_cast<void*>(s), ph.p_filesz);
        }
        return 1;
    }, &ctx);
}

bool _RootCheck() {
    const char s1[] = {'/','s','y','s','t','e','m','/','b','i','n','/','s','u','\0'};
    const char s2[] = {'/','s','y','s','t','e','m','/','x','b','i','n','/','s','u','\0'};
    const char s3[] = {'/','s','b','i','n','/','s','u','\0'};
    const char s4[] = {'/','d','a','t','a','/','l','o','c','a','l','/','s','u','\0'};
    const char* b[] = { s1, s2, s3, s4, nullptr };
    for (int i = 0; b[i]; i++) {
        struct stat st;
        if (syscall(__NR_newfstatat, AT_FDCWD, b[i], &st, 0) == 0) return true;
    }
    return false;
}

bool _MagiskCheck() {
    // FIX: reading /proc/*/cmdline generates AVC denied on Android 14.
    // Disabled — not needed since UnsafeEnvironment() already returns false.
    return false;
}


bool _EmulatorCheck() {
    int sig = 0;
    const char cpu[] = {'/','p','r','o','c','/','c','p','u','i','n','f','o','\0'};
    FILE* f = fopen(cpu, "r");
    if (f) {
        const char gf[] = {'g','o','l','d','f','i','s','h','\0'};
        const char rc[] = {'r','a','n','c','h','u','\0'};
        const char vb[] = {'v','b','o','x','\0'};
        char l[256];
        while (fgets(l,sizeof(l),f))
            if (strstr(l,gf)||strstr(l,rc)||strstr(l,vb)) {sig++; break;}
        fclose(f);
    }
    const char qe[] = {'/','d','e','v','/','s','o','c','k','e','t','/','q','e','m','u','d','\0'};
    const char qp[] = {'/','d','e','v','/','q','e','m','u','_','p','i','p','e','\0'};
    const char* ep[] = { qe, qp, nullptr };
    for (int i=0;ep[i];i++) {
        struct stat st;
        if (stat(ep[i],&st)==0) { sig++; break; }
    }
    return sig >= 2;
}

bool _HackAppsCheck() {
    const char h1[] = {'/','d','a','t','a','/','a','p','p','/','c','o','m','.','g','a','m','e','g','u','a','r','d','i','a','n','.','a','p','p','\0'};
    const char h2[] = {'/','d','a','t','a','/','a','p','p','/','c','o','m','.','z','u','n','e','.','g','a','m','e','k','i','l','l','e','r','\0'};
    const char h3[] = {'/','d','a','t','a','/','a','p','p','/','o','r','g','.','s','b','t','o','o','l','s','.','g','a','m','e','h','a','c','k','\0'};
    const char h4[] = {'/','d','a','t','a','/','a','p','p','/','c','o','m','.','c','i','h','.','g','a','m','e','_','c','i','h','\0'};
    const char* apps[] = { h1, h2, h3, h4, nullptr };
    for (int i=0; apps[i]; i++) {
        DIR* d = opendir(apps[i]);
        if (d) { closedir(d); return true; }
    }
    return false;
}

float HumanizeAim(float angle) {
    float n = ((float)(rand() % 60) - 30) * 0.01f;
    return angle + n;
}

void HumanDelay() {
    int ms = 50 + (rand() % 70);
    usleep(ms * 1000);
}

void ScrubMemory(void* buf, size_t len) {
    volatile uint8_t* p = reinterpret_cast<volatile uint8_t*>(buf);
    for (size_t i = 0; i < len; i++) p[i] = (uint8_t)(rand() & 0xFF);
    for (size_t i = 0; i < len; i++) p[i] = 0;
    __asm__ __volatile__("" ::: "memory");
}

static void* _WatchdogThread(void*) {
    // FIX: thread name changed to avoid matching real kernel kworker patterns
    // that SELinux audits. Name must be <= 15 chars.
    const char tn[] = {'m','e','d','i','a','.','c','o','d','e','c','\0'};
    pthread_setname_np(pthread_self(), tn);
    // FIX: removed _TracerPidCheck/_FridaCheck/_JdwpCheck — these read /proc/self/status
    // and /proc/self/maps which generate AVC denied audit logs on Android 14+.
    // Garena reads the audit log to detect mod presence. Cuban Mods has zero AVC denials.
    // The watchdog now only sleeps — decoy thread with no /proc reads.
    while (_g_wd.load()) {
        usleep((uint32_t)(15000 + rand() % 10000) * 1000u);
    }
    return nullptr;
}

void _StartWatchdog() {
    if (_g_wd.exchange(true)) return;
    pthread_t t; pthread_attr_t a;
    pthread_attr_init(&a);
    pthread_attr_setdetachstate(&a, PTHREAD_CREATE_DETACHED);
    pthread_create(&t, &a, _WatchdogThread, nullptr);
    pthread_attr_destroy(&a);
}

static void _MonitorAC(); // forward declaration
void StealthInit(const char* soName) {
    strncpy(_g_soName, soName, sizeof(_g_soName)-1);
    _UnlinkFromLinkMap(soName);
    _MonitorAC();
    _ProtectCodePages(soName);
    _StartWatchdog();
}

bool UnsafeEnvironment() {
    // FIX: _TracerPidCheck and _FridaCheck read /proc/self/status and /proc/self/maps
    // On Android 14 these generate AVC denied audit logs visible to Garena's AC.
    // Disabled — integrity_bypass.h hooks libthor which is the real protection.
    return false;
}

void _MonitorAC() {
    _g_acActive.store(false);
}

bool IsACScanActive() { return _g_acActive.load(); }

void _SetSurfaceSecure(JavaVM* jvm) {
    if (!jvm) return;
    JNIEnv* env = nullptr;
    bool needsDetach = false;
    jint getEnvResult = jvm->GetEnv((void**)&env, JNI_VERSION_1_6);
    if (getEnvResult == JNI_EDETACHED) {
        if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        needsDetach = true;
    } else if (getEnvResult != JNI_OK || env == nullptr) {
        return;
    }
    jclass atCls = env->FindClass(OBFUSCATE("android/app/ActivityThread"));
    if (!atCls) { if (needsDetach) jvm->DetachCurrentThread(); return; }
    jmethodID curAt = env->GetStaticMethodID(atCls,
        OBFUSCATE("currentActivityThread"),
        OBFUSCATE("()Landroid/app/ActivityThread;"));
    if (!curAt) { env->DeleteLocalRef(atCls); if (needsDetach) jvm->DetachCurrentThread(); return; }
    jobject at = env->CallStaticObjectMethod(atCls, curAt);
    if (!at) { env->DeleteLocalRef(atCls); if (needsDetach) jvm->DetachCurrentThread(); return; }
    jmethodID getApp = env->GetMethodID(atCls,
        OBFUSCATE("getApplication"),
        OBFUSCATE("()Landroid/app/Application;"));
    if (!getApp) { env->DeleteLocalRef(at); env->DeleteLocalRef(atCls); if (needsDetach) jvm->DetachCurrentThread(); return; }
    jobject app = env->CallObjectMethod(at, getApp);
    if (app) env->DeleteLocalRef(app);
    env->DeleteLocalRef(at);
    env->DeleteLocalRef(atCls);
    if (needsDetach) jvm->DetachCurrentThread();
}

