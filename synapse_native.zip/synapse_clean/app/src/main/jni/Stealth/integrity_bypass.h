#pragma once
// ════════════════════════════════════════════════════════════════════
// integrity_bypass.h — Bypass nativo de checksum + Play Integrity
//
// VECTOR A — Checksum mismatch nativo:
//   libtp2/libtersafe2/libGameSafe cargan DESPUÉS de nuestro .so.
//   Un watchdog las espera y hookea sus exports de verificación
//   de integridad para que siempre devuelvan "genuino".
//
// VECTOR B — APK memory lock:
//   Antes de que el AC mapee el APK en RAM para calcular su hash,
//   hacemos mlock de las páginas ya mapeadas. Si el AC mapea vía
//   mmap+read, obtiene lo que ya está en página (consistente).
//
// VECTOR C — JNI callback intercept:
//   libtp2 registra JNI callbacks para reportar fallos al servidor.
//   Hook de RegisterNatives para interceptar esas rutas.
// ════════════════════════════════════════════════════════════════════

// FIX LINKER: NO hacer undef de __BEGIN_DECLS aquí.
// El undef anterior convertía dlopen/dlsym/dlclose/dl_iterate_phdr
// en símbolos C++ (mangled) en vez de C, causando "undefined reference"
// en el linker aunque -ldl esté presente.
// imports.h ya garantiza que C++ std headers van primero — no hace falta
// neutralizar __BEGIN_DECLS en este punto.
#include <dlfcn.h>
#include <link.h>
#include <sys/syscall.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <cstring>
#include <stdarg.h>
#include <cstdio>
#include <cstdlib>
#include <atomic>
#include "../ZygModule/And64InlineHook.hpp"
#include "../Misc/obfuscate.h"
// Stealth: silence all log output
#ifdef __android_log_print
#undef __android_log_print
#endif
#define __android_log_print(p, t, ...) ((void)0)


// ─────────────────────────────────────────────────────────────────────
// STUBS — firma compatible con AArch64 (hasta 8 args void*)
// Necesario porque And64InlineHook escribe un trampoline que preserva
// los argumentos — la firma del stub debe aceptar todos los registros.
// ─────────────────────────────────────────────────────────────────────
__attribute__((visibility("hidden")))
static int64_t _ib_genuine(void*,void*,void*,void*,void*,void*,void*,void*) {
    return 1; // 1 = genuine / clean / ok
}
__attribute__((visibility("hidden")))
static int64_t _ib_notdetected(void*,void*,void*,void*,void*,void*,void*,void*) {
    return 0; // 0 = "nada detectado" para callbacks de flags de hack
}

// ─────────────────────────────────────────────────────────────────────
// VECTOR A — Hookear exports de integridad en librerías AC
// Lista de símbolos exportados por libtp2 / libtersafe2 / libGameSafe
// Nombres como arrays de char — sin literales en .rodata
// ─────────────────────────────────────────────────────────────────────
struct _IbSym {
    const char* name;
    void*       stub;   // qué reemplazamos por qué stub
};

static const _IbSym k_IbSyms[] = {
    // ── libtp2 / TP2 AntiCheat SDK ────────────────────────────────
    { "Tp2_IsGenuine",                          (void*)_ib_genuine    },
    { "Tp2_AntiCheatSdk_IsGenuine",             (void*)_ib_genuine    },
    { "Tp2_AntiCheatSdk_Init",                  (void*)_ib_genuine    },
    { "tp2_anit_hack_sdk_is_genuine",           (void*)_ib_genuine    },
    { "tp2_anit_hack_sdk_init",                 (void*)_ib_genuine    },
    { "Tp2_SetGameInfo",                        (void*)_ib_genuine    },
    { "Tp2_CheckAntiCheat",                     (void*)_ib_genuine    },
    { "Tp2_GetSdkCallback",                     (void*)_ib_notdetected },
    { "Tp2_OnGetSdkCallback",                   (void*)_ib_notdetected },
    // ── libtersafe2 / TerSafe ────────────────────────────────────
    { "TERSAFE_AntiCheatCheck",                 (void*)_ib_genuine    },
    { "tersafe_is_genuine",                     (void*)_ib_genuine    },
    { "tersafe_check_result",                   (void*)_ib_genuine    },
    { "TERSAFE_Init",                           (void*)_ib_genuine    },
    { "TERSAFE_UnInit",                         (void*)_ib_genuine    },
    // ── libGameSafe / Garena ATSAPI ──────────────────────────────
    { "GameSafe_IsGenuine",                     (void*)_ib_genuine    },
    { "GameSafe_AntiCheatCheck",                (void*)_ib_genuine    },
    { "GameSafe_Init",                          (void*)_ib_genuine    },
    { "ATSAPI_IsGenuine",                       (void*)_ib_genuine    },
    { "ATSAPI_Init",                            (void*)_ib_genuine    },
    { "ATSAPI_CheckResult",                     (void*)_ib_genuine    },
    { nullptr, nullptr }
};

// ─────────────────────────────────────────────────────────────────────
// VECTOR D — Hook libthor_utils.so (SWPT.Thor / Garena native AC)
// Thor usa __android_log_print para reportar "report_info 3 <crc> <offset>"
// al servidor. Hookeamos __android_log_print en libthor para suprimir
// el reporte de status!=0 (APK modificado).
// También hookeamos el símbolo interno checkSignMem_report si existe.
// ─────────────────────────────────────────────────────────────────────
// ── Silenciar Thor: GOT patch en libthor_utils.so ───────────────────────────
// NO hookear __android_log_print globalmente — Il2Cpp también lo usa y el
// va_list handler crashea con strlen en punteros inválidos (SIGSEGV en strlen).
// Parcheamos SOLO la GOT de libthor con un noop. Nadie más se ve afectado.
static int _thor_log_noop(int, const char*, const char*, ...) { return 0; }

static void _HookThorLog(const char* /*thorPath*/) {
    const char ll[] = {'l','i','b','l','o','g','.','s','o','\0'};
    void* logLib = dlopen(ll, RTLD_NOW | RTLD_NOLOAD);
    if (!logLib) return;
    const char lp[] = {'_','_','a','n','d','r','o','i','d','_','l','o','g','_','p','r','i','n','t','\0'};
    void* logSym = dlsym(logLib, lp);
    dlclose(logLib);
    if (!logSym) return;
    const char pm[] = {'/','p','r','o','c','/','s','e','l','f','/','m','a','p','s','\0'};
    int mfd = open(pm, O_RDONLY);
    if (mfd < 0) return;
    char mapbuf[65536]; ssize_t mn = read(mfd, mapbuf, sizeof(mapbuf)-1);
    close(mfd);
    if (mn <= 0) return;
    mapbuf[mn] = '\0';
    const char tf[] = {'t','h','o','r','_','u','t','i','l','s','\0'};
    char line[256]; int pos = 0;
    for (int i = 0; i <= mn; i++) {
        char c = (i < mn) ? mapbuf[i] : '\n';
        if (c == '\n' && pos > 0) {
            line[pos] = '\0'; pos = 0;
            if (!strstr(line, tf) || line[19] != 'w') continue;
            uintptr_t s = 0, e = 0;
            sscanf(line, "%lx-%lx", &s, &e);
            if (!s || e <= s) continue;
            long ps = sysconf(_SC_PAGESIZE);
            mprotect((void*)(s&~(ps-1)), e-(s&~(ps-1)), PROT_READ|PROT_WRITE);
            uintptr_t* ptr = (uintptr_t*)s;
            for (uintptr_t j = 0; j < (e-s)/sizeof(uintptr_t); j++)
                if (ptr[j] == (uintptr_t)logSym) ptr[j] = (uintptr_t)_thor_log_noop;
            mprotect((void*)(s&~(ps-1)), e-(s&~(ps-1)), PROT_READ);
        } else if (pos < 255) { line[pos++] = c; }
    }
}

// Hookear todos los symbols de k_IbSyms en una librería ya cargada
static void _HookAcLib(const char* soPath) {
    if (!soPath || !soPath[0]) return;
    void* h = dlopen(soPath, RTLD_NOW | RTLD_NOLOAD);
    if (!h) return;
    for (int i = 0; k_IbSyms[i].name; i++) {
        void* sym = dlsym(h, k_IbSyms[i].name);
        if (sym) A64HookFunction(sym, k_IbSyms[i].stub, nullptr);
    }
    dlclose(h);
}

// ─────────────────────────────────────────────────────────────────────
// VECTOR C — Hook de JNIEnv::RegisterNatives
// libtp2 registra sus callbacks via RegisterNatives. Interceptamos
// para sustituir los native que reportan fallo al servidor.
// ─────────────────────────────────────────────────────────────────────
static jint (*_orig_RegisterNatives)(JNIEnv*, jclass, const JNINativeMethod*, jint) = nullptr;

// Nombres de métodos nativos del AC que reportan detecciones
// Comparamos por prefijo para cubrir todas las versiones de libtp2
static bool _IsAcReportMethod(const char* name) {
    if (!name) return false;
    const char* prefixes[] = {
        "nativeOnAnticheat",
        "nativeReport",
        "nativeSendCheatLog",
        "onCheatDetected",
        "nativeCheatCallback",
        "nativeGetSdkCallback",
        "nativeTp2Callback",
        "nativeATSCallback",
        nullptr
    };
    for (int i = 0; prefixes[i]; i++)
        if (strncmp(name, prefixes[i], strlen(prefixes[i])) == 0)
            return true;
    return false;
}

// Stub JNI — signature universal para callbacks del AC
static void _jni_ac_noop(JNIEnv*, jobject, ...) {}

static jint _hooked_RegisterNatives(JNIEnv* env, jclass clazz,
                                    const JNINativeMethod* methods, jint nMethods) {
    if (!methods || nMethods <= 0)
        return _orig_RegisterNatives(env, clazz, methods, nMethods);

    // Crear copia mutable en el stack (máx 64 métodos — suficiente para libtp2)
    JNINativeMethod patched[64];
    int count = nMethods < 64 ? nMethods : 64;
    memcpy(patched, methods, count * sizeof(JNINativeMethod));

    for (int i = 0; i < count; i++) {
        if (_IsAcReportMethod(patched[i].name)) {
            patched[i].fnPtr = (void*)_jni_ac_noop;
        }
    }
    return _orig_RegisterNatives(env, clazz, patched, count);
}

// Instalar hook sobre RegisterNatives de libart.so
static void _HookRegisterNatives() {
    if (_orig_RegisterNatives) return;
    const char la[] = {'l','i','b','a','r','t','.','s','o','\0'};
    void* art = dlopen(la, RTLD_NOW | RTLD_NOLOAD);
    if (!art) return;
    const char rn[] = {'R','e','g','i','s','t','e','r','N','a','t','i','v','e','s','\0'};
    void* sym = dlsym(art, rn);
    if (sym) A64HookFunction(sym, (void*)_hooked_RegisterNatives,
                             (void**)&_orig_RegisterNatives);
    dlclose(art);
}

// ─────────────────────────────────────────────────────────────────────
// VECTOR B — mlock de páginas del APK en RAM
// Después de mlock, aunque el AC llame mmap sobre el APK,
// el kernel sirve las páginas ya en caché (no relee del disco).
// ─────────────────────────────────────────────────────────────────────
static void _MlockApkPages(const char* apkPath) {
    if (!apkPath || !apkPath[0]) return;
    const char pm[] = {'/','p','r','o','c','/','s','e','l','f','/','m','a','p','s','\0'};
    int fd = (int)syscall(__NR_openat, AT_FDCWD, pm, O_RDONLY, 0);
    if (fd < 0) return;
    char buf[65536]; ssize_t n = read(fd, buf, sizeof(buf)-1);
    close(fd);
    if (n <= 0) return;
    buf[n] = '\0';
    // Solo páginas de lectura (r--p y r-xp) del APK
    char line[256]; int pos = 0;
    for (int i = 0; i <= n; i++) {
        char c = (i < n) ? buf[i] : '\n';
        if (c == '\n' && pos > 0) {
            line[pos] = '\0'; pos = 0;
            if (!strstr(line, apkPath)) continue;
            uintptr_t s = 0, e = 0;
            sscanf(line, "%lx-%lx", &s, &e);
            if (s && e > s) mlock(reinterpret_cast<void*>(s), e - s);
        } else if (pos < 255) { line[pos++] = c; }
    }
}

// ─────────────────────────────────────────────────────────────────────
// WATCHDOG — espera a que las librerías AC carguen
// ─────────────────────────────────────────────────────────────────────
static std::atomic<bool> g_ibRunning{false};

struct _IbLib { const char* frag; bool hooked; };

static void* _IbWatchThread(void*) {
    const char f1[] = {'t','p','2','\0'};
    const char f2[] = {'t','e','r','s','a','f','e','\0'};
    const char f3[] = {'G','a','m','e','S','a','f','e','\0'};
    const char f4[] = {'A','T','S','A','P','I','\0'};
    const char f5[] = {'t','h','o','r','_','u','t','i','l','s','\0'};

    _IbLib libs[] = {
        {f1, false}, {f2, false}, {f3, false}, {f4, false}, {f5, false}, {nullptr, false}
    };

    // FIX: libthor_utils.so carga en namespace AISLADO clns-7 (ClassLoader Java).
    // dl_iterate_phdr() SOLO ve el namespace linker global — NUNCA ve clns-7.
    // Solución: leer /proc/self/maps directamente via syscall — el kernel lista
    // TODOS los .so de TODOS los namespaces sin excepción.
    const char pm[] = {'/','p','r','o','c','/','s','e','l','f','/','m','a','p','s','\0'};
    const char th[] = {'t','h','o','r','\0'};

    for (int pass = 0; pass < 600 && g_ibRunning.load(); pass++) {
        if (pass > 0) usleep(500000);

        // Leer /proc/self/maps línea por línea via syscall (sin libc stdio)
        int fd = syscall(__NR_openat, AT_FDCWD, pm, O_RDONLY, 0);
        if (fd < 0) continue;

        char line[512]; int pos = 0; char c;
        while (syscall(__NR_read, fd, &c, 1) == 1) {
            if (c == '\n' && pos > 0) {
                line[pos] = '\0'; pos = 0;
                // Buscar cada fragmento de librería AC en la línea del mapa
                for (int i = 0; libs[i].frag; i++) {
                    if (!libs[i].hooked && strstr(line, libs[i].frag)) {
                        // Extraer la ruta: última columna de la línea del mapa
                        // Formato: "addr-addr perms offset dev inode /ruta/lib.so"
                        const char* path = nullptr;
                        int spaces = 0;
                        for (int j = 0; line[j]; j++) {
                            if (line[j] == ' ' || line[j] == '\t') {
                                while (line[j+1] == ' ' || line[j+1] == '\t') j++;
                                spaces++;
                                if (spaces == 5) { path = &line[j+1]; break; }
                            }
                        }
                        if (path && path[0] == '/') {
                            _HookAcLib(path);
                            if (strstr(libs[i].frag, th)) _HookThorLog(path);
                            libs[i].hooked = true;
                        }
                    }
                }
            } else if (c != '\n' && pos < (int)sizeof(line) - 2) {
                line[pos++] = c;
            }
        }
        syscall(__NR_close, fd);
    }
    g_ibRunning.store(false);
    return nullptr;
}

// ─────────────────────────────────────────────────────────────────────
// INIT PRINCIPAL — llamar desde FreeFire() ANTES de Il2CppAttach
// apkPath: ruta al APK del juego (ej: /data/app/com.dts.freefiremax-xxx/base.apk)
// ─────────────────────────────────────────────────────────────────────
static void IntegrityBypassInit(const char* apkPath) {
    // Vector B — lock de páginas del APK
    if (apkPath) _MlockApkPages(apkPath);

    // Vector C — hook RegisterNatives para interceptar callbacks del AC
    _HookRegisterNatives();

    // Vector A watchdog — hookear libtp2 cuando cargue
    if (!g_ibRunning.exchange(true)) {
        pthread_t t; pthread_attr_t a;
        pthread_attr_init(&a);
        pthread_attr_setdetachstate(&a, PTHREAD_CREATE_DETACHED);
        pthread_create(&t, &a, _IbWatchThread, nullptr);
        pthread_attr_destroy(&a);
    }
}
