#pragma once
// stealth_full.h — Solo declaraciones para AIDE NDK r12
#include <jni.h>

bool _TracerPidCheck();
bool _JdwpCheck();
bool _BreakpointCheck(void* fn);
bool _FridaCheck();
bool _GotIntegrityCheck();
bool _XposedCheck();
void _UnlinkFromLinkMap(const char* soName);
bool _RootCheck();
bool _MagiskCheck();
bool _EmulatorCheck();
bool _HackAppsCheck();
float HumanizeAim(float angle);
void HumanDelay();
void ScrubMemory(void* buf, size_t len);
void _StartWatchdog();
void StealthInit(const char* soName);
bool UnsafeEnvironment();
void _SetSurfaceSecure(JavaVM* jvm);
