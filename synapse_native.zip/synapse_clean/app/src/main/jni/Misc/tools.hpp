#pragma once

// Pure C headers only — this file is included before C++ std headers
#include <sys/un.h>
#include <fcntl.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <inttypes.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

typedef unsigned long ulong;

inline uintptr_t get_module_base(int pid, const char *module_name)
{
FILE *fp;
uintptr_t addr = 0;
char *pch;
char filename[32];
char line[1024];
snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);
fp = fopen(filename, "r");
if (fp != NULL)
{
while (fgets(line, sizeof(line), fp))
{
if (strstr(line, module_name))
{
pch = strtok(line, "-");
addr = (uintptr_t)strtoul(pch, NULL, 16);
break;
}
}
fclose(fp);
}
return addr;
}

inline long findLibrary(const char *library) {
char filename[0xff];
char buffer[1024];
FILE *fp = NULL;
long address = 0;
memset(filename, 0, sizeof(filename));
memset(buffer, 0, sizeof(buffer));
snprintf(filename, sizeof(filename), "/proc/self/maps");
fp = fopen(filename, "rt");
if (fp == NULL) goto done;
while (fgets(buffer, sizeof(buffer), fp)) {
if (strstr(buffer, library)) {
address = (long)strtoul(buffer, NULL, 16);
goto done;
}
}
done:
if (fp) fclose(fp);
return address;
}

inline uintptr_t getLibraryLoaded(const char *libraryName) {
char line[512];
memset(line, 0, sizeof(line));
FILE *file = fopen("/proc/self/maps", "rt");
if (file != NULL) {
while (fgets(line, sizeof(line), file)) {
if (strstr(line, libraryName)) {
fclose(file);
return 1;
}
}
fclose(file);
}
return 0;
}

static long ClibBase;
inline long getAbsoluteAddress(const char *libraryName, long relativeAddr) {
if (ClibBase == 0) ClibBase = findLibrary(libraryName);
return ClibBase + relativeAddr;
}
