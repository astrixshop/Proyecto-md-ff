// Copyright (c) 2025 @SynapseCheats. All rights reserved.
#pragma once

// ════════════════════════════════════════════════════════════════════
// imports.h — AIDE NDK r12 compatible
//
// REGLA CRÍTICA PARA AIDE NDK:
//   C++ std headers (<string>, <vector>, namespace std) deben ir
//   PRIMERO — antes de CUALQUIER C header que use __BEGIN_DECLS.
//
//   Si los C headers van primero, sus __BEGIN_DECLS = extern "C" {
//   quedan en contexto cuando llega <string> que intenta abrir
//   namespace std → "namespaces can only be defined in global scope"
//   o "expected unqualified-id" en __BEGIN_DECLS → 97+ errores.
//
//   Orden correcto: C++ std → C system → project headers
// ════════════════════════════════════════════════════════════════════

// ── 1. C++ std headers PRIMERO (antes de cualquier C header) ─────
// C++ std headers
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <chrono>
#include <string>
#include <vector>
#include <iostream>
#include <sstream>
// #include <thread>  // desactivado: -fno-exceptions + std::thread = UB
// #include <mutex>   // desactivado: mismo motivo
#include <atomic>

// ── 2. C system headers — DESPUÉS de C++ std ─────────────────────
// Neutralize __BEGIN_DECLS before C system headers on AIDE NDK
// __BEGIN_DECLS: no neutralizar — dlopen/prctl/sleep necesitan extern C
#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>
#include <math.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <inttypes.h>

// ── 3. Project utility headers ────────────────────────────────────
#include <obfuscate.h>
#include <tools.hpp>
#include <And64InlineHook.hpp>

// ── 4. Project headers que necesitan C++ types ───────────────────
#include <unity.h>
#include <Il2Cpp.h>
