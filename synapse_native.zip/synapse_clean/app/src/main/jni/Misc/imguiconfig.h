#pragma once

// imguiconfig.h — setup de ImGui + EGL state
// Limpiado: eliminado dead code (hook_input, hook_getWidth/Height,
// density nunca inicializado, font/config globals sin uso, prevWidth/Height,
// UpdateSpeedhack no-op, structs de input hook).

#include "imgui_impl_opengl3.h"
#include "imgui_impl_android.h"
#include "palatino.h"
#include <imgui.h>
#include <imgui_internal.h>
#include "mod_vars.h"

// Estado EGL — dimensiones del surface actual
struct {
    bool setup;
    int  width;
    int  height;
} egl;

// Structs de UnityEngine para acceso a input táctil vía Il2Cpp
struct UnityEngine_Vector2_Fields { float x; float y; };
struct UnityEngine_Vector2_o      { UnityEngine_Vector2_Fields fields; };

enum TouchPhase {
    Began = 0, Moved = 1, Stationary = 2, Ended = 3, Canceled = 4
};

struct UnityEngine_Touch_Fields {
    int32_t                    m_FingerId;
    UnityEngine_Vector2_o      m_Position;
    UnityEngine_Vector2_o      m_RawPosition;
    UnityEngine_Vector2_o      m_PositionDelta;
    float                      m_TimeDelta;
    int32_t                    m_TapCount;
    int32_t                    m_Phase;
    int32_t                    m_Type;
    float                      m_Pressure;
    float                      m_maximumPossiblePressure;
    float                      m_Radius;
    float                      m_RadiusVariance;
    float                      m_AltitudeAngle;
    float                      m_AzimuthAngle;
};

// ── SetupImgui ────────────────────────────────────────────────────
// Llamado una sola vez desde hook_eglSwapBuffers cuando el surface
// ya tiene dimensiones válidas.
static bool g_IsSetup = false;

inline void SetupImgui(const char* glsl_version = "#version 300 es") {
    if (g_IsSetup) return;
    g_IsSetup = true;

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();

    io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange;
    io.DisplaySize  = ImVec2((float)egl.width, (float)egl.height);

    ImGui::StyleColorsDark();
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding    = 4.0f;
    style.FrameRounding     = 2.0f;
    style.ScrollbarRounding = 0.0f;
    style.WindowTitleAlign  = ImVec2(0.5f, 0.5f);
    style.FramePadding      = ImVec2(8.0f, 6.0f);

    ImGui_ImplOpenGL3_Init(glsl_version);
    ImGui_ImplAndroid_Init(nullptr);

    // Cargar fuente principal desde datos embebidos (palatino.h)
    ImFontConfig font_cfg;
    io.Fonts->AddFontFromMemoryTTF(
        (void*)khoanguyen_data, khoanguyen_size,
        27.0f, &font_cfg,
        io.Fonts->GetGlyphRangesCyrillic());
}
