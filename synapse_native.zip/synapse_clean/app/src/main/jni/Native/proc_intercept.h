// ══════════════════════════════════════════════════════════════════════════════
// proc_intercept.h — ARM64 SVC directos para intercepción de /proc/self/*
//
// Por qué SVC directos (no libc):
//   open()/read() en libc pasan por el PLT del proceso → Frida puede hookearlos.
//   Con SVC #0 + X8=syscall_number, la instrucción va directa al kernel sin
//   ningún trampolín de userspace interceptable.
//
// Uso:
//   native_is_being_traced()  → bool (TracerPid != 0 en /proc/self/status)
//   filter_maps(needle, ...)  → copia /proc/self/maps sin líneas con needle
// ══════════════════════════════════════════════════════════════════════════════
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>

// ── Syscalls directas ARM64 ────────────────────────────────────────────────

static inline long __svc_openat(int dirfd, const char* path, int flags) {
    register long x0 __asm__("x0") = (long)dirfd;
    register long x1 __asm__("x1") = (long)path;
    register long x2 __asm__("x2") = (long)flags;
    register long x3 __asm__("x3") = 0;
    register long x8 __asm__("x8") = 56L;
    __asm__ volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x2),"r"(x3),"r"(x8) : "memory");
    return x0;
}

static inline long __svc_read(int fd, void* buf, size_t n) {
    register long x0 __asm__("x0") = (long)fd;
    register long x1 __asm__("x1") = (long)buf;
    register long x2 __asm__("x2") = (long)n;
    register long x8 __asm__("x8") = 63L;
    __asm__ volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x2),"r"(x8) : "memory");
    return x0;
}

static inline long __svc_close(int fd) {
    register long x0 __asm__("x0") = (long)fd;
    register long x8 __asm__("x8") = 57L;
    __asm__ volatile("svc #0" : "+r"(x0) : "r"(x8) : "memory");
    return x0;
}

// ── Verifica TracerPid en /proc/self/status sin pasar por libc ───────────────
static inline bool native_is_being_traced() {
    static const char path[] = "/proc/self/status";
    int fd = (int)__svc_openat(-100, path, 0);
    if (fd < 0) return false;

    char buf[2048]; long n = __svc_read(fd, buf, sizeof(buf)-1);
    __svc_close(fd);
    if (n <= 0) return false;
    buf[n] = '\0';

    char* p = buf;
    while (*p) {
        if (strncmp(p, "TracerPid:", 10) == 0) {
            p += 10;
            while (*p == '\t' || *p == ' ') p++;
            return (*p != '0');
        }
        while (*p && *p != '\n') p++;
        if (*p) p++;
    }
    return false;
}

// ── Copia /proc/self/maps filtrando líneas que contienen needle ───────────────
static inline void filter_maps(const char* needle, char* out, size_t out_sz) {
    static const char path[] = "/proc/self/maps";
    int fd = (int)__svc_openat(-100, path, 0);
    if (fd < 0) { if (out_sz) out[0]='\0'; return; }

    char raw[65536]; long n = __svc_read(fd, raw, sizeof(raw)-1);
    __svc_close(fd);
    if (n <= 0) { if (out_sz) out[0]='\0'; return; }
    raw[n] = '\0';

    char* dst = out, *lim = out + out_sz - 1;
    const char* src = raw;
    while (*src && dst < lim) {
        const char* eol = src;
        while (*eol && *eol != '\n') eol++;
        bool skip = needle && strstr(src, needle);
        if (!skip) {
            size_t len = (size_t)(eol - src);
            if (dst + len + 1 < lim) { memcpy(dst, src, len); dst += len; }
            if (*eol == '\n' && dst < lim) *dst++ = '\n';
        }
        src = *eol ? eol+1 : eol;
    }
    if (dst < lim) *dst = '\0';
}
