// ══════════════════════════════════════════════════════════════════════════════
// sig_hook.h — Reemplazo nativo del IPackageManager proxy de Java
//
// ANTES (Java):
//   Proxy.newProxyInstance() → InvocationHandler.invoke() → modificar pi.signatures
//   Problema: crea una entrada $Proxy en el Dalvik heap visible al profiler.
//   El stack trace del InvocationHandler muestra com.dts.JLAPI como origen.
//
// AHORA (C++):
//   1. Instalar un PLT hook en openat() de libandroid_runtime.so
//   2. Cuando la ruta sea el APK modificado → redirigir al fd del APK original
//   3. El lector de firma (PackageParser/ZipArchive) ve siempre el APK limpio
//
//   Adicionalmente, patchear ApplicationInfo.sourceDir directamente via JNI
//   (sin reflexión de cadena en Java — usando GetFieldID/SetObjectField en C++)
//   para que Play Integrity calcule el hash correcto.
//
// Por qué PLT hook en openat es superior al proxy Java:
//   - No hay objetos $Proxy en el heap de Dalvik
//   - No hay InvocationHandler en el stack trace
//   - Funciona para cualquier biblioteca que intente verificar la firma
//     (no solo las rutas que el proxy Java conocía)
//   - Sobrevive a actualización del PackageManager (no depende de nombres de campo)
// ══════════════════════════════════════════════════════════════════════════════
#pragma once

#include <dlfcn.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <jni.h>
#include <stdatomic.h>

// ── Estado del hook de firma ─────────────────────────────────────────────────
static _Atomic int         g_sig_orig_fd   = -1;   // fd del APK original cacheado
static char                g_mod_apk_path[512] = {}; // ruta del APK modificado

// Puntero a la openat real (antes del hook)
static int (*g_real_openat)(int, const char*, int, ...) = nullptr;

// ── PLT hook en openat (sin BTI write — usa process_vm_writev igual que EGL) ─
// Redirige aperturas del APK modificado al fd del APK original (memfd o archivo)
static int hooked_openat(int dirfd, const char* path, int flags, ...) {
    if (path && g_mod_apk_path[0] && strcmp(path, g_mod_apk_path) == 0) {
        // El caller quiere el APK modificado → devolver dup del fd original
        int orig = atomic_load(&g_sig_orig_fd);
        if (orig >= 0) {
            // dup() para que el caller pueda close() independientemente
            return dup(orig);
        }
    }
    // Llamada normal — forwarding directo sin trampolín de vtable
    if (g_real_openat) return g_real_openat(dirfd, path, flags);
    return open(path, flags);
}

// ── Instalar el hook de firma ─────────────────────────────────────────────────
// Parches el GOT de libandroid_runtime.so para apuntar openat → hooked_openat
// process_vm_writev bypasa W^X igual que el EGL hook
#include <sys/uio.h>
#include <sys/syscall.h>

static bool _sig_pvm_write(void* dst, const void* src, size_t n) {
    struct iovec lv = {(void*)src, n};
    struct iovec rv = {dst, n};
    return syscall(__NR_process_vm_writev, (pid_t)getpid(),
                   &lv, 1UL, &rv, 1UL, 0UL) == (ssize_t)n;
}

// Encuentra la entrada GOT de `sym_name` en la librería que contiene `lib_frag`
static void** find_got_entry(const char* lib_frag, const char* sym_name) {
    FILE* maps = fopen("/proc/self/maps", "r");
    if (!maps) return nullptr;

    uintptr_t base = 0;
    char line[512];
    while (fgets(line, sizeof(line), maps)) {
        if (!strstr(line, lib_frag) || !strstr(line, "r--p") && !strstr(line, "r-xp")) continue;
        // Parsear dirección base
        char* end;
        base = (uintptr_t)strtoul(line, &end, 16);
        break;
    }
    fclose(maps);
    if (!base) return nullptr;

    // Parsear ELF para encontrar GOT entry de sym_name
    Elf64_Ehdr* ehdr = (Elf64_Ehdr*)base;
    if (memcmp(ehdr->e_ident, ELFMAG, SELFMAG) != 0) return nullptr;

    Elf64_Phdr* phdr = (Elf64_Phdr*)(base + ehdr->e_phoff);
    uintptr_t dyn_off = 0; size_t dyn_sz = 0;
    for (int i = 0; i < ehdr->e_phnum; i++) {
        if (phdr[i].p_type == PT_DYNAMIC) {
            dyn_off = phdr[i].p_vaddr;
            dyn_sz  = phdr[i].p_filesz;
            break;
        }
    }
    if (!dyn_off) return nullptr;

    Elf64_Dyn* dyn  = (Elf64_Dyn*)(base + dyn_off);
    uintptr_t strtab = 0, symtab = 0, rela = 0;
    size_t rela_sz = 0, rela_ent = sizeof(Elf64_Rela);

    for (Elf64_Dyn* d = dyn; d->d_tag != DT_NULL; d++) {
        switch (d->d_tag) {
            case DT_STRTAB: strtab  = base + d->d_un.d_ptr; break;
            case DT_SYMTAB: symtab  = base + d->d_un.d_ptr; break;
            case DT_JMPREL: rela    = base + d->d_un.d_ptr; break;
            case DT_PLTRELSZ: rela_sz = d->d_un.d_val; break;
        }
    }
    if (!strtab || !rela || !rela_sz) return nullptr;

    Elf64_Rela* relocs = (Elf64_Rela*)rela;
    size_t count = rela_sz / sizeof(Elf64_Rela);
    Elf64_Sym* syms = (Elf64_Sym*)symtab;

    for (size_t i = 0; i < count; i++) {
        uint32_t sym_idx = ELF64_R_SYM(relocs[i].r_info);
        const char* name = (const char*)(strtab + syms[sym_idx].st_name);
        if (strcmp(name, sym_name) == 0) {
            return (void**)(base + relocs[i].r_offset);
        }
    }
    return nullptr;
}

// ── API pública ───────────────────────────────────────────────────────────────

// Inicializar el hook de firma.
// modApkPath: ruta del APK modificado (ctx.getApplicationInfo().sourceDir)
// origApkFd:  fd (memfd o archivo) del APK original con la firma real
static bool sig_hook_install(const char* modApkPath, int origApkFd) {
    if (!modApkPath || origApkFd < 0) return false;

    strncpy(g_mod_apk_path, modApkPath, sizeof(g_mod_apk_path)-1);
    atomic_store(&g_sig_orig_fd, dup(origApkFd)); // mantener copia propia

    // Encontrar y parchear GOT de openat en libandroid_runtime.so
    void** got = find_got_entry("libandroid_runtime.so", "openat");
    if (!got) got = find_got_entry("libpackagelistparser.so", "openat");
    if (!got) {
        // Fallback: hooking en nuestro propio PLT no ayuda al runtime,
        // pero al menos parchamos las libs de verificación de firma más comunes
        got = find_got_entry("libziparchive.so", "openat");
    }
    if (!got) return false;

    g_real_openat = (int(*)(int, const char*, int, ...))(*got);
    void* fn_hook = (void*)hooked_openat;
    return _sig_pvm_write(got, &fn_hook, sizeof(fn_hook));
}

// Limpiar — restaurar GOT original y cerrar fd cacheado
static void sig_hook_remove() {
    int fd = atomic_exchange(&g_sig_orig_fd, -1);
    if (fd >= 0) close(fd);
    // Restaurar GOT (seguridad: si g_real_openat sigue siendo válido)
    // En práctica el mod se usa hasta que el proceso muere, no se necesita restore
}

// ── Parchear ApplicationInfo.sourceDir via JNI puro (sin Reflection de alto nivel)
// Más eficiente que el Java anterior — usa GetFieldID/SetObjectField directamente
static void patch_source_dir_jni(JNIEnv* env, jobject ctx, const char* origApkPath) {
    if (!env || !ctx || !origApkPath) return;

    // ctx.getApplicationInfo()
    jclass ctxCls = env->GetObjectClass(ctx);
    jmethodID getAI = env->GetMethodID(ctxCls, "getApplicationInfo",
        "()Landroid/content/pm/ApplicationInfo;");
    if (!getAI) { env->DeleteLocalRef(ctxCls); return; }
    jobject ai = env->CallObjectMethod(ctx, getAI);
    env->DeleteLocalRef(ctxCls);
    if (!ai) return;

    jclass aiCls = env->GetObjectClass(ai);
    jstring jpath = env->NewStringUTF(origApkPath);

    // sourceDir
    jfieldID fSrc = env->GetFieldID(aiCls, "sourceDir", "Ljava/lang/String;");
    if (fSrc) env->SetObjectField(ai, fSrc, jpath);

    // publicSourceDir
    jfieldID fPub = env->GetFieldID(aiCls, "publicSourceDir", "Ljava/lang/String;");
    if (fPub) env->SetObjectField(ai, fPub, jpath);

    // splitSourceDirs[0] = origApkPath (si existe)
    jfieldID fSplit = env->GetFieldID(aiCls, "splitSourceDirs", "[Ljava/lang/String;");
    if (fSplit) {
        jobjectArray splits = (jobjectArray)env->GetObjectField(ai, fSplit);
        if (splits && env->GetArrayLength(splits) > 0)
            env->SetObjectArrayElement(splits, 0, jpath);
        else {
            jobjectArray arr = env->NewObjectArray(1,
                env->FindClass("java/lang/String"), jpath);
            env->SetObjectField(ai, fSplit, arr);
            env->DeleteLocalRef(arr);
        }
        if (splits) env->DeleteLocalRef(splits);
    }

    env->DeleteLocalRef(jpath);
    env->DeleteLocalRef(aiCls);
    env->DeleteLocalRef(ai);
}

#include <elf.h>
