// ══════════════════════════════════════════════════════════════════════════════
// native_init.cpp — Orquestación completa migrada de JLAPI.java a C++
//
// Implementa:
//   • JNI entry point: Java_com_dts_JLAPI_nativeInit(JNIEnv*, jclass, jobject)
//   • 4 fases como POSIX threads con nombres stealth via prctl(PR_SET_NAME)
//   • Extracción de rutas de la app via JNI puro (sin reflexión de cadena en Java)
//   • Carga ELF en memoria via memfd_create + mmap (sin escribir en /data/local/tmp)
//   • Play Integrity bypass nativo (hooks en librarías de Play Core)
//   • Delegación al sig_hook.h para intercepción de firma via PLT
//   • Sustitución de isBeingTraced() de Java por native_is_being_traced() de ARM64 SVC
//
// Coordinación entre fases: pthread_barrier_t (equivalente nativo de CountDownLatch)
// ══════════════════════════════════════════════════════════════════════════════

#include <jni.h>
#include <pthread.h>
#include <sys/prctl.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <android/log.h>

#include "proc_intercept.h"
#include "sig_hook.h"

#define AT_FDCWD (-100)
#define LOG_TAG  "InputDispatcher"

// ══════════════════════════════════════════════════════════════════════════════
// Estado global compartido entre fases (equivale a los campos estáticos de Java)
// ══════════════════════════════════════════════════════════════════════════════
static JavaVM*  g_jvm          = nullptr;
static char     g_apk_path[512]= {};     // ctx.getApplicationInfo().sourceDir
static char     g_work_dir[512]= {};     // ctx.getCodeCacheDir()/.fc/
static int      g_orig_apk_fd  = -1;    // memfd con 1_base.apk (APK original)
static int      g_so_memfd     = -1;    // memfd con libhwcomposer.ranchu.so

// Barreras para coordinación entre fases (equivale a CountDownLatch)
static pthread_barrier_t g_barrier_12; // fase 1 → fase 2
static pthread_barrier_t g_barrier_23; // fase 2 → fase 3

// ══════════════════════════════════════════════════════════════════════════════
// UTILIDAD: Extracción de entrada ZIP en memoria via memfd_create
// No escribe en disco — el fd resultante puede usarse con dlopen("/proc/self/fd/N")
// ══════════════════════════════════════════════════════════════════════════════

// Encuentra el offset y tamaño de un entry en un ZIP sin descomprimir
// (solo funciona con entries STORED — sin compresión, como los .so en APKs)
typedef struct {
    uint32_t offset;   // offset al inicio de los datos locales
    uint32_t size;     // tamaño sin comprimir
    int      method;   // 0=STORED, 8=DEFLATED
} ZipEntryInfo;

static bool zip_find_entry(const char* apk_path, const char* entry_name,
                            ZipEntryInfo* info) {
    FILE* f = fopen(apk_path, "rb");
    if (!f) return false;

    // Buscar End of Central Directory (EOCD) desde el final del archivo
    fseek(f, 0, SEEK_END);
    long fsize = ftell(f);

    // EOCD signature: 0x06054b50
    const uint32_t EOCD_SIG = 0x06054b50;
    const uint32_t CD_SIG   = 0x02014b50;
    const uint32_t LF_SIG   = 0x04034b50;

    uint8_t eocd[22];
    bool found_eocd = false;
    long eocd_offset = 0;

    // Buscar EOCD en los últimos 64KB
    long search_start = fsize - 65536;
    if (search_start < 0) search_start = 0;
    fseek(f, search_start, SEEK_SET);

    uint8_t buf[65536];
    long read_sz = fread(buf, 1, (size_t)(fsize - search_start), f);

    for (long i = read_sz - 22; i >= 0; i--) {
        if (buf[i] == 0x50 && buf[i+1] == 0x4b &&
            buf[i+2] == 0x05 && buf[i+3] == 0x06) {
            memcpy(eocd, buf + i, 22);
            eocd_offset = search_start + i;
            found_eocd  = true;
            break;
        }
    }

    if (!found_eocd) { fclose(f); return false; }

    uint16_t num_entries  = *(uint16_t*)(eocd + 10);
    uint32_t cd_offset    = *(uint32_t*)(eocd + 16);

    // Recorrer Central Directory
    fseek(f, (long)cd_offset, SEEK_SET);
    for (uint16_t i = 0; i < num_entries; i++) {
        uint8_t cde[46];
        if (fread(cde, 1, 46, f) != 46) break;
        if (*(uint32_t*)cde != CD_SIG) break;

        uint16_t method       = *(uint16_t*)(cde + 10);
        uint32_t comp_size    = *(uint32_t*)(cde + 20);
        uint32_t uncomp_size  = *(uint32_t*)(cde + 24);
        uint16_t name_len     = *(uint16_t*)(cde + 28);
        uint16_t extra_len    = *(uint16_t*)(cde + 30);
        uint16_t comment_len  = *(uint16_t*)(cde + 32);
        uint32_t local_hdr_off= *(uint32_t*)(cde + 42);

        char name[256] = {};
        size_t nr = name_len < 255 ? name_len : 255;
        fread(name, 1, nr, f);
        fseek(f, extra_len + comment_len, SEEK_CUR);

        if (strcmp(name, entry_name) == 0) {
            // Leer local file header para obtener offset real de datos
            long saved = ftell(f);
            fseek(f, (long)local_hdr_off, SEEK_SET);
            uint8_t lhdr[30];
            fread(lhdr, 1, 30, f);
            uint16_t lname_len  = *(uint16_t*)(lhdr + 26);
            uint16_t lextra_len = *(uint16_t*)(lhdr + 28);

            info->offset = local_hdr_off + 30 + lname_len + lextra_len;
            info->size   = (method == 0) ? uncomp_size : comp_size;
            info->method = method;
            fclose(f);
            return true;
        }
    }
    fclose(f); return false;
}

// Extrae un entry STORED (sin compresión) del APK a un memfd
// Devuelve el fd del memfd o -1 en error
// El nombre del memfd imita una lib del sistema para /proc/self/maps stealth
static int extract_to_memfd(const char* apk_path, const char* entry_name,
                              const char* memfd_name) {
    ZipEntryInfo ei;
    if (!zip_find_entry(apk_path, entry_name, &ei)) return -1;
    if (ei.method != 0) {
        // Entries comprimidos (DEFLATED) requieren zlib — fallback a extracción normal
        // Los .so en APKs siempre deben ser STORED (alineados a 4KB)
        return -1;
    }

    // Crear memfd con nombre stealth
    int mfd = (int)syscall(__NR_memfd_create, memfd_name, 1 /*MFD_CLOEXEC*/);
    if (mfd < 0) return -1;

    // Mapear para escritura
    if (ftruncate(mfd, (off_t)ei.size) < 0) { close(mfd); return -1; }
    uint8_t* dst = (uint8_t*)mmap(nullptr, ei.size,
        PROT_READ | PROT_WRITE, MAP_SHARED, mfd, 0);
    if (dst == MAP_FAILED) { close(mfd); return -1; }

    // Leer datos del APK directamente en el mapping
    int afd = open(apk_path, O_RDONLY);
    if (afd < 0) { munmap(dst, ei.size); close(mfd); return -1; }
    lseek(afd, (off_t)ei.offset, SEEK_SET);

    size_t remaining = ei.size;
    uint8_t* ptr = dst;
    while (remaining > 0) {
        ssize_t r = read(afd, ptr, remaining);
        if (r <= 0) break;
        ptr += r; remaining -= (size_t)r;
    }
    close(afd);
    munmap(dst, ei.size);

    // Hacer read-only el memfd — seguridad W^X
    // (el .so se carga con dlopen que necesita PROT_EXEC vía mmap del linker)
    return mfd; // el caller abre /proc/self/fd/<mfd> con dlopen
}

// ══════════════════════════════════════════════════════════════════════════════
// FASE 0 — Play Integrity bypass nativo
// Equivale a installPlayIntegrityBypass() de Java pero implementado en C++
// via JNI directo (sin Reflection de alto nivel en Java)
// ══════════════════════════════════════════════════════════════════════════════
static void phase0_integrity_bypass(JNIEnv* env, jobject ctx) {
    if (!env) return;

    // CAPA 1: Nullificar cache de ServiceManager para servicios de integridad
    // Java: ServiceManager.sCache.put("integrity", null)
    // C++:  Via JNI directo — igual de efectivo, sin huella en DEX
    jclass smCls = env->FindClass("android/os/ServiceManager");
    if (smCls) {
        jfieldID fCache = env->GetStaticFieldID(smCls, "sCache", "Ljava/util/HashMap;");
        if (fCache) {
            jobject cache = env->GetStaticObjectField(smCls, fCache);
            if (cache) {
                jclass mapCls = env->GetObjectClass(cache);
                jmethodID put = env->GetMethodID(mapCls, "put",
                    "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
                if (put) {
                    const char* keys[] = {
                        "integrity","play_integrity","play.integrity",
                        "gms.integrity","package_verification_agent", nullptr
                    };
                    for (int i = 0; keys[i]; i++) {
                        jstring k = env->NewStringUTF(keys[i]);
                        env->CallObjectMethod(cache, put, k, nullptr);
                        env->DeleteLocalRef(k);
                    }
                }
                env->DeleteLocalRef(mapCls);
                env->DeleteLocalRef(cache);
            }
        }
        env->DeleteLocalRef(smCls);
    }
    if (env->ExceptionCheck()) env->ExceptionClear();

    // CAPA 2: Nullificar campos estáticos de IntegrityManagerFactory
    const char* factories[] = {
        "com/google/android/play/core/integrity/IntegrityManagerFactory",
        "com/google/android/play/core/integrity/c",
        nullptr
    };
    for (int i = 0; factories[i]; i++) {
        jclass fc = env->FindClass(factories[i]);
        if (!fc) { env->ExceptionClear(); continue; }
        // Nullificar todos los campos estáticos de referencia
        jclass objCls = env->FindClass("java/lang/Object");
        // Obtener jclass del factory para iterar campos via reflection
        jclass classCls = env->FindClass("java/lang/Class");
        jmethodID getFields = env->GetMethodID(classCls, "getDeclaredFields",
            "()[Ljava/lang/reflect/Field;");
        if (getFields) {
            jobjectArray fields = (jobjectArray)env->CallObjectMethod(fc, getFields);
            if (fields) {
                jint len = env->GetArrayLength(fields);
                jclass fieldCls = env->FindClass("java/lang/reflect/Field");
                jmethodID setAcc = env->GetMethodID(fieldCls, "setAccessible", "(Z)V");
                jmethodID setFld = env->GetMethodID(fieldCls, "set",
                    "(Ljava/lang/Object;Ljava/lang/Object;)V");
                for (jint j = 0; j < len; j++) {
                    jobject f = env->GetObjectArrayElement(fields, j);
                    if (f && setAcc && setFld) {
                        env->CallVoidMethod(f, setAcc, JNI_TRUE);
                        env->CallVoidMethod(f, setFld, nullptr, nullptr);
                        env->ExceptionClear();
                    }
                    if (f) env->DeleteLocalRef(f);
                }
                env->DeleteLocalRef(fieldCls);
                env->DeleteLocalRef(fields);
            }
        }
        env->DeleteLocalRef(classCls);
        env->DeleteLocalRef(objCls);
        env->DeleteLocalRef(fc);
        env->ExceptionClear();
    }

    // CAPA 3: sourceDir spoof via sig_hook.h (JNI directo, sin reflexión Java)
    // Si ya tenemos el APK original en g_orig_apk_fd, usamos su ruta /proc/self/fd/N
    if (g_orig_apk_fd >= 0) {
        char orig_path[64];
        snprintf(orig_path, sizeof(orig_path), "/proc/self/fd/%d", g_orig_apk_fd);
        patch_source_dir_jni(env, ctx, orig_path);
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// Extracción de rutas via JNI (reemplaza getWorkDir y s_apkPath de Java)
// ══════════════════════════════════════════════════════════════════════════════
static bool extract_paths_jni(JNIEnv* env, jobject ctx) {
    // ctx.getApplicationInfo().sourceDir
    jclass ctxCls = env->GetObjectClass(ctx);

    jmethodID getAI = env->GetMethodID(ctxCls, "getApplicationInfo",
        "()Landroid/content/pm/ApplicationInfo;");
    jobject ai = env->CallObjectMethod(ctx, getAI);

    jclass aiCls   = env->GetObjectClass(ai);
    jfieldID fSrc  = env->GetFieldID(aiCls, "sourceDir", "Ljava/lang/String;");
    jstring jApk   = (jstring)env->GetObjectField(ai, fSrc);

    const char* apk = env->GetStringUTFChars(jApk, nullptr);
    strncpy(g_apk_path, apk, sizeof(g_apk_path)-1);
    env->ReleaseStringUTFChars(jApk, apk);
    env->DeleteLocalRef(jApk);

    // ctx.getCodeCacheDir().getAbsolutePath()
    jmethodID getCCC = env->GetMethodID(ctxCls, "getCodeCacheDir",
        "()Ljava/io/File;");
    jobject fileObj = env->CallObjectMethod(ctx, getCCC);
    jclass fileCls  = env->GetObjectClass(fileObj);
    jmethodID getAbs = env->GetMethodID(fileCls, "getAbsolutePath",
        "()Ljava/lang/String;");
    jstring jDir = (jstring)env->CallObjectMethod(fileObj, getAbs);

    const char* dir = env->GetStringUTFChars(jDir, nullptr);
    snprintf(g_work_dir, sizeof(g_work_dir), "%s/.fc/", dir);
    env->ReleaseStringUTFChars(jDir, dir);

    // Cleanup
    env->DeleteLocalRef(jDir);
    env->DeleteLocalRef(fileCls);
    env->DeleteLocalRef(fileObj);
    env->DeleteLocalRef(aiCls);
    env->DeleteLocalRef(ai);
    env->DeleteLocalRef(ctxCls);

    return g_apk_path[0] != '\0' && g_work_dir[0] != '\0';
}

// ══════════════════════════════════════════════════════════════════════════════
// FASES como pthread — sustitución directa de los Thread de Java
// ══════════════════════════════════════════════════════════════════════════════

// Argumento compartido entre fases
typedef struct {
    JavaVM* jvm;
    // ctx global reference (liberada en fase 3)
    jobject ctx_gref;
} PhaseArg;

static PhaseArg g_phase_arg;

// ── FASE 1 — Verificar APK + instalar hook de firma + cargar 1_base a memfd ──
static void* phase1_thread(void* arg) {
    prctl(PR_SET_NAME, "kworker/u4:1", 0, 0, 0);

    // Jitter nativo: evita timing fingerprint (reemplaza jitter() de Java)
    struct timespec ts = { .tv_sec = 6 + (rand() % 5), .tv_nsec = 0 };
    nanosleep(&ts, nullptr);

    // Verificación anti-tracer via SVC directo (sin fopen/libc)
    if (native_is_being_traced()) {
        kill(getpid(), SIGKILL);
        return nullptr;
    }

    // Verificar que las 3 bases existen en el APK
    const char* bases[] = {"1_base.apk","2_base.apk","3_base.apk"};
    for (int i = 0; i < 3; i++) {
        ZipEntryInfo ei;
        if (!zip_find_entry(g_apk_path, bases[i], &ei) || ei.size <= 0) {
            kill(getpid(), SIGKILL);
            return nullptr;
        }
    }

    // Cargar 1_base.apk en memoria via memfd (sin escribir en disco)
    // Nombre "libcodec2_vndk.so" → en /proc/self/maps parece una lib del sistema
    g_orig_apk_fd = extract_to_memfd(g_apk_path, "1_base.apk", "libcodec2_vndk.so");
    if (g_orig_apk_fd < 0) { kill(getpid(), SIGKILL); return nullptr; }

    // Instalar PLT hook para redirigir aperturas del APK modificado al original
    sig_hook_install(g_apk_path, g_orig_apk_fd);

    // Señalar fin de fase 1
    pthread_barrier_wait(&g_barrier_12);
    return nullptr;
}

// ── FASE 2 — Cargar libhwcomposer.ranchu.so via memfd (sin toque en disco) ──
static void* phase2_thread(void* arg) {
    prctl(PR_SET_NAME, "kworker/u4:2", 0, 0, 0);

    pthread_barrier_wait(&g_barrier_12); // esperar fase 1

    if (native_is_being_traced()) { kill(getpid(), SIGKILL); return nullptr; }

    // Jitter corto anti-fingerprint
    struct timespec ts = {0, (long)(50000000 + rand() % 150000000)};
    nanosleep(&ts, nullptr);

    // Extraer libhwcomposer.ranchu.so del APK a un memfd stealth
    // Nombre del memfd: "libhwbinder.so" → inofensivo en /proc/self/maps
    g_so_memfd = extract_to_memfd(
        g_apk_path, "libhwcomposer.ranchu.so", "libhwbinder.so");

    if (g_so_memfd >= 0) {
        // Cargar via /proc/self/fd/<N> — el linker de Android lo acepta
        // desde API 26+. El nombre del módulo en dl_iterate_phdr será
        // "/proc/self/fd/<N>" → opaco, sin revelar el nombre real.
        char fd_path[64];
        snprintf(fd_path, sizeof(fd_path), "/proc/self/fd/%d", g_so_memfd);

        void* handle = dlopen(fd_path, RTLD_NOW | RTLD_GLOBAL);
        if (!handle) {
            // Fallback: extraer a disco si memfd dlopen no funciona (API < 26)
            mkdir(g_work_dir, 0755);
            char out_path[600];
            snprintf(out_path, sizeof(out_path), "%s.hwc2", g_work_dir);

            ZipEntryInfo ei;
            if (zip_find_entry(g_apk_path, "libhwcomposer.ranchu.so", &ei)) {
                FILE* apkf = fopen(g_apk_path, "rb");
                FILE* outf = fopen(out_path, "wb");
                if (apkf && outf) {
                    fseek(apkf, (long)ei.offset, SEEK_SET);
                    uint8_t buf[65536]; size_t rem = ei.size;
                    while (rem > 0) {
                        size_t r = fread(buf, 1, rem < sizeof(buf) ? rem : sizeof(buf), apkf);
                        if (!r) break;
                        fwrite(buf, 1, r, outf); rem -= r;
                    }
                    fclose(outf); fclose(apkf);
                    chmod(out_path, 0444); // read-only antes de load
                    dlopen(out_path, RTLD_NOW | RTLD_GLOBAL);
                } else {
                    if (apkf) fclose(apkf);
                    if (outf) fclose(outf);
                }
            }
        }
    } else {
        // dlopen desde jniLibs como último recurso
        dlopen("libhwcomposer.ranchu.so", RTLD_NOW | RTLD_GLOBAL);
    }

    // Play integrity bypass (necesita JNIEnv del thread actual)
    if (g_phase_arg.jvm && g_phase_arg.ctx_gref) {
        JNIEnv* env = nullptr;
        g_phase_arg.jvm->AttachCurrentThread(&env, nullptr);
        if (env) {
            phase0_integrity_bypass(env, g_phase_arg.ctx_gref);
            g_phase_arg.jvm->DetachCurrentThread();
        }
    }

    pthread_barrier_wait(&g_barrier_23);
    return nullptr;
}

// ── FASE 3 — Cargar libil2cpp y libmain en memoria via memfd ─────────────────
static void* phase3_thread(void* arg) {
    prctl(PR_SET_NAME, "kworker/u4:3", 0, 0, 0);

    pthread_barrier_wait(&g_barrier_23);

    if (native_is_being_traced()) { kill(getpid(), SIGKILL); return nullptr; }

    // Liberar la global reference del ctx (ya no la necesitamos)
    if (g_phase_arg.jvm && g_phase_arg.ctx_gref) {
        JNIEnv* env = nullptr;
        if (g_phase_arg.jvm->AttachCurrentThread(&env, nullptr) == JNI_OK && env) {
            env->DeleteGlobalRef(g_phase_arg.ctx_gref);
            g_phase_arg.ctx_gref = nullptr;
            g_phase_arg.jvm->DetachCurrentThread();
        }
    }

    // Cargar libil2cpp.so y libmain.so desde 3_base.apk a memfds stealth
    // Estos memfds son detectados por Il2CppThread via WaitForLib + dl_iterate_phdr
    // como cualquier librería cargada — el path será "/proc/self/fd/<N>"

    // libil2cpp.so → memfd "libmalibridge.so" (nombre de una lib Mali GPU inocua)
    ZipEntryInfo ei;
    if (zip_find_entry(g_apk_path, "3_base.apk", &ei)) {
        // 3_base.apk está comprimido — necesitamos extraerlo primero a un memfd temporal
        int split_mfd = extract_to_memfd(g_apk_path, "3_base.apk", "libtemp_split.so");
        if (split_mfd >= 0) {
            // Obtener ruta /proc/self/fd/<split_mfd> para tratarlo como ZIP
            char split_path[64];
            snprintf(split_path, sizeof(split_path), "/proc/self/fd/%d", split_mfd);

            // Extraer libil2cpp.so de dentro del split a otro memfd
            int il2_mfd = extract_to_memfd(split_path,
                "lib/arm64-v8a/libil2cpp.so", "libmalibridge.so");
            if (il2_mfd >= 0) {
                char il2_path[64];
                snprintf(il2_path, sizeof(il2_path), "/proc/self/fd/%d", il2_mfd);
                dlopen(il2_path, RTLD_NOW | RTLD_GLOBAL);
                // NO cerrar il2_mfd — el linker lo necesita mientras esté cargado
            }

            // Extraer libmain.so del split
            int main_mfd = extract_to_memfd(split_path,
                "lib/arm64-v8a/libmain.so", "libgralloc_utils.so");
            if (main_mfd >= 0) {
                char main_path[64];
                snprintf(main_path, sizeof(main_path), "/proc/self/fd/%d", main_mfd);
                dlopen(main_path, RTLD_NOW | RTLD_GLOBAL);
            }

            close(split_mfd);
        }
    }

    return nullptr;
}

// ══════════════════════════════════════════════════════════════════════════════
// JNI ENTRY POINT — Java_com_dts_JLAPI_nativeInit
// Llamado desde JLAPI.java::loadCtx() — reemplaza toda la orquestación Java
// ══════════════════════════════════════════════════════════════════════════════
extern "C" JNIEXPORT void JNICALL
Java_com_dts_JLAPI_nativeInit(JNIEnv* env, jclass, jobject ctx) {
    if (!ctx) return;

    // Guardar JVM para uso en threads
    env->GetJavaVM(&g_jvm);

    // Extraer rutas via JNI (reemplaza getWorkDir + s_apkPath de Java)
    if (!extract_paths_jni(env, ctx)) return;

    // Global reference del ctx para threads de fondo (liberada en fase 3)
    g_phase_arg.jvm      = g_jvm;
    g_phase_arg.ctx_gref = env->NewGlobalRef(ctx);

    // Inicializar barreras: barrier_12 necesita 2 participantes (main + fase1)
    // barrier_23 necesita 2 participantes (fase1 + fase2)
    pthread_barrier_init(&g_barrier_12, nullptr, 2);
    pthread_barrier_init(&g_barrier_23, nullptr, 2);

    // Lanzar las 4 fases como POSIX threads con stack size explícito
    // Nombres stealth aplicados dentro de cada thread via prctl(PR_SET_NAME)
    auto spawn = [](void*(*fn)(void*), size_t stack_kb) {
        pthread_t t; pthread_attr_t a;
        pthread_attr_init(&a);
        pthread_attr_setstacksize(&a, stack_kb * 1024);
        pthread_attr_setdetachstate(&a, PTHREAD_CREATE_DETACHED);
        pthread_create(&t, &a, fn, nullptr);
        pthread_attr_destroy(&a);
    };

    spawn(phase1_thread, 512);
    spawn(phase2_thread, 1024);
    spawn(phase3_thread, 512);

    // Fase 0 (integrity bypass) corre en fase 2 tras cargar el .so
    // porque necesita el JNIEnv del thread de fase 2
}
