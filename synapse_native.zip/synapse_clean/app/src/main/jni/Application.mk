# Application.mk — SynapseCheats | arm64-v8a
APP_ABI         := arm64-v8a
APP_PLATFORM    := android-21
APP_OPTIM       := release
APP_STL         := c++_static
APP_SHORT_COMMANDS := true
