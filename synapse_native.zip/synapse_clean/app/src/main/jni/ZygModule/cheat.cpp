// Copyright (c) 2026 @SynapseCheat. All rights reserved.
// SynapseCheats — Free Fire MAX | arm64-v8a
//
// ── LIMPIADO: Solo hook EGL + ImGui + touch input ─────────────────
// Se elimina: aimbot, ESP, speedhack, antiban, stealth, chams.
// El menú renderiza pero los toggles no tienen backend aún.
// Agrega tus propias funciones en Il2CppThread().

#include <imports.h>
#include <layout.h>
#include <telaonline.h>
// importz.h desactivado — no necesario para prueba ImGui pura
// Contiene CacheAllOffsets() y offsets de hack que no usamos
// MemoryPatch.hpp desactivado — sin patches de memoria en este test

#include <GLES2/gl2.h>
#include <EGL/egl.h>
#include <syn_dl.h>  // NDK r12 compat — syn_dl.h reemplaza link.h
#include <imagem.h>
#include <sys/prctl.h>
#include <sys/uio.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <pthread.h>
#include <atomic>

// ── Touch — actualizado desde Java via nativeTouchEvent (jni_bridge.cpp) ────
// JLAPI instala un FrameLayout MATCH_PARENT que reenvía todos los
// MotionEvent.ACTION_DOWN/MOVE/UP a g_touchX/Y/Down antes de que lleguen
// al juego. El menú ImGui lee estas variables en cada frame.
// Relay: JLAPI.installTouchRelay() → nativeTouchEvent() → g_touchX/Y/Down
extern "C" {
    float  g_touchX    = -1.f;
    float  g_touchY    = -1.f;
    bool   g_touchDown = false;
}

JavaVM* jvm = nullptr;

EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface);

static std::atomic<int>  g_stage{0};

// ── BTI-safe EGL hook via process_vm_writev ───────────────────────
// Android 15: mprotect+memcpy destruye BTI landing pads → SIGILL.
// process_vm_writev es syscall de kernel, bypasea BTI de userspace.
// Bug 6 FIX: g_origSwap como puntero crudo no tiene memory ordering.
// El check `if (!g_origSwap)` antes de call_once puede leer un valor
// stale en el thread de render si otro thread acaba de escribirlo.
// Con std::atomic el load acquire/release garantiza visibilidad correcta.
static std::atomic<EGLBoolean (*)(EGLDisplay, EGLSurface)> g_origSwap{nullptr};
static std::once_flag g_hookOnce;

// Cacheado una vez — SYN_get_dl_iter() abre/cierra libc.so via RTLD_NOLOAD.
static SYN_dl_iterate_fn s_dl_iter = nullptr;

static bool WaitForLib(const char* libFrag, int maxSeconds) {
    if (!s_dl_iter) s_dl_iter = SYN_get_dl_iter();
    if (!s_dl_iter) return false;
    int iters = maxSeconds * 2;
    for (int i = 0; i < iters; i++) {
        usleep(500000);
        struct _W { const char* f; bool found; } w = {libFrag, false};
        s_dl_iter([](SYN_dl_phdr_info* info, size_t, void* raw) -> int {
            auto* ww = static_cast<_W*>(raw);
            if (info->dlpi_name && strstr(info->dlpi_name, ww->f)) {
                ww->found = true; return 1;
            }
            return 0;
        }, &w);
        if (w.found) return true;
    }
    return false;
}

static bool _pvm_write(void* dst, const void* src, size_t n) {
    struct iovec lv = {const_cast<void*>(src), n};
    struct iovec rv = {dst, n};
    return syscall(__NR_process_vm_writev, (pid_t)getpid(),
                   &lv, 1UL, &rv, 1UL, 0UL) == (ssize_t)n;
}

static uint8_t* g_trampBuf  = nullptr;
static size_t   g_trampOff  = 0;
static size_t   g_trampSize = 4096; // default; se actualiza en InstallEglGotHook

static void InstallEglGotHook() {
    void* libEGL = dlopen(OBFUSCATE("libEGL.so"), RTLD_NOW | RTLD_GLOBAL);
    if (!libEGL) return;
    void* sym = dlsym(libEGL, OBFUSCATE("eglSwapBuffers"));
    if (!sym) return;

    if (!g_trampBuf) {
        // STEALTH FIX 1: el trampoline mapeado anónimo con permisos rwx→r-x es una
        // firma clara en /proc/self/maps. Solución: crear un memfd con nombre que
        // imite una biblioteca del sistema. El kernel lo muestra como
        // "/memfd:libhwbinder.so (deleted)" en /proc/self/maps — indistinguible
        // de una librería real mapeada.
        const size_t pgsz = (size_t)sysconf(_SC_PAGE_SIZE);
        int mfd = -1;

        // memfd_create disponible desde API 30 (Android 11)
        // Nombre elegido para mimetizar una lib del HW compositor (ya cargada por SurfaceFlinger)
// arm64 NR=279, arm32 NR=385
#if defined(__NR_memfd_create)
        mfd = (int)syscall(__NR_memfd_create, "libhwbinder.so", 0);
#elif defined(__arm__)
        mfd = (int)syscall(385, "libhwbinder.so", 0);
#endif
        if (mfd >= 0) {
            ftruncate(mfd, (off_t)pgsz);
            g_trampBuf = (uint8_t*)mmap(nullptr, pgsz,
                PROT_READ | PROT_WRITE,
                MAP_SHARED, mfd, 0);
            close(mfd); // cerrar fd — el mapping sigue vivo
            if (g_trampBuf == MAP_FAILED) g_trampBuf = nullptr;
        }
        // Fallback: MAP_ANONYMOUS si memfd_create no está disponible
        if (!g_trampBuf) {
            g_trampBuf = (uint8_t*)mmap(nullptr, pgsz,
                PROT_READ | PROT_WRITE,
                MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
            if (g_trampBuf == MAP_FAILED) { g_trampBuf = nullptr; return; }
        }
        g_trampSize = pgsz;
    }

    uint8_t* cont = g_trampBuf + g_trampOff;
    // Verificar que no desbordamos el buffer (tamaño dinámico = page_size del kernel)
    // En A16 con 16KB pages: g_trampSize = 16384 → caben 341 hooks de 48 bytes.
    if (g_trampOff + 48 > g_trampSize) return; // 48 bytes por hook (BTI+orig+tramp)
    g_trampOff += 48; // BTI_C(4) + orig(20) + LDR(4) + BR(4) + dst(8) = 40 + 8 padding

    uint8_t orig[20];
    memcpy(orig, sym, 20);

    const uint32_t BTI_C     = 0xD503245Fu; // BTI C — A16 kernel enforcement
    const uint32_t LDR_X16_8 = 0x58000050u; // LDR X16, #8
    const uint32_t BR_X16    = 0xD61F0200u; // BR X16
    // Trampoline layout (A16 BTI-safe):
    //   [0]    BTI C         — landing pad para BLR desde código BTI-habilitado
    //   [4-23] orig bytes    — 20 bytes del prólogo original de eglSwapBuffers
    //   [24]   LDR X16, #8  — carga cont_dst en X16
    //   [28]   BR X16       — salta de vuelta a sym+20
    //   [32]   cont_dst     — dirección de retorno (8 bytes)
    uintptr_t cont_dst = (uintptr_t)sym + 20;
    memcpy(cont,      &BTI_C,     4);   // [0]
    memcpy(cont +  4, orig,       20);  // [4-23]
    memcpy(cont + 24, &LDR_X16_8, 4);  // [24]
    memcpy(cont + 28, &BR_X16,    4);  // [28]
    memcpy(cont + 32, &cont_dst,  8);  // [32] — 8 bytes para puntero 64-bit

    // BTI_C already defined above
    uintptr_t hfn = (uintptr_t)hook_eglSwapBuffers;
    uint8_t patch[20];
    memcpy(patch,      &BTI_C,     4);
    memcpy(patch +  4, &LDR_X16_8, 4);
    memcpy(patch +  8, &BR_X16,    4);
    memcpy(patch + 12, &hfn,       8);

    if (_pvm_write(sym, patch, 20)) {
        // Quitar bit W del trampoline antes de ejecutar (W^X)
        mprotect(g_trampBuf, g_trampSize, PROT_READ | PROT_EXEC);
        __builtin___clear_cache((char*)sym, (char*)sym + 20);
        __builtin___clear_cache((char*)g_trampBuf, (char*)g_trampBuf + g_trampSize);
        g_origSwap.store(reinterpret_cast<EGLBoolean(*)(EGLDisplay, EGLSurface)>(cont),
                         std::memory_order_release);
    }
}

// ── hook_eglSwapBuffers ───────────────────────────────────────────
EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    auto _swap = g_origSwap.load(std::memory_order_acquire);
    if (!_swap) {
        // Retry seguro con once_flag — no re-instala si ya se ejecutó
        std::call_once(g_hookOnce, InstallEglGotHook);
        _swap = g_origSwap.load(std::memory_order_acquire);
        if (!_swap) return EGL_TRUE;
    }

    eglQuerySurface(dpy, surface, EGL_WIDTH,  &egl.width);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &egl.height);

    if (!egl.setup && egl.width > 0 && egl.height > 0) {
        // Detectar versión GLES disponible antes de inicializar ImGui
        const char* glver = (const char*)glGetString(GL_VERSION);
        const char* glsl  = (glver && strstr(glver, "3.")) ? "#version 300 es" : "#version 100";
        SetupImgui(glsl);
        InitTexture();
        egl.setup = true;
    }
    if (!egl.setup) return _swap(dpy, surface); // esperar dimensiones válidas

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)egl.width, (float)egl.height);

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(egl.width, egl.height);
    ImGui::NewFrame();

    // ── Touch nativo — actualizado desde Java vía nativeTouchEvent ──
    io.MousePos     = g_touchDown ? ImVec2(g_touchX, g_touchY) : ImVec2(-1.f, -1.f);
    io.MouseDown[0] = g_touchDown;

    // ── Renderizar menú ───────────────────────────────────────────
    menu();

    // STEALTH FIX 2: ImGui emite una secuencia de llamadas GL muy reconocible
    // (glUseProgram, glBindVertexArray, glDrawElements en loop).
    // Envolvemos el render en un save/restore de estado GL completo para que
    // el patrón quede "enterrado" dentro del estado normal de Unity y no sea
    // distinguible en un trace de llamadas GL (como el que hace la capa de
    // detección de Garena via eglDebugMessageControlKHR).
    GLint prevProg = 0, prevVao = 0, prevVbo = 0, prevIbo = 0;
    GLint prevBlend = 0, prevCull = 0, prevDepth = 0, prevScissor = 0;
    GLint prevViewport[4] = {};
    glGetIntegerv(GL_CURRENT_PROGRAM,       &prevProg);
    glGetIntegerv(GL_ARRAY_BUFFER_BINDING,   &prevVbo);
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING,  &prevVao);
    glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, &prevIbo);
    glGetIntegerv(GL_VIEWPORT,              prevViewport);
    prevBlend   = glIsEnabled(GL_BLEND);
    prevCull    = glIsEnabled(GL_CULL_FACE);
    prevDepth   = glIsEnabled(GL_DEPTH_TEST);
    prevScissor = glIsEnabled(GL_SCISSOR_TEST);

    ImGui::EndFrame();
    ImGui::Render();
    glViewport(0, 0, (GLsizei)egl.width, (GLsizei)egl.height);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    // Restaurar estado GL exactamente como estaba antes del render de ImGui
    glUseProgram((GLuint)prevProg);
    glBindVertexArray((GLuint)prevVao);
    glBindBuffer(GL_ARRAY_BUFFER,          (GLuint)prevVbo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,  (GLuint)prevIbo);
    glViewport(prevViewport[0], prevViewport[1], prevViewport[2], prevViewport[3]);
    prevBlend   ? glEnable(GL_BLEND)      : glDisable(GL_BLEND);
    prevCull    ? glEnable(GL_CULL_FACE)  : glDisable(GL_CULL_FACE);
    prevDepth   ? glEnable(GL_DEPTH_TEST) : glDisable(GL_DEPTH_TEST);
    prevScissor ? glEnable(GL_SCISSOR_TEST) : glDisable(GL_SCISSOR_TEST);

    return _swap(dpy, surface);
}

// ── RenderThread — espera il2cpp, luego instala el hook EGL ───────
static void* RenderThread(void*) {
    const char tn[] = {'H','w','c','2','C','a','l','l','b','a','c','k','\0'};
    prctl(PR_SET_NAME, (unsigned long)tn, 0, 0, 0);

    // Esperar Stage 1: il2cpp listo + offsets cacheados
    for (int i = 0; i < 360 && g_stage.load() < 1; i++) usleep(500000);

    WaitForLib(OBFUSCATE("libGGP.so"), 90);
    usleep(800000);

    std::call_once(g_hookOnce, InstallEglGotHook);
    return nullptr;
}

// ── Il2CppThread — cachea offsets de touch para el menú ──────────
static void* Il2CppThread(void*) {
    const char tn[] = {'S','u','r','f','a','c','e','F','l','i','n','g','e','r','\0'};
    prctl(PR_SET_NAME, (unsigned long)tn, 0, 0, 0);

    WaitForLib(OBFUSCATE("libGGP.so"), 120); // Bug 2 FIX: string estaba en claro en .rodata
    sleep(5);

    // Verificar que il2cpp.so esté disponible
    {
        void* h = dlopen(OBFUSCATE("libil2cpp.so"), RTLD_NOLOAD | RTLD_NOW);
        if (!h) return nullptr;

        using fn_get  = void*(*)();
        using fn_asm  = void**(*)(const void*, size_t*);
        using fn_img  = void*(*)(const void*);
        using fn_name = const char*(*)(void*);

        auto f_get  = (fn_get) dlsym(h, OBFUSCATE("il2cpp_domain_get"));
        auto f_asm  = (fn_asm) dlsym(h, OBFUSCATE("il2cpp_domain_get_assemblies"));
        auto f_img  = (fn_img) dlsym(h, OBFUSCATE("il2cpp_assembly_get_image"));
        auto f_name = (fn_name)dlsym(h, OBFUSCATE("il2cpp_image_get_name"));

        if (f_get && f_asm && f_img && f_name) {
            for (int a = 0; a < 30; a++) {
                void* domain = f_get();
                if (!domain) { usleep(1000000); continue; }
                size_t sz = 0;
                void** list = f_asm(domain, &sz);
                if (!list || sz == 0) { usleep(1000000); continue; }
                bool found = false;
                for (size_t i = 0; i < sz && !found; i++) {
                    if (!list[i]) continue;
                    void* img = f_img(list[i]);
                    if (!img) continue;
                    const char* nm = f_name(img);
                    if (nm && strcmp(nm, "Assembly-CSharp.dll") == 0) found = true;
                }
                if (found) break;
                usleep(1000000);
            }
        }
        // NO dlclose: RTLD_NOLOAD no incrementa refcount
        // dlclose lo decrementaría y podría unload libil2cpp.so
        (void)h;
    }

    Il2CppAttach(OBFUSCATE("libil2cpp.so"));
    for (int i = 0; i < 30 && !Il2CppIsAssembliesLoaded(); i++)
        usleep(500000);

    g_stage.store(1, std::memory_order_release);

    // PRUEBA IMGUI PURA — sin hooks de hack
    // Cuando confirmes que ImGui no baneá, agrega aquí tus hooks

    return nullptr;
}

// ── JNI ──────────────────────────────────────────────────────────
extern "C" JNIEXPORT jboolean JNICALL
Java_com_dts_JLAPI_KernelStatus(JNIEnv*, jclass) {
    return (jboolean)(dlopen(OBFUSCATE("libil2cpp.so"), RTLD_NOLOAD) != nullptr);
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    jvm = vm;
    return JNI_VERSION_1_6;
}

// ── Entry point ───────────────────────────────────────────────────
__attribute__((constructor))
void lib_main() {
    {
        pthread_t t; pthread_attr_t a;
        pthread_attr_init(&a);
        pthread_attr_setstacksize(&a, 2 * 1024 * 1024);
        pthread_attr_setdetachstate(&a, PTHREAD_CREATE_DETACHED);
        pthread_create(&t, &a, Il2CppThread, nullptr);
        pthread_attr_destroy(&a);
    }
    {
        pthread_t t; pthread_attr_t a;
        pthread_attr_init(&a);
        pthread_attr_setstacksize(&a, 1024 * 1024);
        pthread_attr_setdetachstate(&a, PTHREAD_CREATE_DETACHED);
        pthread_create(&t, &a, RenderThread, nullptr);
        pthread_attr_destroy(&a);
    }
}
