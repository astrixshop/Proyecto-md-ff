#pragma once
#include <vector>
#include <random>
#include <cmath> // Adicionado para M_PI
#include <imgui.h>

// Estrutura para uma particula individual
struct Particle {
    ImVec2 position;    // Posiaoo atual da particula
    ImVec2 velocity;    // Velocidade da particula
    float life;         // Tempo de vida restante (0.0 a 1.0)
    float maxLife;      // Tempo de vida maximo
    float size;         // Tamanho da particula
    ImU32 color;        // Cor da particula
    float alpha;        // Transparancia
    
    Particle() : position(0, 0), velocity(0, 0), life(1.0f), maxLife(1.0f), size(2.0f), color(IM_COL32(255, 255, 255, 255)), alpha(1.0f) {}
};

// Classe para gerenciar o sistema de particulas
class ParticleSystem {
private:
    std::vector<Particle> particles;
    std::mt19937 rng;
    std::uniform_real_distribution<float> randomFloat;
    ImVec2 windowSize;
    float spawnRate;
    float timeSinceLastSpawn;
    
public:
    ParticleSystem(int maxParticles = 100, float spawnRate = 0.1f);
    
    void Update(float deltaTime, ImVec2 windowSize);
    void Render(ImDrawList* drawList);
    void SpawnParticle(ImVec2 position = ImVec2(-1, -1));
    void SetWindowSize(ImVec2 size) { windowSize = size; }
    
private:
    void UpdateParticle(Particle& particle, float deltaTime);
    ImU32 GetParticleColor(float life, float maxLife);
    float Random(float min = 0.0f, float max = 1.0f);
};



