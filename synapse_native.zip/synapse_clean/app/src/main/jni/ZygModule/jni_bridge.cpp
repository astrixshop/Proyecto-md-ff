// jni_bridge.cpp — SynapseCheats
// Compatible con AIDE NDK r12 (sin link.h completo, sin ElfW)
#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stddef.h>
#include <elf.h>
#include <syn_dl.h>      // SYN_dl_phdr_info, SYN_get_dl_iter — NDK r12 compat

#define LOG_TAG "InputDispatcher"
#define LOGI(...) ((void)0)
#define LOGE(...) ((void)0)

// ─── JNI_OnLoad ──────────────────────────────────────────────────────────────
// cheat.cpp también define JNI_OnLoad — este archivo NO lo duplica.

// ─── nativeInitAudio — lanza Free Fire Max via Intent ────────────────────────
extern "C" JNIEXPORT void JNICALL
Java_com_dts_MainActivity_nativeInitAudio(JNIEnv* env, jclass, jobject context) {
    jclass compCls   = env->FindClass("android/content/ComponentName");
    jclass intentCls = env->FindClass("android/content/Intent");
    if (!compCls || !intentCls) return;

    jmethodID compInit   = env->GetMethodID(compCls, "<init>",
        "(Ljava/lang/String;Ljava/lang/String;)V");
    jmethodID intentInit = env->GetMethodID(intentCls, "<init>", "()V");
    jmethodID setComp    = env->GetMethodID(intentCls, "setComponent",
        "(Landroid/content/ComponentName;)Landroid/content/Intent;");
    jmethodID addFlags   = env->GetMethodID(intentCls, "addFlags",
        "(I)Landroid/content/Intent;");

    jstring pkg    = env->NewStringUTF("com.dts.freefiremax");
    jstring act    = env->NewStringUTF("com.dts.freefiremax.MainActivity");
    jobject comp   = env->NewObject(compCls,   compInit,   pkg, act);
    jobject intent = env->NewObject(intentCls, intentInit);
    env->DeleteLocalRef(pkg); env->DeleteLocalRef(act);

    env->CallObjectMethod(intent, setComp,   comp);
    env->CallObjectMethod(intent, addFlags,  (jint)0x10000000);

    jclass     ctxCls   = env->GetObjectClass(context);
    jmethodID  startAct = env->GetMethodID(ctxCls, "startActivity",
        "(Landroid/content/Intent;)V");
    env->CallVoidMethod(context, startAct, intent);

    env->DeleteLocalRef(comp);    env->DeleteLocalRef(intent);
    env->DeleteLocalRef(compCls); env->DeleteLocalRef(intentCls);
    env->DeleteLocalRef(ctxCls);
}

// ─── nativeMemfdCreate ────────────────────────────────────────────────────────
// arm64 NR_memfd_create = 279, MFD_CLOEXEC = 1
// Nombre vacío → aparece como "/memfd: (deleted)" en /proc/self/maps
extern "C" JNIEXPORT jlong JNICALL
Java_com_dts_JLAPI_nativeMemfdCreate(JNIEnv*, jclass) {
    long fd = syscall(279L, "", 1);
    return (jlong)fd;
}

// ─── nativeTouchEvent — recibe toques desde MenuOverlay/JLAPI ────────────────
// Java llama esto desde dispatchTouchEvent() del overlay.
// action: 0=DOWN, 2=MOVE, 1=UP, 3=CANCEL  (valores de MotionEvent)
extern float g_touchX;
extern float g_touchY;
extern bool  g_touchDown;

extern "C" JNIEXPORT void JNICALL
Java_com_dts_JLAPI_nativeTouchEvent(JNIEnv*, jclass,
                                     jint action, jfloat x, jfloat y) {
    switch (action) {
        case 0: // ACTION_DOWN
        case 2: // ACTION_MOVE
            g_touchX = x; g_touchY = y; g_touchDown = true;  break;
        case 1: // ACTION_UP
        case 3: // ACTION_CANCEL
            g_touchX = x; g_touchY = y; g_touchDown = false; break;
    }
}

// ─── nativeSetInputQueue — no-op ─────────────────────────────────────────────
extern "C" JNIEXPORT void JNICALL
Java_com_dts_JLAPI_nativeSetInputQueue(JNIEnv*, jclass, jobject) {}

// Borra soname/path del STRTAB ELF del .so cargado en memoria via memfd.
// Sin rastro del nombre real del módulo en dl_iterate_phdr ni /proc/self/maps.
extern "C" JNIEXPORT void JNICALL
Java_com_dts_JLAPI_nativeCleanLoadedSoStrings(JNIEnv*, jclass) {
    auto dl_iter = SYN_get_dl_iter();
    if (!dl_iter) return;

    struct Ctx { uintptr_t strtab; size_t strsize; };
    Ctx ctx = {0, 0};

    dl_iter([](SYN_dl_phdr_info* info, size_t, void* raw) -> int {
        if (!info->dlpi_name) return 0;
        if (info->dlpi_name[0] != '\0' &&
            !strstr(info->dlpi_name, "hwcomposer") &&
            !strstr(info->dlpi_name, "memfd")) return 0;

        auto* c = static_cast<Ctx*>(raw);
        for (int i = 0; i < (int)info->dlpi_phnum; i++) {
            const Elf64_Phdr* ph = &info->dlpi_phdr[i];
            if (ph->p_type != PT_DYNAMIC) continue;
            auto* dyn = reinterpret_cast<Elf64_Dyn*>(
                info->dlpi_addr + ph->p_vaddr);
            uintptr_t strtab = 0; size_t strsz = 0;
            for (Elf64_Dyn* d = dyn; d->d_tag != DT_NULL; d++) {
                if (d->d_tag == DT_STRTAB)
                    strtab = info->dlpi_addr + (uintptr_t)d->d_un.d_ptr;
                if (d->d_tag == DT_STRSZ)
                    strsz  = (size_t)d->d_un.d_val;
            }
            if (strtab && strsz) { c->strtab = strtab; c->strsize = strsz; }
            break;
        }
        return 0;
    }, &ctx);

    if (!ctx.strtab || !ctx.strsize) return;

    long   ps  = sysconf(_SC_PAGESIZE);
    void*  pg  = reinterpret_cast<void*>(ctx.strtab & ~(uintptr_t)(ps - 1));
    size_t len = ((ctx.strtab + ctx.strsize) -
        reinterpret_cast<uintptr_t>(pg) + (size_t)ps - 1u)
        & ~((size_t)ps - 1u);

    if (mprotect(pg, len, PROT_READ | PROT_WRITE) != 0) return;

    char* s   = reinterpret_cast<char*>(ctx.strtab);
    char* end = s + ctx.strsize;
    for (char* p = s; p < end; ) {
        size_t l = strlen(p);
        if (l > 0 && (
            (l > 3 && strcmp(p + l - 3, ".so") == 0) ||
            p[0] == '/' ||
            strstr(p, "hwcomposer") ||
            strstr(p, "memfd"))) {
            memset(p, 0, l);
        }
        p += l + 1;
    }
    mprotect(pg, len, PROT_READ);
}
