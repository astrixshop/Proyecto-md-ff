#include "aaui.h"
#include <mutex>
#include <thread>
#include <ctime>



#define O(str) ((const char*)(char*)OBFUSCATE(str))
#define SO(str) std::string(OBFUSCATE(str))

extern JavaVM *jvm;
inline JNIEnv *genv = nullptr;
inline bool isExpired() {
std::time_t t = std::time(nullptr);
std::tm* now = std::localtime(&t);
std::tm expirationDate = {};
expirationDate.tm_year = 2027 - 1900;  // Actualizado a 2027
expirationDate.tm_mon = 11;            // Diciembre (0-indexed: 11 = diciembre)
expirationDate.tm_mday = 31;
return std::difftime(std::mktime(now), std::mktime(&expirationDate)) > 0;
}


// getClipboard() — ver la versión completa con JavaVM* más abajo.
// Este forward declaration evita referencias hacia adelante en ShowLogin2.
inline std::string getClipboard(JavaVM* vm);
inline std::string getClipboard() { return getClipboard(jvm); }

jclass UnityPlayer_cls;
jfieldID UnityPlayer_CurrentActivity_fid;



jobject getGlobalContext()
{
jclass activityThread = genv->FindClass(OBFUSCATE("android/app/ActivityThread"));
jmethodID currentActivityThread = genv->GetStaticMethodID(activityThread, OBFUSCATE("currentActivityThread"), OBFUSCATE("()Landroid/app/ActivityThread;"));
jobject at = genv->CallStaticObjectMethod(activityThread, currentActivityThread);
jmethodID getApplication = genv->GetMethodID(activityThread, OBFUSCATE("getApplication"), OBFUSCATE("()Landroid/app/Application;"));
jobject context = genv->CallObjectMethod(at, getApplication);
return context;
}

void displayKeyboard(bool pShow) {
jclass ctx = genv->FindClass(OBFUSCATE("android/content/Context"));
jfieldID fid = genv->GetStaticFieldID(ctx, OBFUSCATE("INPUT_METHOD_SERVICE"), OBFUSCATE("Ljava/lang/String;"));
jmethodID mid = genv->GetMethodID(ctx, OBFUSCATE("getSystemService"), OBFUSCATE("(Ljava/lang/String;)Ljava/lang/Object;"));
jobject context = genv->GetStaticObjectField(UnityPlayer_cls, UnityPlayer_CurrentActivity_fid);
jobject InputManObj = genv->CallObjectMethod(context, mid, (jstring) genv->GetStaticObjectField(ctx, fid));
jclass ClassInputMethodManager = genv->FindClass(OBFUSCATE("android/view/inputmethod/InputMethodManager"));
jmethodID toggleSoftInputId = genv->GetMethodID(ClassInputMethodManager, OBFUSCATE("toggleSoftInput"), OBFUSCATE("(II)V"));
if (pShow) {
genv->CallVoidMethod(InputManObj, toggleSoftInputId, 2, 0);
} else {
genv->CallVoidMethod(InputManObj, toggleSoftInputId, 0, 0);
}
}

int ShowSoftKeyboardInput() {
jint result;
jint flags = 0;

JNIEnv *env;
jvm->AttachCurrentThread(&env, NULL);

jclass looperClass = env->FindClass(OBFUSCATE("android/os/Looper"));
auto prepareMethod = env->GetStaticMethodID(looperClass, OBFUSCATE("prepare"), OBFUSCATE("()V"));
env->CallStaticVoidMethod(looperClass, prepareMethod);

jclass activityThreadClass = env->FindClass(OBFUSCATE("android/app/ActivityThread"));
jfieldID sCurrentActivityThreadField = env->GetStaticFieldID(activityThreadClass, OBFUSCATE("sCurrentActivityThread"), OBFUSCATE("Landroid/app/ActivityThread;"));
jobject sCurrentActivityThread = env->GetStaticObjectField(activityThreadClass, sCurrentActivityThreadField);

jfieldID mInitialApplicationField = env->GetFieldID(activityThreadClass, OBFUSCATE("mInitialApplication"), OBFUSCATE("Landroid/app/Application;"));
jobject mInitialApplication = env->GetObjectField(sCurrentActivityThread, mInitialApplicationField);

jclass contextClass = env->FindClass(OBFUSCATE("android/content/Context"));
jfieldID fieldINPUT_METHOD_SERVICE = env->GetStaticFieldID(contextClass, OBFUSCATE("INPUT_METHOD_SERVICE"), OBFUSCATE("Ljava/lang/String;"));
jobject INPUT_METHOD_SERVICE = env->GetStaticObjectField(contextClass, fieldINPUT_METHOD_SERVICE);
jmethodID getSystemServiceMethod = env->GetMethodID(contextClass, OBFUSCATE("getSystemService"), OBFUSCATE("(Ljava/lang/String;)Ljava/lang/Object;"));
jobject callObjectMethod = env->CallObjectMethod(mInitialApplication, getSystemServiceMethod, INPUT_METHOD_SERVICE);
jclass classInputMethodManager = env->FindClass(OBFUSCATE("android/view/inputmethod/InputMethodManager"));
jmethodID toggleSoftInputId = env->GetMethodID(classInputMethodManager, OBFUSCATE("toggleSoftInput"), OBFUSCATE("(II)V"));
if (result) {
env->CallVoidMethod(callObjectMethod, toggleSoftInputId, 2, flags);
} else {
env->CallVoidMethod(callObjectMethod, toggleSoftInputId, flags, flags);
}

env->DeleteLocalRef(classInputMethodManager);
env->DeleteLocalRef(callObjectMethod);
env->DeleteLocalRef(contextClass);
env->DeleteLocalRef(mInitialApplication);
env->DeleteLocalRef(activityThreadClass);
jvm->DetachCurrentThread();
return result;
}


struct {
struct {
struct {
jobject Builder(JNIEnv *env) {
jclass BuilderClass = env->FindClass("android/os/StrictMode$ThreadPolicy$Builder");
jmethodID BuilderID = env->GetMethodID(BuilderClass,"<init>", "()V");
jobject _tmp = env->NewObject(BuilderClass, BuilderID); return _tmp;
}
jobject permitAll(JNIEnv *env, jobject builder) {
jclass BuilderClass = env->FindClass("android/os/StrictMode$ThreadPolicy$Builder");
jmethodID permitAllID = env->GetMethodID(BuilderClass,"permitAll","()Landroid/os/StrictMode$ThreadPolicy$Builder;");

}
jobject build(JNIEnv *env, jobject permitAll) {
jclass BuilderClass = env->FindClass("android/os/StrictMode$ThreadPolicy$Builder");
jmethodID buildID = env->GetMethodID(BuilderClass,"build","()Landroid/os/StrictMode$ThreadPolicy;");

}
}Builder;
}ThreadPolicy;

void setThreadPolicy(JNIEnv *env, jobject policy) {
jclass StrictModeclass = env->FindClass("android/os/StrictMode");
jmethodID setThreadPolicy = env->GetStaticMethodID(StrictModeclass,"setThreadPolicy","(Landroid/os/StrictMode$ThreadPolicy;)V");
env->CallStaticVoidMethod(StrictModeclass,setThreadPolicy, policy);
env->DeleteLocalRef(StrictModeclass);
}
}StrictMode;

struct {
jobject HttpURLConnection(JNIEnv *env, const char *url) {
jclass urlclass = env->FindClass("java/net/URL");
jmethodID urlcontruc = env->GetMethodID(urlclass, "<init>", "(Ljava/lang/String;)V");
jobject mainurl = env->NewObject(urlclass, urlcontruc, env->NewStringUTF(url));
jobject _tmp = env->NewObject(urlclass, urlcontruc, env->NewStringUTF(url)); return _tmp;
}

jobject openConnection(JNIEnv *env, jobject http) {
jclass urlclass = env->FindClass("java/net/URL");
jmethodID openConnectionID = env->GetMethodID(urlclass,"openConnection","()Ljava/net/URLConnection;");

}
}URL;

struct {
jobject BufferedInputStream(JNIEnv *env, jobject in) {
jclass BufferedInputStreamClass = env->FindClass("java/io/BufferedInputStream");
jmethodID BufferedInputStreamID = env->GetMethodID(BufferedInputStreamClass, "<init>", "(Ljava/io/InputStream;)V");
jobject _tmp = env->NewObject(BufferedInputStreamClass, BufferedInputStreamID,in); return _tmp;
}
}BufferedInputStream;

struct {
jobject getInputStream(JNIEnv *env, jobject urlConnection) {
jclass httpcon = env->FindClass("java/net/HttpURLConnection");
jmethodID impu = env->GetMethodID(httpcon, "getInputStream", "()Ljava/io/InputStream;");

}
void setRequestMethod(JNIEnv *env, jobject urlConnection, const char *method) {
jclass httpcon = env->FindClass("java/net/HttpURLConnection");
jmethodID getmthodurl = env->GetMethodID(httpcon, "setRequestMethod", "(Ljava/lang/String;)V");
env->CallVoidMethod(urlConnection, getmthodurl, env->NewStringUTF(method));
env->DeleteLocalRef(httpcon);
}
void setDoOutput(JNIEnv *env, jobject urlConnection, jboolean dooutput){
jclass httpcon = env->FindClass("java/net/HttpURLConnection");
jmethodID setDoOutputid = env->GetMethodID(httpcon, "setDoOutput", "(Z)V");
env->CallVoidMethod(urlConnection, setDoOutputid, dooutput);
env->DeleteLocalRef(httpcon);
}
void setRequestProperty(JNIEnv *env, jobject urlConnection, const char *key, const char *value) {
jclass httpcon = env->FindClass("java/net/HttpURLConnection");
jmethodID setrequespr = env->GetMethodID(httpcon, "setRequestProperty", "(Ljava/lang/String;Ljava/lang/String;)V");
env->CallVoidMethod(urlConnection, setrequespr, env->NewStringUTF(key), env->NewStringUTF(value));
env->DeleteLocalRef(httpcon);
}
void setFixedLengthStreamingMode(JNIEnv *env, jobject urlConnection, int contentLength){
jclass httpcon = env->FindClass("java/net/HttpURLConnection");
jmethodID setFixed = env->GetMethodID(httpcon, "setFixedLengthStreamingMode", "(I)V");
env->CallVoidMethod(urlConnection, setFixed, contentLength);
env->DeleteLocalRef(httpcon);
}
jobject getOutputStream(JNIEnv *env, jobject urlConnection) {
jclass httpcon = env->FindClass("java/net/HttpURLConnection");
jmethodID outhphtppp = env->GetMethodID(httpcon, "getOutputStream", "()Ljava/io/OutputStream;");
return env->CallObjectMethod(urlConnection, outhphtppp);
}
}HttpURLConnection;

struct {
jobject InputStreamReader(JNIEnv *env, jobject in, const char* utf) {
jclass InputStreamReaderClass = env->FindClass("java/io/InputStreamReader");
jmethodID InputStreamReaderID = env->GetMethodID(InputStreamReaderClass, "<init>", "(Ljava/io/InputStream;Ljava/lang/String;)V");
jobject _tmp = env->NewObject(InputStreamReaderClass, InputStreamReaderID,in,env->NewStringUTF(utf)); return _tmp;
}
}InputStreamReader;

struct {
jobject BufferedReader(JNIEnv *env, jobject in, int sz) {
jclass BufferedReaderClass = env->FindClass("java/io/BufferedReader");
jmethodID BufferedReaderID = env->GetMethodID(BufferedReaderClass, "<init>", "(Ljava/io/Reader;I)V");
jobject _tmp = env->NewObject(BufferedReaderClass, BufferedReaderID,in,sz); return _tmp;
}
jstring readLine(JNIEnv *env, jobject in) {
jclass BufferedReaderClass = env->FindClass("java/io/BufferedReader");
jmethodID readLineID = env->GetMethodID(BufferedReaderClass, "readLine", "()Ljava/lang/String;");

}
}BufferedReader;

struct {
jobject StringBuilder(JNIEnv *env) {
jclass StringBuilderClass = env->FindClass("java/lang/StringBuilder");
jmethodID StringBuilderID = env->GetMethodID(StringBuilderClass, "<init>", "()V");
jobject _tmp = env->NewObject(StringBuilderClass, StringBuilderID); return _tmp;
}
jobject append(JNIEnv *env, jobject obj, jstring str) {
jclass StringBuilderClass = env->FindClass("java/lang/StringBuilder");
jmethodID appendID = env->GetMethodID(StringBuilderClass,"append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");

}
jstring toString(JNIEnv *env, jobject obj) {
jclass Object = env->FindClass("java/lang/StringBuilder");
jmethodID toString = env->GetMethodID(Object,"toString", "()Ljava/lang/String;");

}
}StringBuilder;

const char *getRequestURL(JNIEnv *env, const char *url) {
jobject policy = StrictMode.ThreadPolicy.Builder.build(env,StrictMode.ThreadPolicy.Builder.permitAll(env,StrictMode.ThreadPolicy.Builder.Builder(env)));
StrictMode.setThreadPolicy(env,policy);
jobject urlConnection = URL.openConnection(env,URL.HttpURLConnection(env,url));
jobject in = BufferedInputStream.BufferedInputStream(env,HttpURLConnection.getInputStream(env,urlConnection));
jobject reader = BufferedReader.BufferedReader(env,InputStreamReader.InputStreamReader(env,in,"UTF-8"),8);
jobject sb = StringBuilder.StringBuilder(env);
jstring line;
while((line = BufferedReader.readLine(env,reader)) != nullptr) {
StringBuilder.append(env,sb,line);
}
jstring str = StringBuilder.toString(env,sb);
return env->GetStringUTFChars(str,0);;
}

jobject getJNIContext(JNIEnv *env) {
jclass activityThreadCls = env->FindClass("android/app/ActivityThread");
jmethodID currentActivityThread = env->GetStaticMethodID(activityThreadCls, "currentActivityThread", "()Landroid/app/ActivityThread;");
jobject activityThreadObj = env->CallStaticObjectMethod(activityThreadCls, currentActivityThread);
jmethodID getApplication = env->GetMethodID(activityThreadCls, "getApplication", "()Landroid/app/Application;");
jobject context = env->CallObjectMethod(activityThreadObj, getApplication);
return context;
}

const char *GetAndroidID(JNIEnv *env, jobject context) {
jclass contextClass = env->FindClass("android/content/Context");
jmethodID getContentResolverMethod = env->GetMethodID(contextClass,"getContentResolver","()Landroid/content/ContentResolver;");
jclass settingSecureClass = env->FindClass("android/provider/Settings$Secure");
jmethodID getStringMethod = env->GetStaticMethodID(settingSecureClass,"getString", "(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;");
auto obj = env->CallObjectMethod(context, getContentResolverMethod);
auto str = (jstring) env->CallStaticObjectMethod(settingSecureClass, getStringMethod, obj,env->NewStringUTF("android_id"));
return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceModel(JNIEnv *env) {
jclass buildClass = env->FindClass("android/os/Build");
jfieldID modelId = env->GetStaticFieldID(buildClass, "MODEL","Ljava/lang/String;");
auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceBrand(JNIEnv *env) {
jclass buildClass = env->FindClass("android/os/Build");
jfieldID modelId = env->GetStaticFieldID(buildClass, "BRAND","Ljava/lang/String;");
auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceUniqueIdentifier(JNIEnv *env, const char *uuid) {
jclass uuidClass = env->FindClass("java/util/UUID");
auto len = strlen(uuid);
jbyteArray myJByteArray = env->NewByteArray(len);
env->SetByteArrayRegion(myJByteArray, 0, len, (jbyte *) uuid);
jmethodID nameUUIDFromBytesMethod = env->GetStaticMethodID(uuidClass,"nameUUIDFromBytes","([B)Ljava/util/UUID;");
jmethodID toStringMethod = env->GetMethodID(uuidClass, "toString","()Ljava/lang/String;");
auto obj = env->CallStaticObjectMethod(uuidClass, nameUUIDFromBytesMethod, myJByteArray);
auto str = (jstring) env->CallObjectMethod(obj, toStringMethod);
return env->GetStringUTFChars(str, 0);
}
inline std::string getClipboard(JavaVM* jvm) {
if (jvm == nullptr) return {};
std::string result;
JNIEnv* env;
if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) return {};

jclass looperClass = env->FindClass("android/os/Looper");
jmethodID prepareMethod = env->GetStaticMethodID(looperClass, "prepare", "()V");
env->CallStaticVoidMethod(looperClass, prepareMethod);
jclass activityThreadClass = env->FindClass("android/app/ActivityThread");
jfieldID sCurrentActivityThreadField = env->GetStaticFieldID(activityThreadClass, "sCurrentActivityThread", "Landroid/app/ActivityThread;");
jobject sCurrentActivityThread = env->GetStaticObjectField(activityThreadClass, sCurrentActivityThreadField);
jfieldID mInitialApplicationField = env->GetFieldID(activityThreadClass, "mInitialApplication", "Landroid/app/Application;");
jobject mInitialApplication = env->GetObjectField(sCurrentActivityThread, mInitialApplicationField);
jclass contextClass = env->FindClass("android/content/Context");
jmethodID getSystemServiceMethod = env->GetMethodID(contextClass, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
jstring clipboardStr = env->NewStringUTF("clipboard");
jobject clipboardManager = env->CallObjectMethod(mInitialApplication, getSystemServiceMethod, clipboardStr);
env->DeleteLocalRef(clipboardStr);
jclass clipboardManagerClass = env->FindClass("android/content/ClipboardManager");
jmethodID getTextMethod = env->GetMethodID(clipboardManagerClass, "getText", "()Ljava/lang/CharSequence;");
jclass charSequenceClass = env->FindClass("java/lang/CharSequence");
jmethodID toStringMethod = env->GetMethodID(charSequenceClass, "toString", "()Ljava/lang/String;");
jobject text = env->CallObjectMethod(clipboardManager, getTextMethod);
if (text) {
jstring jstr = (jstring)env->CallObjectMethod(text, toStringMethod);
const char* cstr = env->GetStringUTFChars(jstr, nullptr);
result = cstr;
env->ReleaseStringUTFChars(jstr, cstr);
env->DeleteLocalRef(jstr);
env->DeleteLocalRef(text);
}

env->DeleteLocalRef(charSequenceClass);
env->DeleteLocalRef(clipboardManagerClass);
env->DeleteLocalRef(clipboardManager);
env->DeleteLocalRef(contextClass);
env->DeleteLocalRef(mInitialApplication);
env->DeleteLocalRef(sCurrentActivityThread);
env->DeleteLocalRef(activityThreadClass);

jvm->DetachCurrentThread();

return result;
}



// Bug #4 fix: mutex para proteger msg de acceso concurrente.
// Sin esto, múltiples clics en LOGAR generan data race → string corrupto/crash.
static std::mutex s_msgMtx;
std::string msg;
static char Username[128];
static char Password[128];
inline bool isLogin = false;
inline bool loginn = false;
inline bool showLoginScreen = true;
inline bool isLoginSuccess = false;
static bool remember;
char username[128] = "";
char password[128] = "";


std::string Teste(JavaVM *vm, const char *user, const char *pass) {
if (!vm) return SO("FATAL ERROR");
JNIEnv *env = nullptr;
vm->AttachCurrentThread(&env, 0);
char params[1024];
std::string isURL_str = O("https://leomodzvipadmin.x10.mx/mod/CheckLogin.php?user=%s&pass=%s&uid=%s");
const char *isURL = isURL_str.c_str();
auto object = getJNIContext(env);
std::string hwid = user;
hwid += GetAndroidID(env, object);
hwid += GetDeviceModel(env);
hwid += GetDeviceBrand(env);
std::string UUID = GetDeviceUniqueIdentifier(env, hwid.c_str());

snprintf(params, sizeof(params), isURL, user, pass,UUID.c_str());
const char *Request = getRequestURL(env,params);

vm->DetachCurrentThread();

if(strcmp(isURL, OBFUSCATE("https://leomodzvipadmin.x10.mx/mod/CheckLogin.php?user=%s&pass=%s&uid=%s")) != 0) {
return O("não foi possível obter informações do servidor");
}

std::string FindUser = (user);
if (FindUser.find(SO("*")) != std::string::npos)
{
return O("não foi possível obter informações do servidor");
}
if (FindUser.find(SO("'")) != std::string::npos)
{
return O("não foi possível obter informações do servidor");
}

std::string FindURL = (isURL);
std::string FindParams = (params);
if (FindURL.find(SO("https://leomodzvipadmin.x10.mx")) != std::string::npos && FindParams.find(SO("https://leomodzvipadmin.x10.mx/mod/")) != std::string::npos)
{
if(Request != nullptr)
{
std::string request = (Request);
if (request.find(UUID) != std::string::npos)
{
if(strcmp(Request,UUID.c_str()) != 0)
{
return O("não foi possível obter informações do servidor");
}
return O("Init");
}
else if(request.find("ﾠ") != std::string::npos)
{
return O("Usuário ou senha incorretos.");
}
else
{
return request.c_str();
}
} else {
return O("não foi possível obter informações do servidor");
}
}
else
{
return O("não foi possível obter informações do servidor");
}
}

void LoginThread2(const std::string &username, const std::string &password) {
    isLogin = true;
    std::string result = Teste(jvm, username.c_str(), password.c_str());
    { std::lock_guard<std::mutex> lk(s_msgMtx); msg = result; } // Bug #4 fix
    isLogin = false;
}
// Variables de estado de ShowLogin2 — declaradas aquí porque solo se usan en esta función
static float   gsButtonWidth    = 200.f;
static float   gsButtonHeight   = 80.f;
static float   borderWidth      = 1.f;
static float   textScale        = 1.f;
static double  clickStartTime3  = -1.0;
static bool    isDragging3      = false;
static ImVec2  gsButtonPos3     = ImVec2(0.f, 0.f);

void ShowLogin2() {
if (isLogin) {
ImVec2 screen_size = ImGui::GetIO().DisplaySize;
ImVec2 top_left_pos = ImVec2((screen_size.x - gsButtonWidth) * 0.5f, (screen_size.y - gsButtonHeight) * 0.5f);
ImGui::SetNextWindowSize(ImVec2(gsButtonWidth, gsButtonHeight), ImGuiCond_Always);
ImGui::SetNextWindowPos(top_left_pos, ImGuiCond_Always);
ImGui::Begin(OBFUSCATE("Bottaaonesp"), nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoBackground);

ImVec4 invisibleColor = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
ImDrawList* draw_list = ImGui::GetWindowDrawList();
ImVec2 rect_min = ImGui::GetWindowPos();
ImVec2 rect_max = ImVec2(rect_min.x + gsButtonWidth, rect_min.y + gsButtonHeight);
draw_list->AddRectFilled(rect_min, rect_max, ImGui::GetColorU32(invisibleColor));
draw_list->AddRect(rect_min, rect_max, ImGui::GetColorU32(invisibleColor), 10.0f, ImDrawFlags_RoundCornersAll, borderWidth);

ImGui::SetWindowFontScale(textScale);
ImVec2 text_size = ImGui::CalcTextSize(OBFUSCATE("LEO MODZ ON"));
ImVec2 text_pos = ImVec2((gsButtonWidth - text_size.x) * 0.5f, (gsButtonHeight - text_size.y) * 0.5f);
ImGui::SetCursorPos(text_pos);
ImGui::TextColored(invisibleColor, "%s", (const char*)(char*)OBFUSCATE("LEO MODZ ON"));
ImGui::SetWindowFontScale(1.4f);

if (ImGui::IsWindowHovered() && ImGui::IsMouseClicked(0)) {
clickStartTime3 = ImGui::GetTime();
} else if (ImGui::IsMouseReleased(0)) {
if (clickStartTime3 != -1.0f && (ImGui::GetTime() - clickStartTime3 >= 0.1f)) {
isLogin = false;
showLoginScreen = true;
}
clickStartTime3 = -1.0f;
}

if (ImGui::IsWindowHovered() && ImGui::IsMouseClicked(0)) {
isDragging3 = true;
}

if (isDragging3 && ImGui::IsMouseDown(0)) {
ImVec2 mouse_pos = ImGui::GetMousePos();
gsButtonPos3 = ImVec2(mouse_pos.x - gsButtonWidth * 0.5f, mouse_pos.y - gsButtonHeight * 0.5f);
}

if (ImGui::IsMouseReleased(0)) {
isDragging3 = false;
}

ImGui::End();
}


if (showLoginScreen) {
    // Tema vermelho e preto
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.01f, 0.01f, 0.01f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.8f, 0.0f, 0.0f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.1f, 0.0f, 0.0f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.3f, 0.0f, 0.0f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.6f, 0.0f, 0.0f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.0f, 0.0f, 1.0f));

    ImGui::GetStyle().FrameBorderSize = 1.0f;

    if (ImGui::Begin(O("LEO MODZ VIP LOGIN"), nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoCollapse)) {
        if (loginn) {
            ImGui::CenteredText(ImVec4(1.0f, 0.0f, 0.0f, 1.0f), O("EFETUANDO O LOGIN..."));
        } else {
            ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0.05f, 0.0f, 0.0f, 1.0f));
            ImGui::InputTextWithHint("##user", "Username", Username, 128, ImGuiInputTextFlags_CharsNoBlank);
            ImGui::PopStyleColor();

            if (ImGui::Button(O("COLAR USUARIO"), {ImGui::GetContentRegionAvail().x , 0})) {
                strcpy(Username, getClipboard().c_str());
            }

            ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0.05f, 0.0f, 0.0f, 1.0f));
            ImGui::InputTextWithHint("##pw", "Password", Password, 128, ImGuiInputTextFlags_Password | ImGuiInputTextFlags_CharsNoBlank);
            ImGui::PopStyleColor();

            if (ImGui::Button(O("COLAR SENHA"), {ImGui::GetContentRegionAvail().x , 0})) {
                strcpy(Password, getClipboard().c_str());
            }

            ImGui::Separator();

            if (ImGui::Button(O("LOGAR"), {ImGui::GetContentRegionAvail().x, 0})) {
                std::thread login_thread(LoginThread2, std::string(Username), std::string(Password));
                login_thread.detach();
            }

            // Bug #4 fix: leer msg bajo lock para evitar data race
            std::string msgCopy;
            { std::lock_guard<std::mutex> lk(s_msgMtx); msgCopy = msg; }

            if (!(strcmp(msgCopy.c_str(), OBFUSCATE("Init")))) {
                loginn = false;
                isLoginSuccess = true;
            } else {
                ImGui::TextColored(ImVec4(0.8f, 0.0f, 0.0f, 1.0f), "%s", msgCopy.c_str());
            }
        }
        ImGui::End();
    }
    ImGui::PopStyleColor(6);
}

if (isLoginSuccess) {
    // Bug #14 fix: DrawESP() y Aimbott() eliminados del proyecto limpio.
    // Solo renderizar el menú principal de ImGui.
    menu();
}
}
