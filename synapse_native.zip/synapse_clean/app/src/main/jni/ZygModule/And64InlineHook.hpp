#pragma once
#define A64_MAX_BACKUPS 256

#ifdef __cplusplus
extern "C" {
#endif

    void EglSwapInit(void *const symbol, void *const replace, void **result);
    void *EglSwapInitV(void *const symbol, void *const replace,
                           void *const rwx, const uintptr_t rwx_size);

#ifdef __cplusplus
}
#endif

// Alias de compatibilidad — EglSwapInit es A64HookFunction (renombrado para stealth)
#define A64HookFunction EglSwapInit
