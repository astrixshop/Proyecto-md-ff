#pragma once
// zygisk.h — solo Zygisk module class
// FreeFire() y hook_eglSwapBuffers() viven en cheat.cpp — NO duplicar aqui

#include <layout.h>

class _BYTE; class _QWORD;
class _DWORD; class _WORD;
#define _QWORD long
#define _DWORD long
#define _BYTE  long
#define _WORD  long

using zygisk::Api;
using zygisk::AppSpecializeArgs;
using zygisk::ServerSpecializeArgs;

class GsModz : public zygisk::ModuleBase {
public:
    void onLoad(Api *api, JNIEnv *env) override {
        this->api = api;
        this->env = env;
    }
    void preAppSpecialize(AppSpecializeArgs *args) override {
        auto package_name = env->GetStringUTFChars(args->nice_name, nullptr);
        auto app_data_dir = env->GetStringUTFChars(args->app_data_dir, nullptr);
        preSpecialize(package_name, app_data_dir);
        env->ReleaseStringUTFChars(args->nice_name, package_name);
        env->ReleaseStringUTFChars(args->app_data_dir, app_data_dir);
    }
    void postAppSpecialize(const AppSpecializeArgs *) override {
        if (enable_hack && isFreeFire) {
            // FreeFire() definida en cheat.cpp
            extern void* FreeFire(const char*);
            std::thread hack_thread(FreeFire, game_data_dir.c_str());
            hack_thread.detach();
        }
    }
private:
    Api *api;
    JNIEnv *env;
    bool enable_hack = false;
    bool isFreeFire  = false;
    // Bug #12 fix: usar std::string en lugar de char* con new[]/strcpy.
    // La versión anterior: no tenía destructor → memory leak.
    // strcpy sin bounds check → heap overflow si app_data_dir > PATH_MAX.
    std::string game_data_dir;
    std::vector<std::string> targetPackagesFF = {
        OBFUSCATE("com.dts.freefireth"),
        OBFUSCATE("com.dts.freefiremax"),
        OBFUSCATE("com.dts.freefireadv")
    };
    void preSpecialize(const char *package_name, const char *app_data_dir) {
        for (const auto &pkg : targetPackagesFF) {
            if (strcmp(package_name, pkg.c_str()) == 0) {
                enable_hack   = true;
                isFreeFire    = true;
                game_data_dir = app_data_dir ? std::string(app_data_dir) : "";
                return;
            }
        }
    }
};
REGISTER_ZYGISK_MODULE(GsModz)
