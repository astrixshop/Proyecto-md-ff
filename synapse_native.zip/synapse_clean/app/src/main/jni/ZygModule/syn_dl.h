// syn_dl.h — dl_iterate_phdr compatible con AIDE NDK r12
// <link.h> no tiene dl_phdr_info completo ni ElfW en NDK r12.
// Solo arm64-v8a — usamos Elf64 directamente.
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <elf.h>
#include <dlfcn.h>

typedef struct {
    uintptr_t         dlpi_addr;
    const char*       dlpi_name;
    const Elf64_Phdr* dlpi_phdr;
    uint16_t          dlpi_phnum;
} SYN_dl_phdr_info;

typedef int (*SYN_dl_iterate_fn)(
    int (*)(SYN_dl_phdr_info*, size_t, void*), void*);

// RTLD_NOLOAD: libc.so ya está cargada, no aumenta refcount.
// dlclose solo decrementa el contador — no descarga libc.
static inline SYN_dl_iterate_fn SYN_get_dl_iter() {
    void* h = dlopen("libc.so", RTLD_NOW | RTLD_NOLOAD);
    if (!h) return nullptr;
    auto fn = (SYN_dl_iterate_fn)dlsym(h, "dl_iterate_phdr");
    dlclose(h);
    return fn;
}
