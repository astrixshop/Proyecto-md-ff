// particulas.h — stub vacío
// El archivo original contenía int main() y class Player (código de prueba).
// Eliminado para evitar conflicto con el entry point real del .so.
// Si necesitas partículas usa particles.h / particles.cpp.
#pragma once
