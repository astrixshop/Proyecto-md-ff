// Copyright (c) 2025 @SynapseCheats. All rights reserved.
#pragma once
#include <imports.h>
#include <imguiconfig.h>
#include "particles.h"
#include <string>
#include <chrono>
// #include <map>  // eliminado: se usa ImGuiStorage en vez de std::map

// ── Variables del proyecto ────────────────────────────────────────
extern bool AimbotEsp;
extern bool aimbotAuto;
extern bool aimbotTrigger;
extern bool Aimbot;
extern bool AimVisible;
extern bool AimSilent;
extern float Fov_Aim;
extern float Aimdis;
extern bool EspBox;
extern bool EspLine;
extern bool EspVida;
extern bool EspCircle;
extern bool EspInfo;
extern bool SpeedHack;
extern bool GhostHack;
extern bool Paraquedas;
extern bool TelekillTeste;
extern bool ResetGuest1;
extern int  currentLinePosition;
extern int  currentBoxType;
extern int  aimPosition;
extern int  aimSmoothing;
extern bool ignoreKnockedEnemies;

// ── Paleta de colores ─────────────────────────────────────────────
#define SC_BG     ImVec4(0.04f,  0.04f,  0.06f,  0.97f)
#define SC_PANEL  ImVec4(0.06f,  0.06f,  0.09f,  1.00f)
#define SC_CYN    ImVec4(0.00f,  0.75f,  0.90f,  1.00f)
#define SC_CYND   ImVec4(0.00f,  0.35f,  0.45f,  1.00f)
#define SC_WHT    ImVec4(0.90f,  0.92f,  0.95f,  1.00f)
#define SC_MUT    ImVec4(0.40f,  0.50f,  0.55f,  1.00f)
#define SC_GRN    ImVec4(0.10f,  0.80f,  0.30f,  1.00f)
#define SC_RED    ImVec4(0.90f,  0.20f,  0.20f,  1.00f)
#define SC_YEL    ImVec4(1.00f,  0.80f,  0.00f,  1.00f)
#define SC_PINK   ImVec4(0.85f,  0.10f,  0.55f,  1.00f)

// ── Toggle animado ────────────────────────────────────────────────
// Bug #13 fix: reemplazar std::map<ImGuiID, float> con ImGuiStorage.
// std::map nunca liberaba entradas huérfanas al recrear el menú → crecimiento indefinido.
// ImGuiStorage es manejado por ImGui y se limpia con el contexto automáticamente.
static ImGuiStorage _s_tog;

static bool SCToggle(const char* label, bool* v) {
    ImGuiWindow* w = ImGui::GetCurrentWindow();
    if (w->SkipItems) return false;
    ImGuiContext& g = *GImGui;
    const ImGuiID id = w->GetID(label);

    const float h  = 26.f;
    const float tw = h * 2.5f;
    const float r  = h * 0.50f;
    ImVec2 ls  = ImGui::CalcTextSize(label);
    ImVec2 pos = w->DC.CursorPos;
    float  avail = ImGui::GetContentRegionAvail().x;

    ImRect bb(pos, ImVec2(pos.x + avail, pos.y + h));
    ImGui::ItemSize(bb, g.Style.FramePadding.y);
    if (!ImGui::ItemAdd(bb, id)) return false;

    ImVec2 tmin(bb.Max.x - tw, bb.Min.y);
    ImVec2 tmax(bb.Max.x,      bb.Max.y);
    ImGui::SetCursorScreenPos(tmin);
    bool pressed = ImGui::InvisibleButton(label, ImVec2(tw, h));
    if (pressed) *v = !*v;

    float cur = _s_tog.GetFloat(id, *v ? 1.f : 0.f);
    cur = ImLerp(cur, *v ? 1.f : 0.f, g.IO.DeltaTime * 14.f);
    _s_tog.SetFloat(id, cur);
    float t = cur;

    auto dl = w->DrawList;
    ImVec2 ctr((tmin.x+tmax.x)*0.5f, (tmin.y+tmax.y)*0.5f);

    dl->AddRectFilled(tmin, tmax, IM_COL32(14, 14, 20, 255), r);
    if (*v) {
        dl->AddRectFilledMultiColor(tmin, tmax,
            IM_COL32(0, 160, 200, (int)(160*t)),
            IM_COL32(200, 0, 120, (int)(160*t)),
            IM_COL32(200, 0, 120, (int)(160*t)),
            IM_COL32(0, 160, 200, (int)(160*t)));
        dl->AddRect(tmin, tmax, IM_COL32(0, 210, 240, 220), r, 0, 1.8f);
        dl->AddRect(ImVec2(tmin.x-2,tmin.y-2),
                    ImVec2(tmax.x+2,tmax.y+2),
                    IM_COL32(0,190,220,35), r, 0, 2.5f);
    } else {
        dl->AddRect(tmin, tmax, IM_COL32(55, 55, 65, 255), r, 0, 1.2f);
    }

    float kx = tmin.x + r + t * (tw - r*2.f);
    ImVec2 knob(kx, ctr.y);
    dl->AddCircleFilled(knob, r*0.78f+2, IM_COL32(0,0,0,80));
    dl->AddCircleFilled(knob, r*0.75f,   IM_COL32(255,255,255,255));
    if (*v)
        dl->AddCircle(knob, r*0.90f, IM_COL32(255,255,255,110), 0, 1.5f);

    dl->AddText(ImVec2(bb.Min.x, ctr.y - ls.y*0.5f),
                IM_COL32(220,230,245,255), label);
    return pressed;
}

static void Sec(const char* t) {
    ImGui::Spacing();
    ImGui::PushStyleColor(ImGuiCol_Text, SC_CYN);
    ImGui::TextUnformatted(t);
    ImGui::PopStyleColor();
    ImGui::PushStyleColor(ImGuiCol_Separator, SC_CYND);
    ImGui::Separator();
    ImGui::PopStyleColor();
    ImGui::Spacing();
}

static void SCSlider(const char* lbl, const char* id,
                     float* v, float mn, float mx) {
    char buf[20]; snprintf(buf,sizeof(buf),"%.0f",*v);
    ImGui::TextUnformatted(lbl);
    ImGui::SameLine(ImGui::GetContentRegionAvail().x - 36.f);
    ImGui::PushStyleColor(ImGuiCol_Text, SC_CYN);
    ImGui::TextUnformatted(buf);
    ImGui::PopStyleColor();
    ImGui::SetNextItemWidth(-1);
    ImGui::SliderFloat(id, v, mn, mx, "");
    ImGui::Spacing();
}

static void ApplyTheme() {
    ImGuiStyle& s = ImGui::GetStyle();
    ImVec4* c = s.Colors;
    c[ImGuiCol_WindowBg]        = SC_BG;
    c[ImGuiCol_ChildBg]         = SC_PANEL;
    c[ImGuiCol_TitleBg]         = ImVec4(.02f,.02f,.04f,1.f);
    c[ImGuiCol_TitleBgActive]   = ImVec4(.02f,.02f,.04f,1.f);
    c[ImGuiCol_Border]          = ImVec4(.0f,.40f,.50f,.80f);
    c[ImGuiCol_FrameBg]         = ImVec4(.04f,.06f,.09f,1.f);
    c[ImGuiCol_FrameBgHovered]  = ImVec4(.0f,.22f,.28f,.8f);
    c[ImGuiCol_FrameBgActive]   = SC_CYND;
    c[ImGuiCol_Button]          = ImVec4(.0f,.18f,.24f,.7f);
    c[ImGuiCol_ButtonHovered]   = ImVec4(.0f,.34f,.44f,.9f);
    c[ImGuiCol_ButtonActive]    = SC_CYN;
    c[ImGuiCol_SliderGrab]      = SC_CYN;
    c[ImGuiCol_SliderGrabActive]= SC_WHT;
    c[ImGuiCol_CheckMark]       = SC_CYN;
    c[ImGuiCol_Separator]       = ImVec4(.0f,.35f,.45f,.5f);
    c[ImGuiCol_Text]            = SC_WHT;
    c[ImGuiCol_TextDisabled]    = SC_MUT;
    c[ImGuiCol_Header]          = ImVec4(.0f,.18f,.24f,.6f);
    c[ImGuiCol_HeaderHovered]   = ImVec4(.0f,.30f,.40f,.8f);
    c[ImGuiCol_HeaderActive]    = SC_CYN;
    s.WindowRounding   = 10.f;
    s.FrameRounding    =  5.f;
    s.GrabRounding     =  6.f;
    s.WindowTitleAlign = ImVec2(.5f,.5f);
    s.FramePadding     = ImVec2(9.f,7.f);
    s.ItemSpacing      = ImVec2(8.f,9.f);
    s.WindowBorderSize = 1.2f;
    s.FrameBorderSize  = 0.f;
}

// ═════════════════════════════════════════════════════════════════
// MENÚ PRINCIPAL
// ═════════════════════════════════════════════════════════════════
static void menu() {
    ApplyTheme();

    static bool    visible    = true;
    static int     tab        = 0;
    static int     aimSub     = 0;

    // ── Estado de la bolita ───────────────────────────────────────
    static ImVec2  bPos       = ImVec2(12.f, 12.f);  // esquina sup-izq
    static ImVec2  touchStart = ImVec2(0.f, 0.f);
    static ImVec2  dOff       = ImVec2(0.f, 0.f);
    static bool    onBall     = false;
    static bool    dragging   = false;
    static double  lastTapTime = 0.0;   // timestamp del último tap (ImGui time)

    const float BR           = 26.f;   // radio de la bolita
    const float DRAG_THRESH  = 12.f;   // píxeles para distinguir tap de drag

    ImGuiIO& io = ImGui::GetIO();
    float cx = bPos.x + BR, cy = bPos.y + BR;   // centro de la bolita

    // ── Lógica drag vs tap ────────────────────────────────────────
    // Paso 1: detectar inicio de toque sobre la bolita
    if (!onBall && io.MouseDown[0]) {
        float dx = io.MousePos.x - cx;
        float dy = io.MousePos.y - cy;
        if (dx*dx + dy*dy <= BR*BR) {
            onBall     = true;
            dragging   = false;
            touchStart = io.MousePos;
            dOff       = ImVec2(io.MousePos.x - bPos.x,
                                io.MousePos.y - bPos.y);
        }
    }

    // Paso 2: mientras el dedo sigue presionado
    if (onBall && io.MouseDown[0]) {
        float moved = sqrtf(
            (io.MousePos.x - touchStart.x) * (io.MousePos.x - touchStart.x) +
            (io.MousePos.y - touchStart.y) * (io.MousePos.y - touchStart.y));

        // Solo activar drag si el dedo se movió lo suficiente
        if (moved > DRAG_THRESH) dragging = true;

        if (dragging) {
            // Mover la bolita siguiendo el dedo
            bPos.x = ImClamp(io.MousePos.x - dOff.x,
                             0.f, io.DisplaySize.x - BR*2.f);
            bPos.y = ImClamp(io.MousePos.y - dOff.y,
                             0.f, io.DisplaySize.y - BR*2.f);
            cx = bPos.x + BR;
            cy = bPos.y + BR;
        }
    }

    // Paso 3: dedo levantado
    if (onBall && !io.MouseDown[0]) {
        if (!dragging) {
            // Double-tap: dos taps en < 400ms → toggle
            double now = ImGui::GetTime();
            if (now - lastTapTime < 0.4) {
                visible = !visible;
                lastTapTime = 0.0; // reset para evitar triple-tap
            } else {
                lastTapTime = now; // guardar para el siguiente tap
            }
        }
        onBall   = false;
        dragging = false;
    }

    // ── Dibujar bolita en el fondo (siempre visible) ──────────────
    {
        ImDrawList* dl = ImGui::GetBackgroundDrawList();

        // Sombra
        dl->AddCircleFilled(ImVec2(cx+2.f, cy+3.f), BR,
                            IM_COL32(0,0,0,70), 32);
        // Azul = menú visible / gris oscuro = oculto (doble tap para abrir)
        ImU32 fill = visible
            ? IM_COL32(0, 90, 115, 240)
            : IM_COL32(30, 30, 45, 220);
        dl->AddCircleFilled(ImVec2(cx, cy), BR, fill, 32);

        // Borde cyan
        dl->AddCircle(ImVec2(cx, cy), BR,
                      IM_COL32(0, 190, 230, 180), 32, 1.8f);

        // Letra "S" centrada
        ImVec2 ts = ImGui::CalcTextSize("S");
        dl->AddText(ImVec2(cx - ts.x*0.5f, cy - ts.y*0.5f),
                    IM_COL32(220, 240, 255, 255), "S");
    }

    if (!visible) return;

    // ── Ventana principal (movible via barra de título) ───────────
    ImGui::SetNextWindowPos(ImVec2(74.f, 8.f), ImGuiCond_Once);
    ImGui::SetNextWindowSize(ImVec2(450.f, 490.f), ImGuiCond_Always);

    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding,   10.f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize,  1.2f);
    ImGui::PushStyleColor(ImGuiCol_Border, SC_CYND);


    bool open = ImGui::Begin("  Game Assistant  |  OB53  |  64-bit  ",
        nullptr,
        ImGuiWindowFlags_NoScrollbar |
        ImGuiWindowFlags_NoCollapse  |
        ImGuiWindowFlags_NoResize);

    if (!open) {
        ImGui::End();
        ImGui::PopStyleColor();
        ImGui::PopStyleVar(2);
        return;
    }

    // ── Tabs ──────────────────────────────────────────────────────
    const char* tabs[] = { " AIM ", " ESP ", " MISC ", " INFO " };
    for (int i = 0; i < 4; i++) {
        ImGui::PushStyleColor(ImGuiCol_Button,
            tab == i ? SC_CYND : ImVec4(.0f,.10f,.14f,.7f));
        ImGui::PushStyleColor(ImGuiCol_Text,
            tab == i ? SC_WHT : SC_MUT);
        if (ImGui::Button(tabs[i], ImVec2(104.f, 36.f))) tab = i;
        ImGui::PopStyleColor(2);
        if (i < 3) ImGui::SameLine(0, 4.f);
    }
    ImGui::Separator();
    ImGui::Spacing();

    ImGui::BeginChild("##cnt", ImVec2(-1, -2), false);

    // ══════════════════════════════════════
    // TAB 0 — AIM
    // ══════════════════════════════════════
    if (tab == 0) {
        const char* st[] = { "Silent##s", "Aimbot##a", "Config##c" };
        for (int i = 0; i < 3; i++) {
            ImGui::PushStyleColor(ImGuiCol_Button,
                aimSub == i ? ImVec4(.0f,.20f,.28f,.9f)
                            : ImVec4(0,0,0,0));
            if (ImGui::Button(st[i], ImVec2(138.f, 28.f))) aimSub = i;
            ImGui::PopStyleColor();
            if (i < 2) ImGui::SameLine(0, 3.f);
        }
        ImGui::Spacing();

        if (aimSub == 0) {
            Sec("SILENT AIM");
            SCToggle("Silent Aim",           &AimbotEsp);       ImGui::Spacing();
            SCToggle("Siempre activo",       &aimbotAuto);      ImGui::Spacing();
            SCToggle("Al disparar",          &aimbotTrigger);   ImGui::Spacing();
            SCToggle("Ignorar tumbados",     &ignoreKnockedEnemies);

            Sec("OBJETIVO");
            static const char* bparts[] = { "Cabeza","Cuello","Pecho","Cadera" };
            ImGui::TextUnformatted("Parte del cuerpo:");
            ImGui::SetNextItemWidth(-1);
            ImGui::Combo("##bp", &aimPosition, bparts, 4);
            ImGui::Spacing();
            static const char* smopts[] = {
                "Instantaneo","Muy suave","Suave","Medio","Lento","Muy lento"
            };
            ImGui::TextUnformatted("Suavizado:");
            ImGui::SetNextItemWidth(-1);
            ImGui::Combo("##sm", &aimSmoothing, smopts, 6);
        }
        else if (aimSub == 1) {
            Sec("RANGO");
            SCSlider("FOV / Radio",       "##fov",  &Fov_Aim,  5.f, 360.f);
            SCSlider("Distancia max (m)", "##dst",  &Aimdis,  10.f, 500.f);
        }
        else {
            Sec("VISIBILIDAD");
            SCToggle("Solo visibles",   &AimVisible);  ImGui::Spacing();
            SCToggle("Aim Silent",      &AimSilent);

        }
    }

    // ══════════════════════════════════════
    // TAB 1 — ESP
    // ══════════════════════════════════════
    else if (tab == 1) {
        Sec("ESP");
        SCToggle("ESP activo",           &AimbotEsp);   ImGui::Spacing();
        SCToggle("Caja (corners)",       &EspBox);      ImGui::Spacing();
        SCToggle("Linea de seguimiento", &EspLine);     ImGui::Spacing();
        SCToggle("Barra de vida",        &EspVida);     ImGui::Spacing();
        SCToggle("Circulo FOV",          &EspCircle);   ImGui::Spacing();
        SCToggle("Info (nick/dist)",     &EspInfo);
        if (EspCircle) {
            ImGui::Spacing();
            SCSlider("Radio circulo px", "##fovr", &Fov_Aim, 10.f, 400.f);
        }

        Sec("POSICION LINEA");
        static const char* lpos[] = {
            "Arriba-Izq","Arriba","Abajo","Centro","OFF"
        };
        ImGui::SetNextItemWidth(-1);
        ImGui::Combo("##lpos", &currentLinePosition, lpos, 5);

        Sec("TIPO CAJA");
        static const char* btype[] = { "Corners","Full Box","3D","OFF" };
        ImGui::SetNextItemWidth(-1);
        ImGui::Combo("##btype", &currentBoxType, btype, 4);
    }

    // ══════════════════════════════════════
    // TAB 2 — MISC
    // ══════════════════════════════════════
    else if (tab == 2) {
        Sec("MOVIMIENTO");
        SCToggle("Speed Hack",             &SpeedHack);    ImGui::Spacing();
        SCToggle("Ghost Hack (noclip)",    &GhostHack);    ImGui::Spacing();
        SCToggle("Paracaidas infinito",    &Paraquedas);   ImGui::Spacing();

        Sec("CUENTA");
        SCToggle("Reset Guest (invitado)", &ResetGuest1);  ImGui::Spacing();
        SCToggle("Telekill (experimental)",&TelekillTeste);
    }

    // ══════════════════════════════════════
    // TAB 3 — INFO
    // ══════════════════════════════════════
    else {
        Sec("ESTADO");
        auto SL = [](const char* lbl, bool on) {
            ImGui::TextColored(on ? SC_GRN : SC_MUT,
                "%s %s", on ? ">" : ".", lbl);
        };
        SL("Silent Aim",  AimbotEsp);
        SL("Aimbot Auto", aimbotAuto);
        SL("ESP",         AimbotEsp && (EspBox||EspLine||EspVida));
        SL("Speed Hack",  SpeedHack);
        SL("Ghost Hack",  GhostHack);

        Sec("BUILD");
        ImGui::TextColored(SC_CYN, "Game Assistant  v3.2");
        ImGui::TextColored(SC_MUT, "Free Fire MAX  OB53  64-bit");
        ImGui::Spacing();
        ImGui::TextColored(SC_YEL, "FOV: %.0f    Dist: %.0fm", Fov_Aim, Aimdis);

        Sec("RIESGO BAN");
        int risk = (SpeedHack?25:0)+(GhostHack?20:0)
                 + (aimbotAuto?15:0)+(TelekillTeste?20:0);
        if (risk > 100) risk = 100;
        ImVec4 rc = risk < 30 ? SC_GRN : risk < 60 ? SC_YEL : SC_RED;
        ImGui::TextColored(rc, "Riesgo: %d%%", risk);
        ImGui::PushStyleColor(ImGuiCol_PlotHistogram, rc);
        ImGui::ProgressBar(risk/100.f, ImVec2(-1,7), "");
        ImGui::PopStyleColor();
    }

    ImGui::EndChild();
    ImGui::End();
    ImGui::PopStyleColor();  // Border
    ImGui::PopStyleVar(2);   // WindowRounding + BorderSize
}
