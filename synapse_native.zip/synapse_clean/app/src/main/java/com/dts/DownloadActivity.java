package com.dts;
// SLog: ver SLog.java — DEBUG=true activa logs

import android.app.Activity;
import android.os.Bundle;

// DownloadActivity — descarga eliminada.
// Las bases se leen directamente de la raíz del APK.
// Esta clase se mantiene en caso de que el AndroidManifest la referencie.
public class DownloadActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        finish(); // nada que hacer
    }
}
