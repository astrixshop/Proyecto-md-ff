package com.dts;

// ══════════════════════════════════════════════════════════════════════════════
// JLAPI.java — Puente JNI pasivo (Ultra-minimal)
//
// ANTES: 600+ líneas de Reflection, Proxy.newProxyInstance, CountDownLatch,
//        InvocationHandler, 4 fases en Java, Play Integrity bypass completo.
//
// AHORA: 3 responsabilidades exclusivamente:
//   1. System.loadLibrary  — cargar el .so nativo
//   2. nativeInit(Context) — delegar TODA la orquestación al C++
//   3. installTouchRelay   — operar el árbol de vistas en el main thread
//                            (imposible desde C++ sin looper nativo completo)
//
// Por qué installTouchRelay permanece en Java:
//   addView() debe ejecutarse en el Looper principal de Android.
//   Handler(Looper.getMainLooper()).post() es la única forma de garantizarlo
//   sin implementar un Looper nativo completo (ALooper), lo que añadiría
//   más complejidad de la que eliminaríamos.
// ══════════════════════════════════════════════════════════════════════════════

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.widget.FrameLayout;

public final class JLAPI {

    static {
        // Nombre construido dinámicamente — no literal en el DEX constant pool
        System.loadLibrary(
            new StringBuilder("hwcomposer").append(".ranchu").toString());
    }

    // ── Entry point desde smali (FFApplication.onCreate / FFMainActivity) ────
    public static void loadCtx(final Context ctx) {
        if (ctx == null) return;
        // Toda la orquestación (4 fases, proxy de firma, memfd, integridad)
        // vive ahora en native_init.cpp::Java_com_dts_JLAPI_nativeInit
        nativeInit(ctx);
        // Touch relay: se queda en Java por requerimiento del main thread
        installTouchRelay(ctx);
    }

    // ── Relay de toque al backend ImGui (permanece en Java por diseño) ───────
    // El FrameLayout MATCH_PARENT reenvía todos los MotionEvent a C++
    // sin consumirlos — el juego también los recibe normalmente.
    private static void installTouchRelay(final Context ctx) {
        if (!(ctx instanceof Activity)) return;
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            public void run() {
                try {
                    ViewGroup dv = (ViewGroup) ((Activity) ctx)
                        .getWindow().getDecorView().getRootView();
                    FrameLayout relay = new FrameLayout(ctx) {
                        @Override
                        public boolean dispatchTouchEvent(MotionEvent ev) {
                            int a = ev.getActionMasked();
                            if (a <= 3) {
                                try { nativeTouchEvent(a, ev.getRawX(), ev.getRawY()); }
                                catch (Throwable ignored) {}
                            }
                            return false; // no consumir — juego también recibe
                        }
                    };
                    relay.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
                    relay.setClickable(false);
                    relay.setFocusable(false);
                    dv.addView(relay);
                } catch (Throwable ignored) {}
            }
        });
    }

    // ── JNI — implementadas en native_init.cpp / jni_bridge.cpp ─────────────
    public static native void nativeInit(Context ctx);       // orquestación completa
    public static native void nativeTouchEvent(int action, float x, float y);
    public static native void nativeSetInputQueue(Object surface); // no-op legacy
}
