package com.dts;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * MenuOverlay — Menú Java interno sin SYSTEM_ALERT_WINDOW.
 *
 * Se agrega directamente al DecorView de Unity (sin servicio flotante).
 * Garena NO puede detectarlo como overlay porque usa la jerarquía de vistas
 * de la propia actividad — no hay permiso especial, no hay WindowManager.
 *
 * Apertura: doble-tap en esquina inferior-izquierda (invisible, sin botón).
 * Cierre: tap fuera del menú o doble-tap de nuevo.
 */
public final class MenuOverlay {

    private static FrameLayout   sRoot;
    private static LinearLayout  sPanel;
    private static boolean        sVisible = false;
    private static final Handler  sMain    = new Handler(Looper.getMainLooper());

    // ── Inicializar y agregar al UnityPlayer ─────────────────────────────────
    public static void init(final Context ctx) {
        sMain.post(new Runnable() {
            public void run() {
                if (!(ctx instanceof Activity)) return;
                Activity act = (Activity) ctx;

                // Contenedor raíz transparente — cubre toda la pantalla
                sRoot = new FrameLayout(ctx);
                sRoot.setLayoutParams(new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
                sRoot.setVisibility(View.GONE);

                // Panel del menú
                sPanel = buildPanel(ctx);
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    dp(ctx, 280), ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.leftMargin  = dp(ctx, 12);
                lp.topMargin   = dp(ctx, 60);
                sPanel.setLayoutParams(lp);

                sRoot.addView(sPanel);

                // Tap fuera del panel cierra el menú
                sRoot.setOnTouchListener(new View.OnTouchListener() {
                    public boolean onTouch(View v, MotionEvent e) {
                        if (e.getAction() == MotionEvent.ACTION_UP) {
                            float x = e.getRawX(), y = e.getRawY();
                            int[] loc = new int[2];
                            sPanel.getLocationOnScreen(loc);
                            boolean inside = x >= loc[0] && x <= loc[0] + sPanel.getWidth()
                                          && y >= loc[1] && y <= loc[1] + sPanel.getHeight();
                            if (!inside) hide();
                        }
                        return true;
                    }
                });

                // STEALTH FIX 3: getChildCount() del DecorView es detectable por el juego
                // via JNI. Solución: envolver sRoot en un FrameLayout subclaseado que
                // devuelve 0 en getChildCount() y null en getChildAt() cuando está GONE,
                // haciéndolo invisible para cualquier traversal del árbol de vistas.
                ViewGroup decorView = (ViewGroup) act.getWindow()
                    .getDecorView().getRootView();
                decorView.addView(new FrameLayout(ctx) {
                    { addView(sRoot); }
                    @Override public int getChildCount() {
                        return sRoot.getVisibility() == View.VISIBLE ? super.getChildCount() : 0;
                    }
                    @Override public android.view.View getChildAt(int i) {
                        return sRoot.getVisibility() == View.VISIBLE ? super.getChildAt(i) : null;
                    }
                    // Relay de toque al nativo para que ImGui mueva la bolita
                    @Override public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
                        int action = ev.getActionMasked();
                        if (action <= 3) {
                            try { JLAPI.nativeTouchEvent(action, ev.getX(), ev.getY()); }
                            catch (Throwable ignored) {}
                        }
                        return super.dispatchTouchEvent(ev);
                    }
                });

                // Zona de doble-tap invisible en esquina inferior-izquierda
                installDoubleTapZone(act, decorView);
            }
        });
    }

    // ── Zona de doble-tap invisible — 80×80dp esquina inferior-izquierda ─────
    private static void installDoubleTapZone(final Activity act,
            final ViewGroup decorView) {

        final View zone = new View(act);
        FrameLayout.LayoutParams zlp = new FrameLayout.LayoutParams(
            dp(act, 80), dp(act, 80));
        zlp.gravity = android.view.Gravity.BOTTOM | android.view.Gravity.START;
        zone.setLayoutParams(zlp);
        zone.setAlpha(0f); // completamente invisible

        final GestureDetector gd = new GestureDetector(act,
            new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onDoubleTap(MotionEvent e) {
                    toggle(); return true;
                }
            });

        zone.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                return gd.onTouchEvent(e);
            }
        });

        decorView.addView(zone);
    }

    // ── Mostrar / ocultar ────────────────────────────────────────────────────
    public static void show() {
        sMain.post(new Runnable() { public void run() {
            if (sRoot == null) return;
            sVisible = true;
            sRoot.setVisibility(View.VISIBLE);
        }});
    }

    public static void hide() {
        sMain.post(new Runnable() { public void run() {
            if (sRoot == null) return;
            sVisible = false;
            sRoot.setVisibility(View.GONE);
        }});
    }

    public static void toggle() {
        if (sVisible) hide(); else show();
    }

    // ── Construir UI del panel ────────────────────────────────────────────────
    private static LinearLayout buildPanel(Context ctx) {
        // Fondo del panel
        android.graphics.drawable.GradientDrawable bg =
            new android.graphics.drawable.GradientDrawable();
        bg.setColor(Color.parseColor("#E6000000"));
        bg.setCornerRadius(dp(ctx, 12));
        bg.setStroke(dp(ctx, 1), Color.parseColor("#3333FF"));

        LinearLayout panel = new LinearLayout(ctx);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(bg);
        int p = dp(ctx, 12);
        panel.setPadding(p, p, p, p);

        // Título
        panel.addView(makeTitle(ctx, "PHANTOM MENU"));
        panel.addView(makeDivider(ctx));

        // ── Sección: Visuals ──────────────────────────────────────────────
        panel.addView(makeSection(ctx, "VISUALS"));
        panel.addView(makeSwitch(ctx, "ESP Boxes",     "esp_box"));
        panel.addView(makeSwitch(ctx, "Health Bar",    "esp_hp"));
        panel.addView(makeSwitch(ctx, "Distance",      "esp_dist"));
        panel.addView(makeDivider(ctx));

        // ── Sección: Combat ───────────────────────────────────────────────
        panel.addView(makeSection(ctx, "COMBAT"));
        panel.addView(makeSwitch(ctx, "Aimbot",        "aimbot"));
        panel.addView(makeSwitch(ctx, "Silent Aim",    "silent_aim"));
        panel.addView(makeDivider(ctx));

        // ── Sección: Misc ─────────────────────────────────────────────────
        panel.addView(makeSection(ctx, "MISC"));
        panel.addView(makeSwitch(ctx, "Speed Hack",    "speed"));
        panel.addView(makeSwitch(ctx, "No Spread",     "no_spread"));

        return panel;
    }

    // ── Widgets ───────────────────────────────────────────────────────────────

    private static TextView makeTitle(Context ctx, String text) {
        TextView tv = new TextView(ctx);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#3333FF"));
        tv.setTextSize(15);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(ctx, 8);
        tv.setLayoutParams(lp);
        return tv;
    }

    private static TextView makeSection(Context ctx, String text) {
        TextView tv = new TextView(ctx);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#9B59B6"));
        tv.setTextSize(11);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        if (android.os.Build.VERSION.SDK_INT >= 21)
            tv.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(ctx, 6);
        lp.bottomMargin = dp(ctx, 4);
        tv.setLayoutParams(lp);
        return tv;
    }

    private static View makeDivider(Context ctx) {
        View v = new View(ctx);
        v.setBackgroundColor(Color.parseColor("#333333"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 1);
        lp.topMargin = lp.bottomMargin = dp(ctx, 4);
        v.setLayoutParams(lp);
        return v;
    }

    /**
     * Switch row: label a la izquierda, toggle a la derecha.
     * key = identificador de la feature — conéctalo a tu lógica nativa.
     */
    private static View makeSwitch(final Context ctx, final String label,
            final String key) {

        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowLp.bottomMargin = dp(ctx, 6);
        row.setLayoutParams(rowLp);

        // Etiqueta
        final TextView tv = new TextView(ctx);
        tv.setText(label);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(12);
        tv.setLayoutParams(new LinearLayout.LayoutParams(
            0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        // Bug 6 FIX: android.widget.Switch está deprecated desde API 33 (Android 13).
        // Usamos androidx.appcompat.widget.SwitchCompat si está disponible,
        // con fallback a android.widget.Switch para dispositivos pre-13.
        final CompoundButton sw;
        try {
            Class<?> swCompat = Class.forName("androidx.appcompat.widget.SwitchCompat");
            sw = (CompoundButton) swCompat
                .getConstructor(Context.class).newInstance(ctx);
        } catch (Throwable ignored2) {
            // Fallback para builds sin appcompat
            sw = new android.widget.Switch(ctx);
        }
        sw.setChecked(false);
        sw.setTag(key);
        sw.setOnCheckedChangeListener(
            new android.widget.CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(
                        android.widget.CompoundButton b, boolean checked) {
                    // Conectar aquí con la lógica nativa via JNI o variable estática
                    onFeatureToggle(key, checked);
                }
            });

        row.addView(tv);
        row.addView(sw);
        return row;
    }

    // ── JNI bridge — declarar en cheat.cpp como:
    //    JNIEXPORT void JNICALL Java_com_dts_MenuOverlay_nativeSetFeature(
    //        JNIEnv*, jclass, jstring key, jboolean enabled)
    private static native void nativeSetFeature(String key, boolean enabled);

    // ── Callback de features — conectado al nativo via JNI ──────────────────
    // Bug 3 FIX: antes este método estaba vacío — todos los switches del menú
    // Java no hacían absolutamente nada. Ahora llama nativeSetFeature() que
    // el C++ implementa en cheat.cpp. Si la librería aún no está cargada
    // (fase 2 no completada) el try-catch absorbe el UnsatisfiedLinkError.
    private static void onFeatureToggle(String key, boolean enabled) {
        try {
            nativeSetFeature(key, enabled);
        } catch (UnsatisfiedLinkError ignored) {
            // .so aún no cargado — el estado se pierde; el C++ ImGui sync
            // sobreescribirá el estado cuando el menú nativo se sincronice.
        }
    }

    // ── Helper ────────────────────────────────────────────────────────────────
    private static int dp(Context ctx, int v) {
        return Math.round(v * ctx.getResources().getDisplayMetrics().density);
    }
}
